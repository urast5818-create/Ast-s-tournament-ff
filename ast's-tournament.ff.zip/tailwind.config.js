/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        esBg: '#0B0F14',
        esSurface: '#171C24',
        esCard: '#1F2633',
        esCards: '#1F2633',
        esPrimary: '#FF8A00',
        esSecondary: '#FFC107',
        esAccent: '#FF8A00',
        esSuccess: '#4CAF50',
        esError: '#F44336',
        esTextPrimary: '#FFFFFF',
        esTextSecondary: '#C5C5C5',
        esBorder: '#2B313D',
      },
    },
  },
  plugins: [],
}
