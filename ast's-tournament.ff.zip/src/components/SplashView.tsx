import React from 'react';
import { Trophy, Cpu } from 'lucide-react';
import { appStrings } from '../config/appStrings';

interface SplashViewProps {
  progress: number;
  status: string;
}

export default function SplashView({ progress, status }: SplashViewProps) {
  return (
    <div className="flex-1 min-h-screen flex flex-col items-center justify-center bg-[#0B0F14] text-white p-6 relative overflow-hidden">
      {/* Glow Effects */}
      <div className="absolute top-[30%] left-[50%] -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-esPrimary/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[60%] left-[50%] -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-esSecondary/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-md w-full text-center space-y-8 relative z-10 animate-in fade-in duration-700">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-[28px] bg-gradient-to-tr from-esPrimary to-esSecondary flex items-center justify-center shadow-[0_0_50px_rgba(255,138,0,0.3)] animate-pulse">
            <Trophy size={40} className="text-[#0B0F14]" />
          </div>
        </div>

        <div className="space-y-3">
          <span className="text-[10px] tracking-[0.4em] font-mono text-esSecondary uppercase font-extrabold bg-esSecondary/10 px-3.5 py-1.5 rounded-full border border-esSecondary/20">
            {appStrings.splash.badgeText}
          </span>
          <h2 className="text-3xl font-black tracking-tight text-white uppercase font-heading">
            {appStrings.splash.title}
          </h2>
          <p className="text-xs text-esTextSecondary max-w-xs mx-auto">
            {appStrings.splash.subtitle}
          </p>
        </div>

        {/* Custom Progress Bar */}
        <div className="space-y-3 pt-6">
          <div className="flex items-center justify-between text-[10px] font-mono text-esTextSecondary font-bold px-1">
            <span className="flex items-center gap-1.5 uppercase tracking-wide">
              <Cpu size={12} className="text-esPrimary animate-spin" />
              {status}
            </span>
            <span className="text-esSecondary">{progress}%</span>
          </div>

          <div className="w-full h-2.5 bg-[#171C24] rounded-full overflow-hidden border border-[#2B313D] p-[2px]">
            <div 
              className="h-full bg-gradient-to-r from-esPrimary to-esSecondary rounded-full transition-all duration-300 shadow-[0_0_12px_rgba(255,138,0,0.4)]"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="pt-8 text-[9px] text-esTextSecondary/40 font-mono uppercase tracking-widest">
          {appStrings.splash.footer}
        </div>
      </div>
    </div>
  );
}

