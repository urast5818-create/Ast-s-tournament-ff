import React, { useState } from 'react';
import { Send, Wallet, Percent, DollarSign, Key, CheckCircle, Clock } from 'lucide-react';
import { UserProfile, Transaction } from '../types';
import { appStrings } from '../config/appStrings';

interface WalletViewProps {
  userProfile: UserProfile;
  transactions: Transaction[];
  promoCode: string;
  setPromoCode: (v: string) => void;
  depositAmount: string;
  setDepositAmount: (v: string) => void;
  depositUpi: string;
  setPromoCodeClean: (v: string) => void; // just to make sure we pass the correct handlers
  setDepositUpi: (v: string) => void;
  withdrawAmount: string;
  setWithdrawAmount: (v: string) => void;
  withdrawUpi: string;
  setWithdrawUpi: (v: string) => void;
  onRedeemCoupon: (e: React.FormEvent) => void;
  onDeposit: (e: React.FormEvent) => void;
  onWithdrawal: (e: React.FormEvent) => void;
}

export default function WalletView({
  userProfile,
  transactions,
  promoCode,
  setPromoCode,
  depositAmount,
  setDepositAmount,
  depositUpi,
  setDepositUpi,
  withdrawAmount,
  setWithdrawAmount,
  withdrawUpi,
  setWithdrawUpi,
  onRedeemCoupon,
  onDeposit,
  onWithdrawal,
}: WalletViewProps) {
  const [activeFormTab, setActiveFormTab] = useState<'deposit' | 'withdraw'>('deposit');

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* 1. Large Balance Metrics Overview Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-[#1F2633] to-[#171C24] border-t-4 border-t-esPrimary border border-[#2B313D] rounded-3xl p-6 text-left shadow-xl relative overflow-hidden group">
          <div className="absolute top-4 right-4 w-12 h-12 rounded-full bg-esPrimary/5 flex items-center justify-center border border-esPrimary/10">
            <Wallet size={20} className="text-esPrimary" />
          </div>
          <span className="text-[10px] font-mono font-black text-esTextSecondary block uppercase tracking-widest">
            {appStrings.wallet.mainWalletHeader}
          </span>
          <span className="text-3xl font-black text-white font-mono block mt-2 tracking-tight">
            ${userProfile.walletBalance.toFixed(2)}
          </span>
          <p className="text-[10px] text-esTextSecondary font-mono mt-1.5 uppercase">
            {appStrings.wallet.mainWalletSub}
          </p>
        </div>

        <div className="bg-gradient-to-br from-[#1F2633] to-[#171C24] border-t-4 border-t-esSecondary border border-[#2B313D] rounded-3xl p-6 text-left shadow-xl relative overflow-hidden group">
          <div className="absolute top-4 right-4 w-12 h-12 rounded-full bg-esSecondary/5 flex items-center justify-center border border-esSecondary/10">
            <Percent size={18} className="text-esSecondary" />
          </div>
          <span className="text-[10px] font-mono font-black text-esTextSecondary block uppercase tracking-widest">
            {appStrings.wallet.bonusWalletHeader}
          </span>
          <span className="text-3xl font-black text-white font-mono block mt-2 tracking-tight">
            ${userProfile.bonusBalance.toFixed(2)}
          </span>
          <p className="text-[10px] text-esTextSecondary font-mono mt-1.5 uppercase">
            {appStrings.wallet.bonusWalletSub}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left forms (8 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Action forms with tabs */}
          <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl overflow-hidden shadow-xl">
            {/* Tabs */}
            <div className="flex border-b border-[#2B313D]">
              <button 
                onClick={() => setActiveFormTab('deposit')}
                className={`flex-1 py-4 font-black text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
                  activeFormTab === 'deposit' 
                    ? 'border-esPrimary text-white bg-[#1F2633]' 
                    : 'border-transparent text-esTextSecondary hover:text-white hover:bg-[#1F2633]/30'
                }`}
              >
                {appStrings.wallet.tabDepositLabel}
              </button>
              <button 
                onClick={() => setActiveFormTab('withdraw')}
                className={`flex-1 py-4 font-black text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
                  activeFormTab === 'withdraw' 
                    ? 'border-esPrimary text-white bg-[#1F2633]' 
                    : 'border-transparent text-esTextSecondary hover:text-white hover:bg-[#1F2633]/30'
                }`}
              >
                {appStrings.wallet.tabWithdrawLabel}
              </button>
            </div>

            <div className="p-6">
              {/* Deposit funds container */}
              {activeFormTab === 'deposit' && (
                <form onSubmit={onDeposit} className="space-y-4 text-left">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">{appStrings.wallet.depositTitle}</h4>
                    <span className="text-[9px] font-mono text-esSecondary font-extrabold bg-esSecondary/10 border border-esSecondary/25 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                      {appStrings.wallet.manualGatewayBadge}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] text-esTextSecondary font-mono block uppercase tracking-widest">
                        {appStrings.wallet.depositAmountLabel}
                      </label>
                      <input 
                        type="number"
                        min="1"
                        required
                        value={depositAmount}
                        onChange={e => setDepositAmount(e.target.value)}
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary focus:shadow-[0_0_10px_rgba(255,138,0,0.15)] font-mono transition-all"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] text-esTextSecondary font-mono block uppercase tracking-widest">
                        {appStrings.wallet.depositRefLabel}
                      </label>
                      <input 
                        type="text"
                        required
                        placeholder={appStrings.wallet.depositRefPlaceholder}
                        value={depositUpi}
                        onChange={e => setDepositUpi(e.target.value)}
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary focus:shadow-[0_0_10px_rgba(255,138,0,0.15)] font-mono transition-all"
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-3.5 bg-gradient-to-r from-esPrimary to-[#FFA040] hover:from-[#FFA040] hover:to-esPrimary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest transition-all duration-300 shadow-md shadow-esPrimary/10 hover:shadow-[0_0_15px_rgba(255,138,0,0.35)] cursor-pointer font-heading"
                  >
                    {appStrings.wallet.depositButtonText}
                  </button>

                  <p className="text-[9px] text-esTextSecondary/50 font-mono text-center leading-relaxed">
                    {appStrings.wallet.depositTip}
                  </p>
                </form>
              )}

              {/* Withdraw funds container */}
              {activeFormTab === 'withdraw' && (
                <form onSubmit={onWithdrawal} className="space-y-4 text-left">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">{appStrings.wallet.withdrawTitle}</h4>
                    <span className="text-[9px] font-mono text-esPrimary bg-esPrimary/10 border border-esPrimary/25 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                      {appStrings.wallet.rootTransfersBadge}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] text-esTextSecondary font-mono block uppercase tracking-widest">
                        {appStrings.wallet.withdrawAmountLabel}
                      </label>
                      <input 
                        type="number"
                        min="1"
                        required
                        value={withdrawAmount}
                        onChange={e => setWithdrawAmount(e.target.value)}
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary focus:shadow-[0_0_10px_rgba(255,138,0,0.15)] font-mono transition-all"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] text-esTextSecondary font-mono block uppercase tracking-widest">
                        {appStrings.wallet.withdrawUpiLabel}
                      </label>
                      <input 
                        type="text"
                        required
                        placeholder={appStrings.wallet.withdrawUpiPlaceholder}
                        value={withdrawUpi}
                        onChange={e => setWithdrawUpi(e.target.value)}
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary focus:shadow-[0_0_10px_rgba(255,138,0,0.15)] font-mono transition-all"
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-3.5 bg-gradient-to-r from-esPrimary to-[#FFA040] hover:from-[#FFA040] hover:to-esPrimary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest transition-all duration-300 shadow-md shadow-esPrimary/10 hover:shadow-[0_0_15px_rgba(255,138,0,0.35)] cursor-pointer font-heading"
                  >
                    {appStrings.wallet.withdrawButtonText}
                  </button>

                  <p className="text-[9px] text-esTextSecondary/50 font-mono text-center leading-relaxed">
                    {appStrings.wallet.withdrawTip}
                  </p>
                </form>
              )}
            </div>
          </div>

          {/* Promo code redeemer */}
          <form onSubmit={onRedeemCoupon} className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 space-y-4 shadow-xl text-left">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">{appStrings.wallet.redeemTitle}</h4>
            
            <div className="flex gap-3">
              <input 
                type="text"
                value={promoCode}
                onChange={e => setPromoCode(e.target.value)}
                placeholder={appStrings.wallet.promoPlaceholder}
                className="flex-1 bg-[#0B0F14] border border-[#2B313D] rounded-xl px-4 py-3 text-xs text-white uppercase focus:outline-none focus:border-esPrimary focus:shadow-[0_0_10px_rgba(255,138,0,0.15)] font-mono transition-all"
              />
              <button 
                type="submit"
                className="bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] px-6 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 shadow-md shadow-esPrimary/10 cursor-pointer font-heading"
              >
                {appStrings.wallet.redeemButtonText}
              </button>
            </div>
            <p className="text-[9px] text-esTextSecondary font-mono leading-relaxed">
              {appStrings.wallet.redeemTip}
            </p>
          </form>
        </div>

        {/* Right ledger activities (5 cols) */}
        <div className="lg:col-span-5 space-y-4 text-left">
          <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-3">
              {appStrings.wallet.ledgerTitle}
            </h4>

            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {transactions.map((tx, idx) => {
                const isPending = tx.status === 'PENDING';
                const isDeposit = tx.type === 'DEPOSIT';
                const isWithdraw = tx.type === 'WITHDRAWAL';

                let badgeColor = "bg-esSecondary/10 text-esSecondary border-esSecondary/20";
                if (isDeposit && !isPending) badgeColor = "bg-[#4CAF50]/15 text-[#4CAF50] border-[#4CAF50]/30";
                if (isWithdraw) badgeColor = "bg-esPrimary/10 text-esPrimary border-esPrimary/20";

                return (
                  <div 
                    key={idx} 
                    className="bg-[#1F2633]/60 border border-[#2B313D]/70 hover:border-[#2B313D] rounded-2xl p-4 flex items-center justify-between text-xs transition-colors"
                  >
                    <div className="space-y-1 flex-1 min-w-0 pr-2">
                      <div className="flex items-center gap-2">
                        <span className={`font-mono font-black text-[8px] px-2.5 py-0.5 rounded-full border uppercase tracking-wider shrink-0 ${badgeColor}`}>
                          {tx.type}
                        </span>
                        <span className="text-white font-bold block truncate max-w-[140px]">
                          {tx.description}
                        </span>
                      </div>
                      <span className="text-[9px] text-esTextSecondary/60 font-mono block">
                        {tx.timestamp}
                      </span>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-mono font-black text-white text-sm block">
                        ${tx.amount.toFixed(2)}
                      </span>
                      <span className={`text-[8px] font-mono font-black block mt-1 flex items-center gap-1 justify-end uppercase ${
                        tx.status === 'APPROVED' ? 'text-[#4CAF50]' : isPending ? 'text-esSecondary' : 'text-[#F44336]'
                      }`}>
                        {tx.status === 'APPROVED' ? (
                          <>
                            <CheckCircle size={9} />
                            <span>{appStrings.wallet.statusApproved}</span>
                          </>
                        ) : isPending ? (
                          <>
                            <Clock size={9} className="animate-pulse" />
                            <span>{appStrings.wallet.statusPending}</span>
                          </>
                        ) : (
                          <span>{appStrings.wallet.statusRejected}</span>
                        )}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}

