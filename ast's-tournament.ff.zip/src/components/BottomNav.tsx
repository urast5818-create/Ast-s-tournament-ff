import React from 'react';
import { 
  Trophy, Layers, Wallet, User, Shield, FileCode, Gift, Smartphone
} from 'lucide-react';
import { UserProfile } from '../types';
import { appStrings } from '../config/appStrings';
import { AppSettings } from '../dbStore';

interface BottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: any) => void;
  userProfile: UserProfile;
  settings: AppSettings;
  isAdminPanelUnlocked?: boolean;
}

export default function BottomNav({
  currentTab,
  setCurrentTab,
  userProfile,
  settings,
  isAdminPanelUnlocked,
}: BottomNavProps) {
  const showQuests = settings.features.dailyReward || settings.features.referral || settings.features.supportCenter;
  const menuItems = [
    { id: 'home', label: appStrings.bottomNav.explore, icon: Trophy },
    { id: 'matches', label: appStrings.bottomNav.rooms, icon: Layers },
    { id: 'wallet', label: appStrings.bottomNav.wallet, icon: Wallet },
  ];

  if (showQuests) {
    menuItems.push({ id: 'quests', label: 'Rewards', icon: Gift });
  }

  menuItems.push({ id: 'profile', label: appStrings.bottomNav.profile, icon: User });

  menuItems.push({ id: 'developer', label: appStrings.bottomNav.devHub, icon: FileCode });

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#171C24]/90 backdrop-blur-xl border-t border-[#2B313D] z-40 px-2 flex items-center justify-around shadow-[0_-4px_24px_rgba(0,0,0,0.4)]">
      {menuItems.map(item => {
        const Icon = item.icon;
        const isActive = currentTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => setCurrentTab(item.id)}
            className="flex flex-col items-center justify-center flex-1 h-full py-1 relative group cursor-pointer transition-all"
            id={`bottom-nav-${item.id}`}
          >
            {/* Active Highlight Glow */}
            {isActive && (
              <span className="absolute top-0 w-12 h-1 bg-gradient-to-r from-esPrimary to-esSecondary rounded-b-md shadow-[0_2px_10px_rgba(255,138,0,0.8)]" />
            )}
            
            <div className={`p-1.5 rounded-xl transition-all duration-300 ${
              isActive 
                ? 'text-esPrimary bg-esPrimary/10 scale-110' 
                : 'text-esTextSecondary hover:text-white'
            }`}>
              <Icon size={20} className={isActive ? 'stroke-[2.5px]' : 'stroke-2'} />
            </div>
            
            <span className={`text-[9px] font-bold tracking-wider uppercase mt-0.5 transition-colors duration-300 ${
              isActive ? 'text-esPrimary font-black' : 'text-esTextSecondary'
            }`}>
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

