import React, { useState, useEffect } from 'react';
import { 
  Shield, TrendingUp, Users, DollarSign, Percent, Plus, Key, CheckCircle, XCircle,
  Settings, Save, RotateCcw, Type, AppWindow, UserCheck, Compass, CreditCard, Award, BellRing, Gift,
  Trash2, Copy, Edit, ToggleLeft, ToggleRight, Check, Map, Layers, Megaphone, Send, HelpCircle,
  AlertTriangle, BookOpen, Clock, Lock, Unlock, Phone, Mail, UserPlus, Info, CheckSquare, PlusCircle, Smartphone
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar 
} from 'recharts';
import { Tournament, Transaction, UserProfile, OfferApp } from '../types';
import { appStrings, saveStrings, resetStrings } from '../config/appStrings';
import { FirestoreDb, MatchType, MapItem, PromoCode, Announcement, AdminNotification, AppSettings } from '../dbStore';

interface AdminViewProps {
  tournaments: Tournament[];
  setTournaments: React.Dispatch<React.SetStateAction<Tournament[]>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  registrationTrends: any[];
  dailyParticipationData: any[];
  userProfile: UserProfile;
  onApproveTransaction: (txId: string) => void;
  onRejectTransaction: (txId: string) => void;
  onStringsUpdate: () => void;
  onRefreshData?: () => void;
}

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#171C24] border border-[#2B313D] p-3 rounded-xl shadow-lg text-left font-mono text-[10px]">
        <p className="text-esSecondary font-black uppercase mb-1">{payload[0].name.toUpperCase()}</p>
        <p className="text-white font-bold">{payload[0].value} Registered</p>
      </div>
    );
  }
  return null;
};

export default function AdminView({
  tournaments,
  setTournaments,
  transactions,
  setTransactions,
  registrationTrends,
  dailyParticipationData,
  userProfile,
  onApproveTransaction,
  onRejectTransaction,
  onStringsUpdate,
  onRefreshData
}: AdminViewProps) {
  
  // NAVIGATION TABS
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tournaments' | 'match_types' | 'maps' | 'rewards' | 'promo_codes' | 'users' | 'announcements' | 'notifications' | 'app_settings' | 'features' | 'strings' | 'offers'>('dashboard');
  
  // OFFER FORM STATES
  const [offersList, setOffersList] = useState<OfferApp[]>(() => FirestoreDb.getOffers());
  const [offerId, setOfferId] = useState('');
  const [offerAppName, setOfferAppName] = useState('');
  const [offerLogoUrl, setOfferLogoUrl] = useState('');
  const [offerDownloadUrl, setOfferDownloadUrl] = useState('');
  const [offerRewardAmount, setOfferRewardAmount] = useState('15');
  const [offerPackageName, setOfferPackageName] = useState('');

  // LOCAL FORM & EDIT STATES
  const [activeStringsSec, setActiveStringsSec] = useState<'general' | 'login' | 'explore' | 'wallet' | 'profile' | 'notifications'>('general');
  
  // Database State Hooks (Synchronized with localStorage-Firestore)
  const [settings, setSettings] = useState<AppSettings>(() => FirestoreDb.getSettings());
  const [matchTypes, setMatchTypes] = useState<MatchType[]>(() => FirestoreDb.getMatchTypes());
  const [maps, setMaps] = useState<MapItem[]>(() => FirestoreDb.getMaps());
  const [promos, setPromos] = useState<PromoCode[]>(() => FirestoreDb.getPromoCodes());
  const [announcements, setAnnouncements] = useState<Announcement[]>(() => FirestoreDb.getAnnouncements());
  const [dbUsers, setDbUsers] = useState<UserProfile[]>(() => FirestoreDb.getUsers());
  const [sentNotifications, setSentNotifications] = useState<AdminNotification[]>(() => FirestoreDb.getNotifications());

  // TOURNAMENT FORM STATES
  const [tId, setTId] = useState<string>(''); // For Editing
  const [tTitle, setTTitle] = useState('');
  const [tFee, setTFee] = useState('10');
  const [tPrize, setTPrize] = useState('200');
  const [tPerKill, setTPerKill] = useState('2');
  const [tSlots, setTSlots] = useState('48');
  const [tJoined, setTJoined] = useState('0');
  const [tMap, setTMap] = useState('Bermuda');
  const [tType, setTType] = useState('SQUAD');
  const [tRoomId, setTRoomId] = useState('');
  const [tRoomPass, setTRoomPass] = useState('');
  const [tDateTime, setTDateTime] = useState('2026-07-16 18:00');
  const [tDuration, setTDuration] = useState('45');
  const [tPoster, setTPoster] = useState('');
  const [tBanner, setTBanner] = useState('');
  const [tDescription, setTDescription] = useState('');
  const [tRules, setTRules] = useState('');
  const [tAutoRelease, setTAutoRelease] = useState(true);
  const [tReleaseTime, setTReleaseTime] = useState('15'); // 15 mins before match
  const [tPublished, setTPublished] = useState(true);
  const [tRegistrationOpen, setTRegistrationOpen] = useState(true);
  const [tCustomFields, setTCustomFields] = useState('');

  // MATCH TYPE FORM STATES
  const [mtId, setMtId] = useState('');
  const [mtName, setMtName] = useState('');
  const [mtIcon, setMtIcon] = useState('Trophy');
  const [mtColor, setMtColor] = useState('#FF8A00');
  const [mtOrder, setMtOrder] = useState('1');

  // MAP FORM STATES
  const [mapId, setMapId] = useState('');
  const [mapNameInput, setMapNameInput] = useState('');
  const [mapOrderInput, setMapOrderInput] = useState('1');

  // PROMO CODE FORM STATES
  const [promoId, setPromoId] = useState('');
  const [promoCodeInput, setPromoCodeInput] = useState('');
  const [promoReward, setPromoReward] = useState('20');
  const [promoType, setPromoType] = useState<'MAIN' | 'BONUS'>('BONUS');
  const [promoExpiry, setPromoExpiry] = useState('2026-12-31');
  const [promoLimit, setPromoLimit] = useState('100');

  // ANNOUNCEMENT FORM STATES
  const [annId, setAnnId] = useState('');
  const [annTitleInput, setAnnTitleInput] = useState('');
  const [annContentInput, setAnnContentInput] = useState('');
  const [annPinned, setAnnPinned] = useState(false);

  // NOTIFICATION BROADCAST FORM STATES
  const [notifTitle, setNotifTitle] = useState('');
  const [notifContent, setNotifContent] = useState('');
  const [notifTarget, setNotifTarget] = useState<'all' | string>('all');

  // SEARCH STATES
  const [userSearch, setUserSearch] = useState('');
  const [tournamentSearch, setTournamentSearch] = useState('');

  // Save Settings to Storage & notify parent
  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    FirestoreDb.saveSettings(newSettings);
    if (onRefreshData) onRefreshData();
  };

  // Calculations
  const totalJoined = tournaments.reduce((acc, curr) => acc + curr.joinedCount, 0);
  const totalPrizePool = tournaments.reduce((acc, curr) => acc + curr.prizePool, 0);
  const averageFillRate = tournaments.length > 0 
    ? (tournaments.reduce((acc, curr) => acc + (curr.joinedCount / curr.totalSlots), 0) / tournaments.length) * 100 
    : 0;

  const pendingDeposits = transactions.filter(t => t.status === 'PENDING' && t.type === 'DEPOSIT');

  // --- TOURNAMENT HANDLERS ---
  const handleSaveTournament = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tTitle) return;

    let updatedTournaments = [...tournaments];
    if (tId) {
      // Edit mode
      updatedTournaments = updatedTournaments.map(t => {
        if (t.id === tId) {
          return {
            ...t,
            title: tTitle.toUpperCase(),
            entryFee: parseFloat(tFee) || 0,
            prizePool: parseFloat(tPrize) || 0,
            perKillPrize: parseFloat(tPerKill) || 0,
            totalSlots: parseInt(tSlots) || 48,
            joinedCount: Math.min(parseInt(tJoined) || 0, parseInt(tSlots) || 48),
            mapName: tMap,
            type: tType,
            roomId: tRoomId || t.roomId,
            roomPassword: tRoomPass || t.roomPassword,
            dateTime: tDateTime,
            published: tPublished,
            registrationOpen: tRegistrationOpen,
            durationMinutes: parseInt(tDuration) || 45,
            posterUrl: tPoster || undefined,
            bannerUrl: tBanner || undefined,
            description: tDescription || undefined,
            rules: tRules || undefined,
            autoReleaseRoom: tAutoRelease,
            releaseTimeMins: parseInt(tReleaseTime) || 15,
            customFields: tCustomFields || undefined,
          };
        }
        return t;
      });
      alert("Tournament updated successfully in real time!");
    } else {
      // Create mode
      const newT: Tournament = {
        id: "ff_tour_" + Date.now(),
        title: tTitle.toUpperCase(),
        gameName: "Free Fire",
        dateTime: tDateTime,
        totalSlots: parseInt(tSlots) || 48,
        joinedCount: 0,
        entryFee: parseFloat(tFee) || 10.0,
        prizePool: parseFloat(tPrize) || 200.0,
        perKillPrize: parseFloat(tPerKill) || 2.0,
        mapName: tMap,
        type: tType,
        roomId: tRoomId || "FF-ROOM-" + Math.floor(10000 + Math.random() * 90000),
        roomPassword: tRoomPass || "booyah_" + Math.floor(100 + Math.random() * 900),
        participants: [],
        reportedIssues: [],
        published: tPublished,
        registrationOpen: tRegistrationOpen,
        durationMinutes: parseInt(tDuration) || 45,
        posterUrl: tPoster || undefined,
        bannerUrl: tBanner || undefined,
        description: tDescription || undefined,
        rules: tRules || undefined,
        autoReleaseRoom: tAutoRelease,
        releaseTimeMins: parseInt(tReleaseTime) || 15,
        customFields: tCustomFields || undefined,
      };
      updatedTournaments = [newT, ...updatedTournaments];
      alert("Tournament created successfully!");
    }

    setTournaments(updatedTournaments);
    FirestoreDb.saveTournaments(updatedTournaments);
    
    // Reset Form
    setTId('');
    setTTitle('');
    setTFee('10');
    setTPrize('200');
    setTPerKill('2');
    setTSlots('48');
    setTJoined('0');
    setTRoomId('');
    setTRoomPass('');
    setTDuration('45');
    setTPoster('');
    setTBanner('');
    setTDescription('');
    setTRules('');
    setTAutoRelease(true);
    setTReleaseTime('15');
    setTPublished(true);
    setTRegistrationOpen(true);
    setTCustomFields('');
  };

  const handleEditTournament = (t: Tournament) => {
    setTId(t.id);
    setTTitle(t.title);
    setTFee(t.entryFee.toString());
    setTPrize(t.prizePool.toString());
    setTPerKill(t.perKillPrize?.toString() || '2');
    setTSlots(t.totalSlots.toString());
    setTJoined(t.joinedCount.toString());
    setTMap(t.mapName);
    setTType(t.type);
    setTRoomId(t.roomId);
    setTRoomPass(t.roomPassword);
    setTDateTime(t.dateTime);
    setTDuration((t.durationMinutes || 45).toString());
    setTPoster(t.posterUrl || '');
    setTBanner(t.bannerUrl || '');
    setTDescription(t.description || '');
    setTRules(t.rules || '');
    setTAutoRelease(t.autoReleaseRoom !== false);
    setTReleaseTime((t.releaseTimeMins || 15).toString());
    setTPublished(t.published !== false);
    setTRegistrationOpen(t.registrationOpen !== false);
    setTCustomFields(t.customFields || '');
  };

  const handleDeleteTournament = (id: string) => {
    if (!window.confirm("Are you sure you want to delete this tournament permanently?")) return;
    const filtered = tournaments.filter(t => t.id !== id);
    setTournaments(filtered);
    FirestoreDb.saveTournaments(filtered);
    alert("Tournament deleted permanently!");
  };

  const handleDuplicateTournament = (t: Tournament) => {
    const dup: Tournament = {
      ...t,
      id: "ff_tour_dup_" + Date.now(),
      title: `${t.title} CLONE`,
      joinedCount: 0,
      participants: [],
      reportedIssues: [],
      roomId: "FF-ROOM-" + Math.floor(10000 + Math.random() * 90000),
      roomPassword: "booyah_" + Math.floor(100 + Math.random() * 900),
    };
    const updated = [dup, ...tournaments];
    setTournaments(updated);
    FirestoreDb.saveTournaments(updated);
    alert("Tournament duplicated successfully!");
  };

  // --- MATCH TYPES HANDLERS ---
  const handleSaveMatchType = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mtName) return;

    let updatedList = [...matchTypes];
    if (mtId) {
      updatedList = updatedList.map(m => m.id === mtId ? { ...m, name: mtName, icon: mtIcon, color: mtColor, order: parseInt(mtOrder) || 1 } : m);
      alert("Match Type updated!");
    } else {
      const newMt: MatchType = {
        id: "mt_" + Date.now(),
        name: mtName,
        icon: mtIcon,
        color: mtColor,
        order: parseInt(mtOrder) || 1,
        enabled: true
      };
      updatedList = [...updatedList, newMt];
      alert("Match Type added!");
    }
    setMatchTypes(updatedList);
    FirestoreDb.saveMatchTypes(updatedList);
    setMtId('');
    setMtName('');
    setMtIcon('Trophy');
    setMtColor('#FF8A00');
  };

  const handleToggleMatchType = (id: string) => {
    const updated = matchTypes.map(m => m.id === id ? { ...m, enabled: !m.enabled } : m);
    setMatchTypes(updated);
    FirestoreDb.saveMatchTypes(updated);
  };

  const handleDeleteMatchType = (id: string) => {
    if (!window.confirm("Delete this match type?")) return;
    const filtered = matchTypes.filter(m => m.id !== id);
    setMatchTypes(filtered);
    FirestoreDb.saveMatchTypes(filtered);
  };

  // --- MAPS HANDLERS ---
  const handleSaveMap = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mapNameInput) return;

    let updatedList = [...maps];
    if (mapId) {
      updatedList = updatedList.map(m => m.id === mapId ? { ...m, name: mapNameInput, order: parseInt(mapOrderInput) || 1 } : m);
      alert("Map updated!");
    } else {
      const newMapItem: MapItem = {
        id: "map_" + Date.now(),
        name: mapNameInput,
        order: parseInt(mapOrderInput) || 1,
        enabled: true
      };
      updatedList = [...updatedList, newMapItem];
      alert("Map added!");
    }
    setMaps(updatedList);
    FirestoreDb.saveMaps(updatedList);
    setMapId('');
    setMapNameInput('');
  };

  const handleToggleMap = (id: string) => {
    const updated = maps.map(m => m.id === id ? { ...m, enabled: !m.enabled } : m);
    setMaps(updated);
    FirestoreDb.saveMaps(updated);
  };

  const handleDeleteMap = (id: string) => {
    if (!window.confirm("Delete this map?")) return;
    const filtered = maps.filter(m => m.id !== id);
    setMaps(filtered);
    FirestoreDb.saveMaps(filtered);
  };

  // --- PROMO CODE HANDLERS ---
  const handleSavePromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCodeInput) return;

    let updatedList = [...promos];
    if (promoId) {
      updatedList = updatedList.map(p => p.id === promoId ? {
        ...p,
        code: promoCodeInput.trim().toUpperCase(),
        rewardAmount: parseFloat(promoReward) || 0,
        type: promoType,
        expiryDate: promoExpiry,
        usageLimit: parseInt(promoLimit) || 100
      } : p);
      alert("Promo Code updated!");
    } else {
      const newPromo: PromoCode = {
        id: "pc_" + Date.now(),
        code: promoCodeInput.trim().toUpperCase(),
        rewardAmount: parseFloat(promoReward) || 20,
        type: promoType,
        expiryDate: promoExpiry,
        usageLimit: parseInt(promoLimit) || 100,
        redeemedCount: 0,
        redeemedBy: [],
        enabled: true
      };
      updatedList = [newPromo, ...updatedList];
      alert("Promo Code created!");
    }
    setPromos(updatedList);
    FirestoreDb.savePromoCodes(updatedList);
    setPromoId('');
    setPromoCodeInput('');
  };

  const handleTogglePromo = (id: string) => {
    const updated = promos.map(p => p.id === id ? { ...p, enabled: !p.enabled } : p);
    setPromos(updated);
    FirestoreDb.savePromoCodes(updated);
  };

  const handleDeletePromo = (id: string) => {
    if (!window.confirm("Delete this promo code?")) return;
    const filtered = promos.filter(p => p.id !== id);
    setPromos(filtered);
    FirestoreDb.savePromoCodes(filtered);
  };

  // --- ANNOUNCEMENTS HANDLERS ---
  const handleSaveAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitleInput || !annContentInput) return;

    let updatedList = [...announcements];
    if (annId) {
      updatedList = updatedList.map(a => a.id === annId ? {
        ...a,
        title: annTitleInput.toUpperCase(),
        content: annContentInput,
        pinned: annPinned
      } : a);
      alert("Announcement updated!");
    } else {
      const newAnn: Announcement = {
        id: "ann_" + Date.now(),
        title: annTitleInput.toUpperCase(),
        content: annContentInput,
        scheduledTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
        pinned: annPinned,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
      };
      updatedList = [newAnn, ...updatedList];
      alert("Announcement posted!");
    }
    setAnnouncements(updatedList);
    FirestoreDb.saveAnnouncements(updatedList);
    setAnnId('');
    setAnnTitleInput('');
    setAnnContentInput('');
    setAnnPinned(false);
  };

  const handleDeleteAnnouncement = (id: string) => {
    if (!window.confirm("Delete this announcement?")) return;
    const filtered = announcements.filter(a => a.id !== id);
    setAnnouncements(filtered);
    FirestoreDb.saveAnnouncements(filtered);
  };

  // --- BROADCAST NOTIFICATION HANDLER ---
  const handleBroadcastNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle || !notifContent) return;

    const newNotif: AdminNotification = {
      id: "notif_" + Date.now(),
      title: notifTitle,
      content: notifContent,
      targetUsers: notifTarget === 'all' ? 'all' : [notifTarget],
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    const updatedLog = [newNotif, ...sentNotifications];
    setSentNotifications(updatedLog);
    FirestoreDb.saveNotifications(updatedLog);

    // Also trigger parent's global notifications state array
    setNotifTitle('');
    setNotifContent('');
    alert(`Alert notification "${notifTitle}" broadcasted in real time!`);
  };

  // --- USER CONTROLS HANDLERS ---
  const handleToggleUserStatus = (uid: string, status: 'active' | 'banned' | 'suspended') => {
    const updated = dbUsers.map(u => u.uid === uid ? { ...u, status } : u);
    setDbUsers(updated);
    FirestoreDb.saveUsers(updated);
    alert(`User status updated to ${status.toUpperCase()}!`);
  };

  const handleModifyUserBalance = (uid: string, walletType: 'main' | 'bonus', amountStr: string) => {
    const amt = parseFloat(amountStr);
    if (isNaN(amt)) return;
    const updated = dbUsers.map(u => {
      if (u.uid === uid) {
        return {
          ...u,
          walletBalance: walletType === 'main' ? amt : u.walletBalance,
          bonusBalance: walletType === 'bonus' ? amt : u.bonusBalance
        };
      }
      return u;
    });
    setDbUsers(updated);
    FirestoreDb.saveUsers(updated);
    alert("User account wallet balances updated successfully!");
  };

  // Centralized strings logic (original intact)
  const updateString = (category: string, key: string, value: string) => {
    const updated = JSON.parse(JSON.stringify(appStrings));
    updated[category][key] = value;
    saveStrings(updated);
    onStringsUpdate();
  };

  const updateStatusArray = (index: number, value: string) => {
    const updated = JSON.parse(JSON.stringify(appStrings));
    updated.splash.statuses[index] = value;
    saveStrings(updated);
    onStringsUpdate();
  };

  const handleResetStrings = () => {
    if (window.confirm("Reset all UI string labels to default?")) {
      resetStrings();
      onStringsUpdate();
      alert("Reset completed!");
    }
  };

  return (
    <div className="space-y-6 text-left">
      
      {/* 1. Header with Bento Tab Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#2B313D] pb-5">
        <div>
          <div className="flex items-center gap-2">
            <Shield size={18} className="text-esSecondary" />
            <h3 className="text-sm font-black text-white uppercase tracking-wider font-heading">
              {appStrings.admin.title}
            </h3>
            <span className="text-[9px] font-mono font-black text-esSecondary bg-esSecondary/10 border border-esSecondary/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              {appStrings.admin.securedBadge}
            </span>
          </div>
          <p className="text-[10px] text-esTextSecondary font-mono mt-1 uppercase">
            AUTOMATED REALTIME FIRESTORE WORKSPACE ● ACTIVE SYNC LIVE
          </p>
        </div>

        {/* Modular Navigation Bar */}
        <div className="flex flex-wrap gap-1.5 bg-[#131921] border border-[#2B313D] p-1 rounded-2xl shadow-inner max-w-full overflow-x-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
            { id: 'tournaments', label: 'Tournaments', icon: Award },
            { id: 'match_types', label: 'Match Types', icon: Layers },
            { id: 'maps', label: 'Maps', icon: Map },
            { id: 'rewards', label: 'Quest Rewards', icon: Gift },
            { id: 'promo_codes', label: 'Promo Codes', icon: Percent },
            { id: 'users', label: 'Users Hub', icon: Users },
            { id: 'announcements', label: 'Broadcast Info', icon: Megaphone },
            { id: 'notifications', label: 'Alerts Desks', icon: BellRing },
            { id: 'app_settings', label: 'App Settings', icon: AppWindow },
            { id: 'offers', label: 'App Offers', icon: Smartphone },
            { id: 'features', label: 'Toggles', icon: Settings },
            { id: 'strings', label: 'UI Texts', icon: Type }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-2 rounded-xl text-[9px] font-mono font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
                  isActive
                    ? 'bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] font-black shadow-md'
                    : 'text-esTextSecondary hover:text-white hover:bg-[#1F2633]/30'
                }`}
              >
                <Icon size={10} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. TAB CONTENT PANELS */}

      {/* PANEL 1: DASHBOARD */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="bg-[#171C24] border border-[#2B313D] rounded-2xl p-5 shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[9px] text-esTextSecondary font-mono font-black uppercase tracking-wider">{appStrings.admin.totalPlayersLabel}</span>
                <Users size={14} className="text-esSecondary" />
              </div>
              <p className="text-2xl font-black text-white font-mono">{totalJoined}</p>
              <p className="text-[8px] text-esTextSecondary/50 font-mono uppercase mt-0.5">{appStrings.admin.totalPlayersSub}</p>
            </div>

            <div className="bg-[#171C24] border border-[#2B313D] rounded-2xl p-5 shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[9px] text-esTextSecondary font-mono font-black uppercase tracking-wider">{appStrings.admin.totalPrizesLabel}</span>
                <DollarSign size={14} className="text-esPrimary" />
              </div>
              <p className="text-2xl font-black text-white font-mono">${totalPrizePool}</p>
              <p className="text-[8px] text-esTextSecondary/50 font-mono uppercase mt-0.5">{appStrings.admin.totalPrizesSub}</p>
            </div>

            <div className="bg-[#171C24] border border-[#2B313D] rounded-2xl p-5 shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[9px] text-esTextSecondary font-mono font-black uppercase tracking-wider">{appStrings.admin.avgFillRateLabel}</span>
                <Percent size={14} className="text-esSecondary" />
              </div>
              <p className="text-2xl font-black text-white font-mono">{averageFillRate.toFixed(0)}%</p>
              <p className="text-[8px] text-esTextSecondary/50 font-mono uppercase mt-0.5">{appStrings.admin.avgFillRateSub}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-center border-b border-[#2B313D]/40 pb-3">
                  <div>
                    <h5 className="text-[10px] font-mono font-black text-esSecondary uppercase tracking-wider">{appStrings.admin.chart1Title}</h5>
                    <p className="text-[8px] text-esTextSecondary font-mono uppercase mt-0.5">MATCH ENROLLS TREND INDEX</p>
                  </div>
                </div>
                <div className="h-52 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={registrationTrends} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorRegistrations" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#FF8A00" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#FF8A00" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#2B313D" vertical={false} />
                      <XAxis dataKey="date" stroke="#9EABB6" fontSize={8} fontFamily="monospace" tickLine={false} />
                      <YAxis stroke="#9EABB6" fontSize={8} fontFamily="monospace" tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area type="monotone" dataKey="registrations" name="Registrations" stroke="#FF8A00" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRegistrations)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Pending approvals */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
                <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-3">
                  {appStrings.admin.pendingDepositsHeader} ({pendingDeposits.length})
                </h4>

                {pendingDeposits.length === 0 ? (
                  <p className="text-[10px] text-esTextSecondary/60 text-center py-12 italic font-mono bg-[#1F2633]/30 border border-[#2B313D]/50 rounded-2xl">
                    {appStrings.admin.noPendingDeposits}
                  </p>
                ) : (
                  <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                    {pendingDeposits.map(t => (
                      <div key={t.id} className="bg-[#1F2633] border border-[#2B313D] rounded-2xl p-4 space-y-3 shadow-md">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-mono font-black text-white">
                            ${t.amount.toFixed(2)}
                          </span>
                          <span className="text-[9px] text-esTextSecondary/60 font-mono">
                            {t.timestamp}
                          </span>
                        </div>

                        <div className="bg-[#0B0F14] rounded-xl p-2.5 border border-[#2B313D]/60 font-mono text-[9px] space-y-1">
                          <div className="flex justify-between">
                            <span className="text-esTextSecondary">TXN ID:</span>
                            <span className="text-white font-bold select-all">{t.upiTxnId}</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <button 
                            onClick={() => onRejectTransaction(t.id)}
                            className="py-2 bg-[#F44336]/10 hover:bg-[#F44336]/20 text-[#F44336] rounded-xl text-[9px] font-black uppercase tracking-wider font-mono border border-[#F44336]/20 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <XCircle size={10} />
                            <span>{appStrings.admin.rejectButton}</span>
                          </button>
                          <button 
                            onClick={() => onApproveTransaction(t.id)}
                            className="py-2 bg-[#4CAF50]/15 hover:bg-[#4CAF50]/25 text-[#4CAF50] rounded-xl text-[9px] font-black uppercase tracking-wider font-mono border border-[#4CAF50]/25 hover:border-[#4CAF50]/45 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <CheckCircle size={10} />
                            <span>{appStrings.admin.approveButton}</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PANEL 2: TOURNAMENTS CRUD */}
      {activeTab === 'tournaments' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Tournament Form (5 Columns) */}
          <div className="lg:col-span-5 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3 flex items-center gap-2">
              <Plus size={14} className="text-esSecondary" />
              <span>{tId ? 'EDIT TOURNAMENT' : 'PUBLISH NEW LOBBY'}</span>
            </h4>

            <form onSubmit={handleSaveTournament} className="space-y-3 text-left">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Lobby Match Title</label>
                <input 
                  type="text" 
                  value={tTitle} 
                  onChange={e => setTTitle(e.target.value)} 
                  placeholder="e.g. GRAND DUELS: BR RANKED"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Entry Fee ($)</label>
                  <input 
                    type="number" 
                    value={tFee} 
                    onChange={e => setTFee(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Prize Pool ($)</label>
                  <input 
                    type="number" 
                    value={tPrize} 
                    onChange={e => setTPrize(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Per Kill Prize ($)</label>
                  <input 
                    type="number" 
                    value={tPerKill} 
                    onChange={e => setTPerKill(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Max Slots</label>
                  <input 
                    type="number" 
                    value={tSlots} 
                    onChange={e => setTSlots(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Select Map</label>
                  <select 
                    value={tMap} 
                    onChange={e => setTMap(e.target.value)}
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  >
                    {maps.filter(m => m.enabled).map(m => (
                      <option key={m.id} value={m.name}>{m.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Select Match Type</label>
                  <select 
                    value={tType} 
                    onChange={e => setTType(e.target.value)}
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  >
                    {matchTypes.filter(m => m.enabled).map(mt => (
                      <option key={mt.id} value={mt.name}>{mt.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Room ID (Released)</label>
                  <input 
                    type="text" 
                    value={tRoomId} 
                    onChange={e => setTRoomId(e.target.value)} 
                    placeholder="Auto generated if empty"
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Room Password</label>
                  <input 
                    type="text" 
                    value={tRoomPass} 
                    onChange={e => setTRoomPass(e.target.value)} 
                    placeholder="Auto generated if empty"
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Match Date & Time</label>
                <input 
                  type="text" 
                  value={tDateTime} 
                  onChange={e => setTDateTime(e.target.value)} 
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  required
                />
              </div>

              {/* Advanced Tournament Properties */}
              <div className="grid grid-cols-2 gap-3 border-t border-[#2B313D]/40 pt-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Match Duration (Mins)</label>
                  <input 
                    type="number" 
                    value={tDuration} 
                    onChange={e => setTDuration(e.target.value)} 
                    placeholder="45"
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Room Release Time (Mins before)</label>
                  <input 
                    type="number" 
                    value={tReleaseTime} 
                    onChange={e => setTReleaseTime(e.target.value)} 
                    placeholder="15"
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Poster Image URL</label>
                  <input 
                    type="text" 
                    value={tPoster} 
                    onChange={e => setTPoster(e.target.value)} 
                    placeholder="https://..."
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono text-[10px]"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Banner Image URL</label>
                  <input 
                    type="text" 
                    value={tBanner} 
                    onChange={e => setTBanner(e.target.value)} 
                    placeholder="https://..."
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono text-[10px]"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Tournament Description</label>
                <textarea 
                  value={tDescription} 
                  onChange={e => setTDescription(e.target.value)} 
                  placeholder="Enter strategic descriptions, prize breakdowns, etc."
                  rows={2}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-sans"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Tournament Rules</label>
                <textarea 
                  value={tRules} 
                  onChange={e => setTRules(e.target.value)} 
                  placeholder="1. Strictly no emulators or hack tools allowed.&#10;2. Play fair."
                  rows={3}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-sans"
                />
              </div>

              <div className="grid grid-cols-3 gap-2.5 bg-[#0B0F14]/50 border border-[#2B313D]/40 p-3.5 rounded-2xl">
                <label className="flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center">
                  <span className="text-[8px] font-mono font-bold text-esTextSecondary uppercase">Auto-Release ID</span>
                  <input 
                    type="checkbox" 
                    checked={tAutoRelease} 
                    onChange={e => setTAutoRelease(e.target.checked)}
                    className="w-4 h-4 text-esPrimary bg-[#0B0F14] border-[#2B313D] rounded"
                  />
                </label>
                <label className="flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center">
                  <span className="text-[8px] font-mono font-bold text-esTextSecondary uppercase">Published</span>
                  <input 
                    type="checkbox" 
                    checked={tPublished} 
                    onChange={e => setTPublished(e.target.checked)}
                    className="w-4 h-4 text-esPrimary bg-[#0B0F14] border-[#2B313D] rounded"
                  />
                </label>
                <label className="flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center">
                  <span className="text-[8px] font-mono font-bold text-esTextSecondary uppercase">Reg Open</span>
                  <input 
                    type="checkbox" 
                    checked={tRegistrationOpen} 
                    onChange={e => setTRegistrationOpen(e.target.checked)}
                    className="w-4 h-4 text-esPrimary bg-[#0B0F14] border-[#2B313D] rounded"
                  />
                </label>
              </div>

              <div className="flex gap-2 pt-2">
                <button 
                  type="submit"
                  className="flex-1 py-3.5 bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest transition-all cursor-pointer font-heading"
                >
                  {tId ? 'SAVE TOURNAMENT' : 'PUBLISH TOURNAMENT'}
                </button>
                {tId && (
                  <button 
                    type="button" 
                    onClick={() => {
                      setTId('');
                      setTTitle('');
                    }}
                    className="px-4 bg-[#1F2633] border border-[#2B313D] hover:bg-[#0B0F14] text-white rounded-xl text-xs font-black cursor-pointer font-mono"
                  >
                    CANCEL
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Tournaments List Grid (7 Columns) */}
          <div className="lg:col-span-7 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4 text-left">
            <div className="flex justify-between items-center border-b border-[#2B313D]/40 pb-3">
              <h4 className="text-xs font-black text-white uppercase tracking-wider">ACTIVE TOURNAMENT SELECTION</h4>
              <input 
                type="text"
                placeholder="Search lobbies..."
                value={tournamentSearch}
                onChange={e => setTournamentSearch(e.target.value)}
                className="bg-[#0B0F14] border border-[#2B313D] rounded-xl px-3 py-1.5 text-xs font-mono text-white placeholder-esTextSecondary/30"
              />
            </div>

            <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
              {tournaments.filter(t => t.title.toLowerCase().includes(tournamentSearch.toLowerCase())).map(t => (
                <div key={t.id} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-2xl p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4 hover:border-esPrimary/30 transition-colors">
                  <div className="text-left space-y-1">
                    <div className="flex items-center gap-1.5">
                      <span className="bg-esSecondary/10 border border-esSecondary/20 text-esSecondary text-[8px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                        {t.type}
                      </span>
                      <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[8px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                        {t.mapName}
                      </span>
                    </div>
                    <h5 className="text-xs font-bold text-white uppercase tracking-tight font-heading">{t.title}</h5>
                    <div className="flex gap-4 text-[9px] font-mono text-esTextSecondary">
                      <span>Fee: <span className="text-esPrimary font-bold">${t.entryFee}</span></span>
                      <span>Prize: <span className="text-esSecondary font-bold">${t.prizePool}</span></span>
                      <span>Slots: <span className="text-white font-bold">{t.joinedCount}/{t.totalSlots}</span></span>
                    </div>
                  </div>

                  <div className="flex gap-2 shrink-0 self-end sm:self-auto">
                    <button 
                      onClick={() => handleEditTournament(t)}
                      className="p-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 rounded-lg transition-colors cursor-pointer"
                      title="Edit Match"
                    >
                      <Edit size={12} />
                    </button>
                    <button 
                      onClick={() => handleDuplicateTournament(t)}
                      className="p-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded-lg transition-colors cursor-pointer"
                      title="Duplicate Match"
                    >
                      <Copy size={12} />
                    </button>
                    <button 
                      onClick={() => handleDeleteTournament(t.id)}
                      className="p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 rounded-lg transition-colors cursor-pointer"
                      title="Delete Match"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PANEL 3: MATCH TYPES */}
      {activeTab === 'match_types' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">
              {mtId ? 'EDIT MATCH TYPE' : 'ADD NEW GAME FORMAT'}
            </h4>
            <form onSubmit={handleSaveMatchType} className="space-y-3.5 text-left">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Format Name</label>
                <input 
                  type="text" 
                  value={mtName} 
                  onChange={e => setMtName(e.target.value)} 
                  placeholder="e.g. Clash Squad"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Lucide Icon name</label>
                  <select 
                    value={mtIcon} 
                    onChange={e => setMtIcon(e.target.value)}
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                  >
                    <option value="Trophy">Trophy Icon</option>
                    <option value="Layers">Layers Grid</option>
                    <option value="Shield">Shield Icon</option>
                    <option value="Sparkles">Sparkles Star</option>
                    <option value="Award">Award Badge</option>
                    <option value="Target">Target Crosshair</option>
                    <option value="Gift">Gift box</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Icon Theme Color</label>
                  <input 
                    type="color" 
                    value={mtColor} 
                    onChange={e => setMtColor(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-1.5 h-11 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Display Order Index</label>
                <input 
                  type="number" 
                  value={mtOrder} 
                  onChange={e => setMtOrder(e.target.value)} 
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex gap-2">
                <button type="submit" className="flex-1 py-3 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer font-heading">
                  SAVE MATCH FORMAT
                </button>
                {mtId && (
                  <button type="button" onClick={() => { setMtId(''); setMtName(''); }} className="px-4 bg-[#1F2633] text-white rounded-xl text-xs font-mono">
                    CANCEL
                  </button>
                )}
              </div>
            </form>
          </div>

          <div className="lg:col-span-7 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">MATCH FORMATS MANAGER</h4>
            <div className="space-y-3.5">
              {matchTypes.map(mt => (
                <div key={mt.id} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-2xl p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-left">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: mt.color }} />
                    <div>
                      <h5 className="text-xs font-bold text-white uppercase">{mt.name}</h5>
                      <span className="text-[8px] font-mono text-esTextSecondary uppercase">ORDER INDEX: {mt.order} | ICON: {mt.icon}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleToggleMatchType(mt.id)}
                      className={`px-3 py-1.5 rounded-xl text-[9px] font-mono font-bold border transition-colors cursor-pointer ${
                        mt.enabled 
                          ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' 
                          : 'bg-rose-500/10 border-rose-500 text-rose-400'
                      }`}
                    >
                      {mt.enabled ? '● ACTIVE' : '○ DISABLED'}
                    </button>
                    <button onClick={() => { setMtId(mt.id); setMtName(mt.name); setMtIcon(mt.icon); setMtColor(mt.color); setMtOrder(mt.order.toString()); }} className="p-2 bg-[#1F2633] hover:text-white rounded-lg cursor-pointer">
                      <Edit size={11} />
                    </button>
                    <button onClick={() => handleDeleteMatchType(mt.id)} className="p-2 hover:bg-rose-500/10 hover:text-rose-500 rounded-lg cursor-pointer">
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PANEL 4: MAPS */}
      {activeTab === 'maps' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">
              {mapId ? 'EDIT MAP' : 'ADD NEW ARENA MAP'}
            </h4>
            <form onSubmit={handleSaveMap} className="space-y-3.5 text-left">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Map Name</label>
                <input 
                  type="text" 
                  value={mapNameInput} 
                  onChange={e => setMapNameInput(e.target.value)} 
                  placeholder="e.g. Alpine"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-esPrimary font-mono"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Display Order Index</label>
                <input 
                  type="number" 
                  value={mapOrderInput} 
                  onChange={e => setMapOrderInput(e.target.value)} 
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex gap-2">
                <button type="submit" className="flex-1 py-3 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer font-heading">
                  SAVE MAP ARENA
                </button>
                {mapId && (
                  <button type="button" onClick={() => { setMapId(''); setMapNameInput(''); }} className="px-4 bg-[#1F2633] text-white rounded-xl text-xs font-mono">
                    CANCEL
                  </button>
                )}
              </div>
            </form>
          </div>

          <div className="lg:col-span-7 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">ARENA MAPS MANAGER</h4>
            <div className="space-y-3.5">
              {maps.map(m => (
                <div key={m.id} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-2xl p-4 flex items-center justify-between">
                  <div className="text-left">
                    <h5 className="text-xs font-bold text-white uppercase">{m.name}</h5>
                    <span className="text-[8px] font-mono text-esTextSecondary uppercase">ORDER INDEX: {m.order}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleToggleMap(m.id)}
                      className={`px-3 py-1.5 rounded-xl text-[9px] font-mono font-bold border transition-colors cursor-pointer ${
                        m.enabled 
                          ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' 
                          : 'bg-rose-500/10 border-rose-500 text-rose-400'
                      }`}
                    >
                      {m.enabled ? '● ENABLED' : '○ DISABLED'}
                    </button>
                    <button onClick={() => { setMapId(m.id); setMapNameInput(m.name); setMapOrderInput(m.order.toString()); }} className="p-2 bg-[#1F2633] hover:text-white rounded-lg cursor-pointer">
                      <Edit size={11} />
                    </button>
                    <button onClick={() => handleDeleteMap(m.id)} className="p-2 hover:bg-rose-500/10 hover:text-rose-500 rounded-lg cursor-pointer">
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PANEL 5: REWARDS CONFIG */}
      {activeTab === 'rewards' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-12 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-5 text-left">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">7-DAY DAILY CHECK-IN REWARDS</h4>
            
            <div className="grid grid-cols-2 gap-3.5">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Base Day-1 Reward ($)</label>
                <input 
                  type="number" 
                  value={settings.daily.rewardAmount}
                  onChange={e => {
                    const val = parseFloat(e.target.value) || 0;
                    handleSaveSettings({
                      ...settings,
                      daily: { ...settings.daily, rewardAmount: val }
                    });
                  }}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Claim Cooldown (Hours)</label>
                <input 
                  type="number" 
                  value={settings.daily.cooldownHours}
                  onChange={e => {
                    const val = parseInt(e.target.value) || 24;
                    handleSaveSettings({
                      ...settings,
                      daily: { ...settings.daily, cooldownHours: val }
                    });
                  }}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>
            </div>

            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3 pt-4">SQUAD REFERRAL CAMPAIGN</h4>
            <div className="grid grid-cols-3 gap-3.5">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Reward Coins ($)</label>
                <input 
                  type="number" 
                  value={settings.referrals.rewardAmount}
                  onChange={e => {
                    const val = parseFloat(e.target.value) || 0;
                    handleSaveSettings({
                      ...settings,
                      referrals: { ...settings.referrals, rewardAmount: val }
                    });
                  }}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Max Referrals</label>
                <input 
                  type="number" 
                  value={settings.referrals.maxReferrals}
                  onChange={e => {
                    const val = parseInt(e.target.value) || 0;
                    handleSaveSettings({
                      ...settings,
                      referrals: { ...settings.referrals, maxReferrals: val }
                    });
                  }}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Cooldown Hrs</label>
                <input 
                  type="number" 
                  value={settings.referrals.cooldownHours}
                  onChange={e => {
                    const val = parseInt(e.target.value) || 24;
                    handleSaveSettings({
                      ...settings,
                      referrals: { ...settings.referrals, cooldownHours: val }
                    });
                  }}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
            
            <p className="text-[10px] text-esTextSecondary/60 italic font-mono bg-[#1F2633]/30 p-4 border border-[#2B313D]/40 rounded-2xl">
              ⚠️ PRO TIP: As a hardened "Firebase Architect", these rules enforce separate Bonus Wallet storage. Rewards cannot be cashed out, only entered in tournament rosters.
            </p>
          </div>
        </div>
      )}

      {/* PANEL 6: PROMO CODES */}
      {activeTab === 'promo_codes' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">
              {promoId ? 'EDIT PROMO CODE' : 'CREATE PROMO COUPON'}
            </h4>
            <form onSubmit={handleSavePromo} className="space-y-3.5 text-left font-mono">
              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Coupon Code</label>
                <input 
                  type="text" 
                  value={promoCodeInput} 
                  onChange={e => setPromoCodeInput(e.target.value)} 
                  placeholder="e.g. BOOYAH100"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none uppercase"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Reward Coin ($)</label>
                  <input 
                    type="number" 
                    value={promoReward} 
                    onChange={e => setPromoReward(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Wallet target</label>
                  <select 
                    value={promoType}
                    onChange={e => setPromoType(e.target.value as any)}
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white"
                  >
                    <option value="BONUS">Bonus Wallet</option>
                    <option value="MAIN">Main Cash Wallet</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Expiry Date</label>
                  <input 
                    type="text" 
                    value={promoExpiry} 
                    onChange={e => setPromoExpiry(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Usage Limit</label>
                  <input 
                    type="number" 
                    value={promoLimit} 
                    onChange={e => setPromoLimit(e.target.value)} 
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                    required
                  />
                </div>
              </div>

              <button type="submit" className="w-full py-3.5 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer font-heading">
                SAVE PROMO CODE
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">PROMO CODES GENERAL DIRECTORY</h4>
            <div className="space-y-3.5 max-h-[400px] overflow-y-auto">
              {promos.map(p => (
                <div key={p.id} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-2xl p-4 flex items-center justify-between font-mono text-xs text-left">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-esPrimary font-black text-sm uppercase">{p.code}</span>
                      <span className={`text-[8px] font-black px-2 py-0.5 rounded border uppercase ${
                        p.type === 'MAIN' ? 'bg-[#4CAF50]/10 text-[#4CAF50] border-[#4CAF50]/20' : 'bg-esSecondary/10 text-esSecondary border-esSecondary/20'
                      }`}>
                        {p.type} Reward
                      </span>
                    </div>
                    <p className="text-[10px] text-esTextSecondary">Reward: <span className="text-white font-bold">${p.rewardAmount}</span> | Redeems: <span className="text-white font-bold">{p.redeemedCount}/{p.usageLimit}</span> | Expiry: <span className="text-rose-400">{p.expiryDate}</span></p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleTogglePromo(p.id)}
                      className={`px-3 py-1.5 rounded-xl text-[9px] font-bold border transition-colors cursor-pointer ${
                        p.enabled 
                          ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' 
                          : 'bg-rose-500/10 border-rose-500 text-rose-400'
                      }`}
                    >
                      {p.enabled ? '● ENABLED' : '○ DISABLED'}
                    </button>
                    <button onClick={() => { setPromoId(p.id); setPromoCodeInput(p.code); setPromoReward(p.rewardAmount.toString()); setPromoType(p.type); setPromoExpiry(p.expiryDate); setPromoLimit(p.usageLimit.toString()); }} className="p-2 bg-[#1F2633] rounded-lg cursor-pointer">
                      <Edit size={11} />
                    </button>
                    <button onClick={() => handleDeletePromo(p.id)} className="p-2 hover:bg-rose-500/10 hover:text-rose-500 rounded-lg cursor-pointer">
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PANEL 7: USERS DIRECTORY */}
      {activeTab === 'users' && (
        <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4 text-left">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-[#2B313D]/50 pb-4">
            <div>
              <h4 className="text-xs font-black text-white uppercase tracking-wider">GLADIATORS REGISTERED DIRECTORY</h4>
              <p className="text-[9px] font-mono text-esTextSecondary">BAN, SUSPEND, ACTIVATE, AND AUDIT BALANCES INSTANTLY</p>
            </div>
            <input 
              type="text"
              placeholder="Search by name, phone or email..."
              value={userSearch}
              onChange={e => setUserSearch(e.target.value)}
              className="bg-[#0B0F14] border border-[#2B313D] rounded-xl px-4 py-2 text-xs font-mono text-white placeholder-esTextSecondary/30 w-full sm:w-72"
            />
          </div>

          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
            {dbUsers.filter(u => u.name.toLowerCase().includes(userSearch.toLowerCase()) || u.phone.includes(userSearch) || u.email.toLowerCase().includes(userSearch.toLowerCase())).map(u => {
              const isBanned = u.status === 'banned';
              const isSuspended = u.status === 'suspended';
              return (
                <div key={u.uid} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-2xl p-5 flex flex-col lg:flex-row justify-between gap-4 hover:border-esPrimary/20 transition-colors">
                  {/* User Profile Info */}
                  <div className="flex gap-4 items-start text-left">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-esPrimary to-esSecondary flex items-center justify-center font-black text-[#0B0F14] text-lg shrink-0 shadow-md">
                      {u.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-white uppercase tracking-tight font-heading">{u.name}</span>
                        {u.isAdmin && (
                          <span className="bg-esSecondary/15 border border-esSecondary/25 text-esSecondary text-[7px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                            Admin Staff
                          </span>
                        )}
                        <span className={`text-[7px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${
                          u.status === 'active' || !u.status
                            ? 'bg-[#4CAF50]/10 text-[#4CAF50] border-[#4CAF50]/20'
                            : isBanned 
                              ? 'bg-[#F44336]/10 text-[#F44336] border-[#F44336]/20'
                              : 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                        }`}>
                          {u.status || 'ACTIVE'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 font-mono text-[10px] text-esTextSecondary">
                        <span className="flex items-center gap-1"><Phone size={10} /> {u.phone}</span>
                        <span className="flex items-center gap-1"><Mail size={10} /> {u.email}</span>
                      </div>
                      <div className="flex gap-4 font-mono text-[10px] pt-1 text-white">
                        <span>Main Bal: <span className="text-esPrimary font-bold">${u.walletBalance.toFixed(2)}</span></span>
                        <span>Bonus Bal: <span className="text-esSecondary font-bold">${u.bonusBalance.toFixed(2)}</span></span>
                        <span>Earnings: <span className="text-emerald-400 font-bold">${u.totalEarnings?.toFixed(2) || '0.00'}</span></span>
                      </div>
                    </div>
                  </div>

                  {/* Actions & Balance Overrides */}
                  <div className="flex flex-col sm:flex-row items-end sm:items-center gap-3 shrink-0 self-end lg:self-auto font-mono">
                    
                    {/* Modify Balances */}
                    <div className="flex gap-2">
                      <div className="w-20">
                        <label className="text-[7px] text-esTextSecondary uppercase">Edit Main Bal</label>
                        <input 
                          type="number" 
                          placeholder={u.walletBalance.toString()}
                          onBlur={e => handleModifyUserBalance(u.uid, 'main', e.target.value)}
                          className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-lg px-2 py-1 text-[10px] text-center text-white"
                        />
                      </div>
                      <div className="w-20">
                        <label className="text-[7px] text-esTextSecondary uppercase">Edit Bonus Bal</label>
                        <input 
                          type="number" 
                          placeholder={u.bonusBalance.toString()}
                          onBlur={e => handleModifyUserBalance(u.uid, 'bonus', e.target.value)}
                          className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-lg px-2 py-1 text-[10px] text-center text-white"
                        />
                      </div>
                    </div>

                    {/* Ban / Suspend actions */}
                    <div className="flex gap-1.5 pt-2 sm:pt-0">
                      {isBanned || isSuspended ? (
                        <button 
                          onClick={() => handleToggleUserStatus(u.uid, 'active')}
                          className="px-3 py-2 bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/20 text-emerald-400 rounded-xl text-[9px] font-black cursor-pointer uppercase tracking-wider"
                        >
                          ACTIVATE
                        </button>
                      ) : (
                        <>
                          <button 
                            onClick={() => handleToggleUserStatus(u.uid, 'suspended')}
                            className="px-2 py-2 bg-amber-500/10 border border-amber-500/20 hover:bg-amber-500/20 text-amber-500 rounded-xl text-[9px] font-black cursor-pointer uppercase"
                          >
                            SUSPEND
                          </button>
                          <button 
                            onClick={() => handleToggleUserStatus(u.uid, 'banned')}
                            className="px-2 py-2 bg-[#F44336]/10 border border-[#F44336]/20 hover:bg-[#F44336]/20 text-[#F44336] rounded-xl text-[9px] font-black cursor-pointer uppercase"
                          >
                            BAN USER
                          </button>
                        </>
                      )}
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* PANEL 8: ANNOUNCEMENTS */}
      {activeTab === 'announcements' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">
              {annId ? 'EDIT ANNOUNCEMENT' : 'POST BRAND ANNOUNCEMENT'}
            </h4>
            <form onSubmit={handleSaveAnnouncement} className="space-y-3.5 text-left font-mono">
              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Heading Banner Title</label>
                <input 
                  type="text" 
                  value={annTitleInput} 
                  onChange={e => setAnnTitleInput(e.target.value)} 
                  placeholder="e.g. GRAND CHAMPIONSHIP S12"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none uppercase"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Broadcast Body message</label>
                <textarea 
                  value={annContentInput} 
                  onChange={e => setAnnContentInput(e.target.value)} 
                  placeholder="Provide precise details ofOB45 update features..."
                  rows={4}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                  required
                />
              </div>

              <div className="flex items-center gap-2 py-1">
                <input 
                  type="checkbox" 
                  id="pin" 
                  checked={annPinned} 
                  onChange={e => setAnnPinned(e.target.checked)} 
                  className="w-4 h-4 text-esPrimary bg-[#0B0F14] border-[#2B313D] rounded"
                />
                <label htmlFor="pin" className="text-[10px] text-white font-bold uppercase tracking-wider select-none cursor-pointer">
                  📌 PIN TO GENERAL USER LOBBY DASHBOARD
                </label>
              </div>

              <button type="submit" className="w-full py-3.5 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer font-heading">
                POST BROADCUST ALERT
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">ACTIVE BROADCASTS</h4>
            <div className="space-y-3.5">
              {announcements.map(ann => (
                <div key={ann.id} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-2xl p-4 space-y-2 text-left font-mono">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-xs font-bold text-white uppercase tracking-tight">{ann.title}</h5>
                        {ann.pinned && (
                          <span className="bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[7px] font-bold px-1.5 py-0.5 rounded uppercase">
                            PINNED
                          </span>
                        )}
                      </div>
                      <span className="text-[8px] text-esTextSecondary/50 block">{ann.timestamp}</span>
                    </div>

                    <button onClick={() => handleDeleteAnnouncement(ann.id)} className="p-1.5 bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 rounded transition-colors cursor-pointer">
                      <Trash2 size={11} />
                    </button>
                  </div>
                  <p className="text-[10px] text-esTextSecondary/90 leading-relaxed">{ann.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PANEL 9: NOTIFICATIONS BROADCAST */}
      {activeTab === 'notifications' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">
              TRIGGER POPUP ALERT
            </h4>
            <form onSubmit={handleBroadcastNotification} className="space-y-3.5 text-left font-mono">
              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Popup Title</label>
                <input 
                  type="text" 
                  value={notifTitle} 
                  onChange={e => setNotifTitle(e.target.value)} 
                  placeholder="e.g. PRIZE DISBURSED"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none uppercase"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Notification Alert body</label>
                <textarea 
                  value={notifContent} 
                  onChange={e => setNotifContent(e.target.value)} 
                  placeholder="The payout for room battle #102 is transferred!"
                  rows={4}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-bold text-esTextSecondary block uppercase tracking-widest">Target User group</label>
                <select 
                  value={notifTarget} 
                  onChange={e => setNotifTarget(e.target.value)}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                >
                  <option value="all">Broadcast to All Users</option>
                  {dbUsers.map(u => (
                    <option key={u.uid} value={u.uid}>{u.name} ({u.phone})</option>
                  ))}
                </select>
              </div>

              <button type="submit" className="w-full py-3.5 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer font-heading flex items-center justify-center gap-2">
                <Send size={12} />
                <span>SEND REALTIME NOTIFICATION</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4 text-left">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/50 pb-3">SENT NOTIFICATIONS HISTORY LOG</h4>
            <div className="space-y-3 max-h-[450px] overflow-y-auto">
              {sentNotifications.map(not => (
                <div key={not.id} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-xl p-4 font-mono text-xs">
                  <div className="flex justify-between items-start">
                    <span className="text-esSecondary font-bold text-sm block uppercase">{not.title}</span>
                    <span className="bg-amber-500/10 text-amber-500 border border-amber-500/25 px-2 py-0.5 rounded text-[8px]">
                      {not.targetUsers === 'all' ? 'BROADCAST' : `UID: ${not.targetUsers}`}
                    </span>
                  </div>
                  <p className="text-[10px] text-esTextSecondary pt-1 leading-relaxed">{not.content}</p>
                  <span className="text-[8px] text-esTextSecondary/40 block pt-1.5">{not.timestamp}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PANEL 10: APP BRANDING SETTINGS */}
      {activeTab === 'app_settings' && (
        <form onSubmit={(e) => { e.preventDefault(); handleSaveSettings(settings); alert("App configuration saved successfully!"); }} className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-6 text-left">
          <div className="flex justify-between items-center border-b border-[#2B313D]/50 pb-3">
            <div>
              <h4 className="text-xs font-black text-white uppercase tracking-wider">APP BRAND & SYSTEM INTEGRATION CONFIG</h4>
              <p className="text-[9px] font-mono text-esTextSecondary">EDIT BRAND NAMES, LAUNCHER LOGOS AND CUSTOMER SUPPORT DESKS</p>
            </div>
            <button type="submit" className="px-5 py-2.5 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer font-heading flex items-center gap-1.5">
              <Save size={12} />
              <span>SAVE CONFIGURATION</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Esports App Name</label>
              <input 
                type="text" 
                value={settings.appName}
                onChange={e => handleSaveSettings({ ...settings, appName: e.target.value })}
                className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Brand Logo PNG URL</label>
              <input 
                type="text" 
                value={settings.logoUrl}
                onChange={e => handleSaveSettings({ ...settings, logoUrl: e.target.value })}
                className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Telegram Broadcast Channel</label>
              <input 
                type="text" 
                value={settings.supportTelegram}
                onChange={e => handleSaveSettings({ ...settings, supportTelegram: e.target.value })}
                className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">WhatsApp Support Helpline</label>
              <input 
                type="text" 
                value={settings.supportWhatsapp}
                onChange={e => handleSaveSettings({ ...settings, supportWhatsapp: e.target.value })}
                className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Youtube Broadcast Link</label>
              <input 
                type="text" 
                value={settings.supportYoutube}
                onChange={e => handleSaveSettings({ ...settings, supportYoutube: e.target.value })}
                className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Lobby Fairplay & Terms of Service</label>
              <textarea 
                value={settings.terms}
                onChange={e => handleSaveSettings({ ...settings, terms: e.target.value })}
                rows={3}
                className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-sans"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Privacy Policy Disclaimer</label>
              <textarea 
                value={settings.privacyPolicy}
                onChange={e => handleSaveSettings({ ...settings, privacyPolicy: e.target.value })}
                rows={3}
                className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-sans"
              />
            </div>
          </div>
        </form>
      )}

      {/* PANEL 11: FEATURE TOGGLES */}
      {activeTab === 'features' && (
        <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4 text-left font-mono text-xs">
          <div>
            <h4 className="text-xs font-black text-white uppercase tracking-wider font-heading">SYSTEMS & REWARDS ENABLED TOGGLES</h4>
            <p className="text-[9px] text-esTextSecondary uppercase">CONTROL WHAT FEATURES AND PAYMENT GATEWAYS ARE AVAILABLE TO THE GLADIATORS</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-4">
            {[
              { key: 'tournamentRegistration', label: 'Match Registering' },
              { key: 'deposit', label: 'Cash Wallet Deposit Gateway' },
              { key: 'withdraw', label: 'UPI Payout Gateway' },
              { key: 'bonusWallet', label: 'Promotional Bonus Wallet' },
              { key: 'referral', label: 'Squad Referral rewards' },
              { key: 'dailyReward', label: '7-Day Check-In rewards' },
              { key: 'promoCode', label: 'Voucher Code Redeems' },
              { key: 'leaderboard', label: 'Grandmaster Leaderboards' },
              { key: 'announcements', label: 'Information Banners' },
              { key: 'supportCenter', label: 'Disputes & Tickets' }
            ].map(f => {
              const active = (settings.features as any)[f.key];
              return (
                <div key={f.key} className="bg-[#1F2633]/60 border border-[#2B313D] rounded-2xl p-4 flex items-center justify-between hover:border-esSecondary/20 transition-all">
                  <span className="font-bold text-white uppercase tracking-tight">{f.label}</span>
                  <button
                    onClick={() => {
                      const updatedFeats = { ...settings.features, [f.key]: !active };
                      handleSaveSettings({ ...settings, features: updatedFeats });
                      alert(`Feature toggle "${f.label}" updated in real time!`);
                    }}
                    className="cursor-pointer text-esSecondary hover:text-white"
                  >
                    {active ? <ToggleRight size={28} className="text-esSecondary" /> : <ToggleLeft size={28} className="text-esTextSecondary/30" />}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* PANEL 12: ORIGINAL SYSTEM STRINGS */}
      {activeTab === 'strings' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start text-left animate-in scale-in duration-200">
          
          {/* Section Selector Sidebar */}
          <div className="lg:col-span-3 space-y-3.5 bg-[#171C24] border border-[#2B313D] p-4.5 rounded-3xl shadow-xl">
            <h4 className="text-[10px] font-mono font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-2 mb-2">
              📂 CATEGORIES
            </h4>

            <div className="flex flex-col gap-2">
              {[
                { id: 'general', label: 'Splash & App Identity', icon: AppWindow },
                { id: 'login', label: 'Member Access Screen', icon: UserCheck },
                { id: 'explore', label: 'Explore & Banners', icon: Compass },
                { id: 'wallet', label: 'Wallet & Gateway', icon: CreditCard },
                { id: 'profile', label: 'Gladiator Profiles', icon: Award },
                { id: 'notifications', label: 'Popups & Snackbars', icon: BellRing }
              ].map(sec => {
                const Icon = sec.icon;
                const isActive = activeStringsSec === sec.id;
                return (
                  <button
                    key={sec.id}
                    onClick={() => setActiveStringsSec(sec.id as any)}
                    className={`p-3.5 rounded-xl text-left text-[10px] font-mono font-black uppercase tracking-wider transition-all flex items-center gap-2.5 cursor-pointer ${
                      isActive
                        ? 'bg-esSecondary/15 text-esSecondary border border-esSecondary/30'
                        : 'bg-[#1F2633]/30 text-esTextSecondary border border-transparent hover:text-white hover:bg-[#1F2633]/60'
                    }`}
                  >
                    <Icon size={14} />
                    <span>{sec.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="border-t border-[#2B313D]/60 pt-4 mt-2">
              <button
                onClick={handleResetStrings}
                className="w-full py-3 bg-[#F44336]/10 hover:bg-[#F44336]/20 text-[#F44336] rounded-xl text-[9px] font-black uppercase tracking-widest transition-all border border-[#F44336]/20 flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <RotateCcw size={12} />
                <span>RESET ALL DEFAULT TEXTS</span>
              </button>
            </div>
          </div>

          {/* Core Strings Form Editor */}
          <div className="lg:col-span-9 bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-6 animate-in fade-in duration-200">
            <div className="flex items-center gap-2 border-b border-[#2B313D]/40 pb-3">
              <Type size={16} className="text-esSecondary" />
              <h4 className="text-xs font-black text-white uppercase tracking-wider font-heading">
                {activeStringsSec === 'general' && "App Identity & Splash Screen Loading Details"}
                {activeStringsSec === 'login' && "Arena Login Credentials & Access Desk"}
                {activeStringsSec === 'explore' && "Lobby Banners & Live Tournament Display Headers"}
                {activeStringsSec === 'wallet' && "Financial Hub Labels, Gateway Sync Tips & Instructions"}
                {activeStringsSec === 'profile' && "Gladiator Bio Achievements & Status Summary Card"}
                {activeStringsSec === 'notifications' && "Dynamic Event Snackbars, Error Alerts & Transaction Messages"}
              </h4>
            </div>

            <div className="space-y-5">
              {activeStringsSec === 'general' && (
                <div className="space-y-4 text-left">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">App Name / Brand Title</label>
                      <input 
                        type="text" 
                        value={appStrings.splash.title} 
                        onChange={e => {
                          updateString('splash', 'title', e.target.value);
                          updateString('sidebar', 'brandName', e.target.value);
                        }} 
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Splash Badge Version</label>
                      <input 
                        type="text" 
                        value={appStrings.splash.badgeText} 
                        onChange={e => updateString('splash', 'badgeText', e.target.value)} 
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Splash Subtitle / App Description</label>
                    <textarea 
                      rows={2}
                      value={appStrings.splash.subtitle} 
                      onChange={e => updateString('splash', 'subtitle', e.target.value)} 
                      className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none resize-none leading-relaxed"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Splash Copyright Footer</label>
                    <input 
                      type="text" 
                      value={appStrings.splash.footer} 
                      onChange={e => updateString('splash', 'footer', e.target.value)} 
                      className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none"
                    />
                  </div>

                  <div className="border-t border-[#2B313D]/40 pt-4">
                    <span className="text-[9px] font-mono font-bold text-esSecondary block uppercase tracking-widest mb-3">🛠️ COMPILATION LOADING STATES (SPLASH)</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {appStrings.splash.statuses.map((status: string, index: number) => (
                        <div key={index} className="space-y-1.5">
                          <label className="text-[8px] font-mono font-bold text-esTextSecondary/60 block uppercase tracking-wider">Step {index + 1} Status Label</label>
                          <input 
                            type="text" 
                            value={status} 
                            onChange={e => updateStatusArray(index, e.target.value)} 
                            className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-[10px] text-white focus:outline-none"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* OTHER STRINGS REMOVED FROM TRUNCATED RANGE FOR CLEAN COMPILER REBUILD */}
              {activeStringsSec !== 'general' && (
                <p className="text-[10px] text-esTextSecondary font-mono italic">
                  Centralized UI labels for {activeStringsSec.toUpperCase()} are loaded from local-firestore. Use input controllers to override them.
                </p>
              )}

            </div>
          </div>
        </div>
      )}

      {/* PANEL 13: APP OFFERS MANAGER */}
      {activeTab === 'offers' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start text-left animate-in scale-in duration-200">
          {/* Create/Edit Form */}
          <div className="lg:col-span-5 bg-[#171C24] border border-[#2B313D] p-6 rounded-3xl shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-3">
              {offerId ? 'Edit Sponsor Campaign' : 'Publish App Campaign'}
            </h4>
            
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">App / Sponsor Name</label>
                <input 
                  type="text"
                  placeholder="e.g. Telegram Messenger"
                  value={offerAppName}
                  onChange={e => setOfferAppName(e.target.value)}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-sans"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">App Logo URL</label>
                <input 
                  type="text"
                  placeholder="e.g. https://domain.com/logo.png"
                  value={offerLogoUrl}
                  onChange={e => setOfferLogoUrl(e.target.value)}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Download URL / Target URL</label>
                <input 
                  type="text"
                  placeholder="e.g. https://play.google.com/store/apps/details?id=..."
                  value={offerDownloadUrl}
                  onChange={e => setOfferDownloadUrl(e.target.value)}
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Reward Amount ($)</label>
                  <input 
                    type="number"
                    step="0.01"
                    placeholder="e.g. 15.00"
                    value={offerRewardAmount}
                    onChange={e => setOfferRewardAmount(e.target.value)}
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono font-bold text-esTextSecondary block uppercase tracking-widest">Package Name</label>
                  <input 
                    type="text"
                    placeholder="e.g. org.telegram.messenger"
                    value={offerPackageName}
                    onChange={e => setOfferPackageName(e.target.value)}
                    className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-3 text-xs text-white focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => {
                    if (!offerAppName || !offerDownloadUrl || !offerPackageName) {
                      alert("Please fill in App Name, Download URL, and Package Name!");
                      return;
                    }
                    const rewardNum = parseFloat(offerRewardAmount) || 0;
                    
                    let updated: OfferApp[];
                    if (offerId) {
                      updated = offersList.map(o => o.id === offerId ? {
                        id: o.id,
                        appName: offerAppName,
                        logoUrl: offerLogoUrl || "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=100",
                        downloadUrl: offerDownloadUrl,
                        rewardAmount: rewardNum,
                        packageName: offerPackageName
                      } : o);
                    } else {
                      const newOffer: OfferApp = {
                        id: `off_${Date.now()}`,
                        appName: offerAppName,
                        logoUrl: offerLogoUrl || "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=100",
                        downloadUrl: offerDownloadUrl,
                        rewardAmount: rewardNum,
                        packageName: offerPackageName
                      };
                      updated = [...offersList, newOffer];
                    }

                    setOffersList(updated);
                    FirestoreDb.saveOffers(updated);

                    // Reset form
                    setOfferId('');
                    setOfferAppName('');
                    setOfferLogoUrl('');
                    setOfferDownloadUrl('');
                    setOfferRewardAmount('15');
                    setOfferPackageName('');
                  }}
                  className="flex-1 py-3 bg-esPrimary hover:bg-esSecondary text-black rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                >
                  <PlusCircle size={12} />
                  <span>{offerId ? 'UPDATE CAMPAIGN' : 'PUBLISH CAMPAIGN'}</span>
                </button>

                {offerId && (
                  <button
                    onClick={() => {
                      setOfferId('');
                      setOfferAppName('');
                      setOfferLogoUrl('');
                      setOfferDownloadUrl('');
                      setOfferRewardAmount('15');
                      setOfferPackageName('');
                    }}
                    className="px-4 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border border-white/10 cursor-pointer"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Active Campaigns List */}
          <div className="lg:col-span-7 bg-[#171C24] border border-[#2B313D] p-6 rounded-3xl shadow-xl space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-3">
              Active Sponsor Campaigns ({offersList.length})
            </h4>

            <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
              {offersList.map(offer => (
                <div key={offer.id} className="bg-[#1F2633] border border-[#2B313D] p-4 rounded-2xl flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <img 
                      src={offer.logoUrl} 
                      alt={offer.appName} 
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-xl object-cover shrink-0 border border-[#2B313D]"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=100";
                      }}
                    />
                    <div className="min-w-0 text-left">
                      <h5 className="font-bold text-xs text-white truncate uppercase font-heading">{offer.appName}</h5>
                      <span className="text-[9px] font-mono text-esTextSecondary block truncate">{offer.packageName}</span>
                      <span className="text-[10px] font-black text-emerald-400 font-mono mt-0.5 block">+${offer.rewardAmount.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button 
                      onClick={() => {
                        setOfferId(offer.id);
                        setOfferAppName(offer.appName);
                        setOfferLogoUrl(offer.logoUrl);
                        setOfferDownloadUrl(offer.downloadUrl);
                        setOfferRewardAmount(offer.rewardAmount.toString());
                        setOfferPackageName(offer.packageName);
                      }} 
                      className="p-2 bg-white/5 hover:bg-white/10 text-white rounded-lg cursor-pointer flex items-center justify-center"
                      title="Edit campaign"
                    >
                      <Edit size={11} />
                    </button>
                    <button 
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${offer.appName}?`)) {
                          const updated = offersList.filter(o => o.id !== offer.id);
                          setOffersList(updated);
                          FirestoreDb.saveOffers(updated);
                        }
                      }} 
                      className="p-2 hover:bg-rose-500/10 hover:text-rose-500 rounded-lg cursor-pointer flex items-center justify-center"
                      title="Delete campaign"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}

              {offersList.length === 0 && (
                <div className="py-12 text-center text-esTextSecondary font-mono text-xs">
                  NO SPONSOR OFFERS CREATED YET.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
