import React, { useState, useEffect, useCallback } from 'react';
import { 
  Sparkles, Smartphone, CheckCircle, ExternalLink, Gift, DollarSign, ArrowUpRight, Award, ShieldCheck, Loader2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { OfferApp, UserProfile } from '../types';
import { FirestoreDb } from '../dbStore';

interface EarnTabProps {
  userProfile: UserProfile;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  onAddNotification: (msg: string) => void;
}

export default function EarnTab({
  userProfile,
  setUserProfile,
  onAddNotification
}: EarnTabProps) {
  const [offers, setOffers] = useState<OfferApp[]>([]);
  const [completedOfferIds, setCompletedOfferIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('AST_COMPLETED_OFFERS');
    return saved ? JSON.parse(saved) : [];
  });

  const [verifyingOffer, setVerifyingOffer] = useState<OfferApp | null>(null);
  const [verificationProgress, setVerificationProgress] = useState(0);

  // Load offers from dbStore
  useEffect(() => {
    const loadedOffers = FirestoreDb.getOffers();
    setOffers(loadedOffers);

    // Sync database updates in real-time
    const handleStorageChange = () => {
      setOffers(FirestoreDb.getOffers());
    };
    window.addEventListener('storage_change', handleStorageChange);
    return () => window.removeEventListener('storage_change', handleStorageChange);
  }, []);

  // Save completed offer IDs
  useEffect(() => {
    localStorage.setItem('AST_COMPLETED_OFFERS', JSON.stringify(completedOfferIds));
  }, [completedOfferIds]);

  // Handle offer completion simulation
  const handleStartOffer = (offer: OfferApp) => {
    if (completedOfferIds.includes(offer.id)) return;

    // Open download link in a new tab
    window.open(offer.downloadUrl, '_blank', 'noopener,noreferrer');

    // Trigger verification sequence
    setVerifyingOffer(offer);
    setVerificationProgress(0);
  };

  const handleCompleteOffer = useCallback((offer: OfferApp) => {
    // Add rewards to wallet balance
    setUserProfile(prev => {
      const bonusReward = offer.rewardAmount;
      const updatedProfile = {
        ...prev,
        bonusBalance: prev.bonusBalance + bonusReward,
        totalEarnings: prev.totalEarnings + bonusReward,
      };
      return updatedProfile;
    });

    setCompletedOfferIds(prev => [...prev, offer.id]);
    setVerifyingOffer(null);

    // Dynamic celebration!
    confetti({
      particleCount: 120,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FF8A00', '#FFC107', '#4CAF50']
    });

    onAddNotification(`Congratulations! You earned $${offer.rewardAmount.toFixed(2)} bonus for installing ${offer.appName}.`);
  }, [setUserProfile, onAddNotification]);

  useEffect(() => {
    if (!verifyingOffer) return;

    const interval = setInterval(() => {
      setVerificationProgress(prev => {
        const next = prev + 10;
        if (next >= 100) {
          clearInterval(interval);
        }
        return Math.min(next, 100);
      });
    }, 400);

    return () => clearInterval(interval);
  }, [verifyingOffer]);

  useEffect(() => {
    if (verificationProgress === 100 && verifyingOffer) {
      handleCompleteOffer(verifyingOffer);
    }
  }, [verificationProgress, verifyingOffer, handleCompleteOffer]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300 pb-12">
      {/* Immersive Welcome Banner */}
      <div className="bg-gradient-to-r from-[#22C55E]/15 via-[#1F2633] to-[#171C24] border border-emerald-500/25 rounded-[32px] p-8 text-left relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-full bg-gradient-to-l from-emerald-500/5 to-transparent pointer-events-none" />
        <div className="absolute top-[-50%] right-[-10%] w-[350px] h-[350px] bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-2xl space-y-4 relative z-10">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[9px] font-mono font-black px-3 py-1 rounded-full uppercase tracking-widest">
              🔥 CASH ZONE ACTIVE
            </span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>
          
          <h1 className="text-3xl md:text-4xl font-black text-white tracking-tight leading-none uppercase font-heading">
            AST'S ARENA <span className="text-emerald-400">SPONSOR OFFERS</span>
          </h1>
          
          <p className="text-esTextSecondary text-xs md:text-sm leading-relaxed font-sans font-medium max-w-xl">
            Earn extra bonus cash directly into your wallet! Simply download and open our sponsors' official mobile apps below. Your progress is verified automatically.
          </p>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 pt-2 max-w-lg">
            <div className="bg-[#171C24]/90 border border-white/5 rounded-2xl p-4 flex flex-col justify-center">
              <span className="text-[9px] font-mono text-esTextSecondary block uppercase tracking-wider">Your Bonus Bal</span>
              <span className="text-lg font-black text-emerald-400 font-mono block mt-0.5">${userProfile.bonusBalance.toFixed(2)}</span>
            </div>
            <div className="bg-[#171C24]/90 border border-white/5 rounded-2xl p-4 flex flex-col justify-center">
              <span className="text-[9px] font-mono text-esTextSecondary block uppercase tracking-wider">Offers Completed</span>
              <span className="text-lg font-black text-white font-mono block mt-0.5">{completedOfferIds.length} / {offers.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: List of offers */}
        <div className="lg:col-span-2 space-y-4 text-left">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-white tracking-widest uppercase font-heading flex items-center gap-2">
              <Smartphone size={16} className="text-emerald-400" />
              Sponsor Apps Available
            </h2>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
              {offers.filter(o => !completedOfferIds.includes(o.id)).length} UNCLAIMED
            </span>
          </div>

          {offers.length === 0 ? (
            <div className="bg-[#171C24]/60 border border-[#2B313D] rounded-3xl p-12 text-center space-y-4">
              <Gift size={48} className="text-esTextSecondary mx-auto opacity-30" />
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white uppercase">No Sponsor Apps Published</h3>
                <p className="text-xs text-esTextSecondary">Sponsor campaigns are currently offline. Check back soon!</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {offers.map(offer => {
                const isCompleted = completedOfferIds.includes(offer.id);
                return (
                  <div 
                    key={offer.id} 
                    className={`bg-[#1F2633] border rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 relative overflow-hidden group ${
                      isCompleted 
                        ? 'border-emerald-500/10 opacity-70' 
                        : 'border-[#2B313D] hover:border-emerald-500/40 hover:shadow-[0_8px_30px_rgb(0,0,0,0.4)]'
                    }`}
                  >
                    {isCompleted && (
                      <div className="absolute top-2 right-2 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-[8px] font-bold font-mono px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle size={8} /> COMPLETED
                      </div>
                    )}

                    <div className="flex items-start gap-4">
                      {/* App Logo */}
                      <div className="w-14 h-14 rounded-2xl overflow-hidden bg-[#171C24] border border-[#2B313D] shrink-0 relative flex items-center justify-center">
                        <img 
                          src={offer.logoUrl} 
                          alt={offer.appName} 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=100';
                          }}
                        />
                      </div>

                      {/* App Title & Package */}
                      <div className="space-y-1 min-w-0">
                        <h3 className="font-bold text-sm text-white truncate font-heading group-hover:text-emerald-400 transition-colors uppercase">
                          {offer.appName}
                        </h3>
                        <p className="text-[10px] font-mono text-esTextSecondary truncate">
                          {offer.packageName}
                        </p>
                        <div className="pt-1 flex items-center gap-1.5">
                          <span className="text-xs font-black text-emerald-400 font-mono">
                            +${offer.rewardAmount.toFixed(2)}
                          </span>
                          <span className="text-[8px] font-bold uppercase tracking-wider text-white/40 px-1.5 py-0.5 rounded bg-white/5 font-mono">
                            Cash Bonus
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 mt-auto">
                      {isCompleted ? (
                        <button 
                          disabled 
                          className="w-full py-2.5 rounded-xl bg-emerald-500/5 text-emerald-400/60 border border-emerald-500/10 text-[10px] font-black uppercase font-mono tracking-wider flex items-center justify-center gap-1.5 cursor-not-allowed"
                        >
                          <CheckCircle size={12} /> Claimed Successfully
                        </button>
                      ) : (
                        <button 
                          onClick={() => handleStartOffer(offer)}
                          className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-[10px] font-black uppercase font-mono tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                        >
                          <span>Install & Earn</span>
                          <ExternalLink size={12} />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right column: Info guidelines & instructions */}
        <div className="space-y-6 text-left">
          {/* Rules / Guideline Card */}
          <div className="bg-[#171C24]/80 border border-[#2B313D] rounded-3xl p-6 space-y-4">
            <h3 className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
              <Gift size={15} className="text-emerald-400" />
              Campaign Guidelines
            </h3>
            
            <div className="space-y-4 text-xs font-medium text-esTextSecondary">
              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold font-mono flex items-center justify-center shrink-0">1</span>
                <p className="leading-relaxed">Click "Install & Earn" button to be redirected to our sponsor's page or platform catalog.</p>
              </div>
              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold font-mono flex items-center justify-center shrink-0">2</span>
                <p className="leading-relaxed">Verify that you install the exact app matching the package name correctly.</p>
              </div>
              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold font-mono flex items-center justify-center shrink-0">3</span>
                <p className="leading-relaxed">Keep the application active for at least 1-2 minutes to receive your reward.</p>
              </div>
              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold font-mono flex items-center justify-center shrink-0">4</span>
                <p className="leading-relaxed">Rewards are processed instantly as wallet bonus points usable for entering custom matches.</p>
              </div>
            </div>

            <div className="pt-2 border-t border-[#2B313D] flex items-center gap-2.5 text-[10px] font-bold text-white/50">
              <ShieldCheck size={14} className="text-emerald-400" />
              <span>Verified Ast's Arena Safety Engine</span>
            </div>
          </div>
        </div>
      </div>

      {/* Futuristic Verification Modal Overlay */}
      {verifyingOffer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className="bg-[#171C24] border border-[#2B313D] max-w-md w-full rounded-3xl p-6 text-center space-y-6 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-yellow-500 to-emerald-500 animate-pulse" />

            <div className="space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/35 flex items-center justify-center relative">
                <Loader2 size={28} className="text-emerald-400 animate-spin" />
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-black text-white uppercase tracking-tight font-heading">
                  Verifying Installation
                </h3>
                <p className="text-xs text-esTextSecondary max-w-xs mx-auto">
                  Connecting to our network API node to check installation matching package <span className="text-white font-mono">{verifyingOffer.packageName}</span>...
                </p>
              </div>
            </div>

            {/* Custom Progress Bar */}
            <div className="space-y-2 text-left">
              <div className="flex justify-between items-center text-[10px] font-mono font-bold text-esTextSecondary">
                <span>API MATCH SEQUENCE</span>
                <span className="text-emerald-400">{verificationProgress}%</span>
              </div>
              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-300 ease-out shadow-[0_0_8px_rgba(16,185,129,0.5)]"
                  style={{ width: `${verificationProgress}%` }}
                />
              </div>
            </div>

            <div className="text-[10px] font-mono text-white/40 flex items-center justify-center gap-1.5 bg-[#0F131A] py-2 rounded-xl">
              <ShieldCheck size={12} className="text-emerald-400" />
              SECURE HANDSHAKE VERIFIED
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
