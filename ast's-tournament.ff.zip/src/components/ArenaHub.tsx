import React, { useState, useEffect } from 'react';
import { 
  Gift, Share2, Calendar, Award, Sparkles, TrendingUp, Wallet, 
  HelpCircle, Send, Star, MessageSquare, AlertTriangle, 
  History, BookOpen, Info, Copy, CheckCircle2, RefreshCw, Trophy
} from 'lucide-react';
import { UserProfile, Transaction, Tournament } from '../types';
import { FirestoreDb } from '../dbStore';

interface ArenaHubProps {
  userProfile: UserProfile;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  notifications: string[];
  setNotifications: React.Dispatch<React.SetStateAction<string[]>>;
  tournaments: Tournament[];
  favoriteIds: string[];
  setFavoriteIds: React.Dispatch<React.SetStateAction<string[]>>;
}

interface ClaimHistoryItem {
  id: string;
  type: 'DAILY' | 'REFERRAL';
  amount: number;
  description: string;
  timestamp: string;
}

interface SupportTicket {
  id: string;
  subject: string;
  category: string;
  description: string;
  status: 'PENDING' | 'RESOLVED';
  timestamp: string;
}

interface FeedbackItem {
  id: string;
  rating: number;
  comment: string;
  timestamp: string;
}

export default function ArenaHub({
  userProfile,
  setUserProfile,
  transactions,
  setTransactions,
  notifications,
  setNotifications,
  tournaments,
  favoriteIds,
  setFavoriteIds
}: ArenaHubProps) {
  const settings = FirestoreDb.getSettings();

  // Navigation tabs inside Arena Hub
  const [activeSubTab, setActiveSubTab] = useState<'rewards' | 'referral' | 'support' | 'rules'>('rewards');

  // --- REFERRAL STATE ---
  const userReferralCode = `AST-${userProfile.name.toUpperCase().replace(/\s+/g, '-')}-${userProfile.uid.split('_')[1] || '777'}`;
  const [friendReferralCode, setFriendReferralCode] = useState('');
  const [copiedReferral, setCopiedReferral] = useState(false);
  const [referralHistory, setReferralHistory] = useState<any[]>(() => {
    const saved = localStorage.getItem('AST_REFERRALS');
    return saved ? JSON.parse(saved) : [
      { id: 'ref_1', name: 'Raptor_FF', status: 'COMPLETED', reward: settings.referrals.rewardAmount, timestamp: '2026-07-14 15:45' },
      { id: 'ref_2', name: 'Sniper_Queen', status: 'COMPLETED', reward: settings.referrals.rewardAmount, timestamp: '2026-07-15 09:12' }
    ];
  });

  // --- DAILY CHECK-IN STATE ---
  const [lastCheckInDate, setLastCheckInDate] = useState<string>(() => {
    return localStorage.getItem('AST_LAST_CHECKIN') || '';
  });
  const [checkInDayIndex, setCheckInDayIndex] = useState<number>(() => {
    const saved = localStorage.getItem('AST_CHECKIN_DAY_INDEX');
    return saved ? parseInt(saved, 10) : 0;
  });
  const [claimHistory, setClaimHistory] = useState<ClaimHistoryItem[]>(() => {
    const saved = localStorage.getItem('AST_CLAIM_HISTORY');
    return saved ? JSON.parse(saved) : [
      { id: 'ch_1', type: 'DAILY', amount: settings.daily.rewardAmount, description: 'Day 1 Check-In Reward', timestamp: '2026-07-15 08:30' }
    ];
  });

  const dailyRewards = [
    { day: 1, amount: settings.daily.rewardAmount, badge: 'BRONZE' },
    { day: 2, amount: settings.daily.rewardAmount * 1.5, badge: 'BRONZE' },
    { day: 3, amount: settings.daily.rewardAmount * 2.0, badge: 'SILVER' },
    { day: 4, amount: settings.daily.rewardAmount * 2.5, badge: 'SILVER' },
    { day: 5, amount: settings.daily.rewardAmount * 3.0, badge: 'GOLD' },
    { day: 6, amount: settings.daily.rewardAmount * 4.0, badge: 'GOLD' },
    { day: 7, amount: settings.daily.rewardAmount * 6.0, badge: 'LEGENDARY' }
  ];

  // Support / FAQ / Feedback State
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem('AST_TICKETS');
    return saved ? JSON.parse(saved) : [
      { id: 'tk_1', subject: 'Room Credentials Issue', category: 'CREDENTIALS', description: 'Match #101 started before I received the password.', status: 'RESOLVED', timestamp: '2026-07-13 18:20' }
    ];
  });
  const [faqSearch, setFaqSearch] = useState('');
  const [faqExpanded, setFaqExpanded] = useState<number | null>(null);

  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketCategory, setTicketCategory] = useState('WALLET');
  const [ticketDesc, setTicketDesc] = useState('');

  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>(() => {
    const saved = localStorage.getItem('AST_FEEDBACK');
    return saved ? JSON.parse(saved) : [
      { id: 'fb_1', rating: 5, comment: 'Amazing platform! Tournaments are run smoothly and payout is fast.', timestamp: '2026-07-15 20:45' }
    ];
  });
  const [fbRating, setFbRating] = useState(5);
  const [fbComment, setFbComment] = useState('');

  // Persist items
  useEffect(() => {
    localStorage.setItem('AST_REFERRALS', JSON.stringify(referralHistory));
  }, [referralHistory]);

  useEffect(() => {
    localStorage.setItem('AST_CLAIM_HISTORY', JSON.stringify(claimHistory));
  }, [claimHistory]);

  useEffect(() => {
    localStorage.setItem('AST_TICKETS', JSON.stringify(supportTickets));
  }, [supportTickets]);

  useEffect(() => {
    localStorage.setItem('AST_FEEDBACK', JSON.stringify(feedbacks));
  }, [feedbacks]);

  // Check checkin status (completed today)
  const todayStr = new Date().toISOString().split('T')[0];
  const isDailyClaimedToday = lastCheckInDate === todayStr;

  // --- ACTIONS ---

  // Handle Referral Submission
  const handleClaimReferralCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendReferralCode.trim()) return;

    if (friendReferralCode.toUpperCase() === userReferralCode) {
      alert('You cannot claim your own referral code!');
      return;
    }

    if (!friendReferralCode.trim().startsWith('AST-')) {
      alert('Invalid code format. Code must start with AST-');
      return;
    }

    // Reward code claimer
    const reward = settings.referrals.rewardAmount;
    setUserProfile(prev => ({
      ...prev,
      bonusBalance: prev.bonusBalance + reward
    }));

    const newTx: Transaction = {
      id: "tx_ref_" + Date.now(),
      type: "REFERRAL",
      amount: reward,
      status: "APPROVED",
      description: `Claimed Friend Referral: ${friendReferralCode.trim().toUpperCase()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setTransactions(prev => [newTx, ...prev]);

    // Record claim
    setClaimHistory(prev => [
      {
        id: 'ch_ref_' + Date.now(),
        type: 'REFERRAL',
        amount: reward,
        description: `Claimed friend referral code: ${friendReferralCode.toUpperCase()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
      },
      ...prev
    ]);

    setNotifications(prev => [
      `🎁 Referral code claimed! $${reward.toFixed(2)} Bonus Balance added to your wallet.`,
      ...prev
    ]);

    setFriendReferralCode('');
    alert(`Success! $${reward.toFixed(2)} Bonus Coins have been added to your separate Bonus Wallet.`);
  };

  const copyReferralCode = () => {
    navigator.clipboard.writeText(userReferralCode);
    setCopiedReferral(true);
    setTimeout(() => setCopiedReferral(false), 2000);
  };

  // Handle Daily Checkin
  const handleDailyCheckIn = () => {
    if (isDailyClaimedToday) return;

    const currentDayReward = dailyRewards[checkInDayIndex % 7];
    const rewardAmount = currentDayReward.amount;

    // Add to Bonus Wallet
    setUserProfile(prev => ({
      ...prev,
      bonusBalance: prev.bonusBalance + rewardAmount
    }));

    // Update check-in dates
    setLastCheckInDate(todayStr);
    localStorage.setItem('AST_LAST_CHECKIN', todayStr);

    const nextIndex = (checkInDayIndex + 1) % 7;
    setCheckInDayIndex(nextIndex);
    localStorage.setItem('AST_CHECKIN_DAY_INDEX', nextIndex.toString());

    // Record Claim
    const newClaim: ClaimHistoryItem = {
      id: 'ch_d_' + Date.now(),
      type: 'DAILY',
      amount: rewardAmount,
      description: `Day ${currentDayReward.day} Check-In Completed`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setClaimHistory(prev => [newClaim, ...prev]);

    // Transaction ledger item
    const newTx: Transaction = {
      id: "tx_day_" + Date.now(),
      type: "DAILY_CHECKIN",
      amount: rewardAmount,
      status: "APPROVED",
      description: `Claimed Day ${currentDayReward.day} Check-In`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setTransactions(prev => [newTx, ...prev]);

    setNotifications(prev => [
      `🔥 Day ${currentDayReward.day} check-in success! $${rewardAmount.toFixed(2)} Bonus Coins added.`,
      ...prev
    ]);

    alert(`Booyah! Day ${currentDayReward.day} claim success! $${rewardAmount.toFixed(2)} added to Bonus Wallet.`);
  };

  // Support Ticket Action
  const handleRaiseTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketDesc.trim()) return;

    const newTicket: SupportTicket = {
      id: 'tk_' + Date.now(),
      subject: ticketSubject.trim(),
      category: ticketCategory,
      description: ticketDesc.trim(),
      status: 'PENDING',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    setSupportTickets(prev => [newTicket, ...prev]);
    setTicketSubject('');
    setTicketDesc('');
    alert('Ticket submitted successfully! Support experts will review and resolve this in 5-10 minutes.');
  };

  // Feedback Action
  const handleSendFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fbComment.trim()) return;

    const newFeedback: FeedbackItem = {
      id: 'fb_' + Date.now(),
      rating: fbRating,
      comment: fbComment.trim(),
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    setFeedbacks(prev => [newFeedback, ...prev]);
    setFbComment('');
    alert('Thank you for your rating! We appreciate your premium feedback.');
  };

  // FAQs List
  const faqs = [
    { q: "How do I join a custom Match Room?", a: "Find a tournament with vacant slots on the 'Explore Matches' tab and click 'Register'. Once registered, when the timer starts, your custom match credentials (ROOM ID and PASSWORD) will be instantly unlocked in the lobby details popup!" },
    { q: "What is the Bonus Balance?", a: "The Bonus Wallet balance is a virtual, promotional credit earned via Daily Rewards, referral invites, and Lucky Spins. It can ONLY be used to register in premium matches or tournament entry fees. It can never be converted to main balance or withdrawn." },
    { q: "Can I withdraw cash?", a: "Yes. Balances in your Main Wallet can be withdrawn to any active UPI ID at any time. Payout requests are verified by our admin board and transfers take only 10 to 15 minutes." },
    { q: "Are hacks or script systems allowed?", a: "Absolutely not. Ast's Arena enforces a strict zero-tolerance anti-cheat framework. Any player caught utilizing scripts, aim-locks, or modified files will be instantly ban-hammered from the servers and their wallet balances will be fully confiscated." },
    { q: "What if the host doesn't start the room?", a: "If a room experiences configuration errors or fails to launch, file a ticket in our Support Center instantly. Admins will verify the server status and credit entry fees back to your wallet." }
  ];

  // Announcements List
  const announcements = [
    { id: 'an_1', tag: 'URGENT', title: 'Free Fire OB45 Sync Up Completed', desc: 'Our tournament automation has fully synced with the latest Free Fire Client Update. Ready for optimal matchmaking.', date: '2026-07-16' },
    { id: 'an_2', tag: 'NOTICE', title: 'New $50 Bonus referral campaign!', desc: 'Invite 3 friends to AST Arena. For every valid registration, receive $15 into your Bonus Wallet instantly!', date: '2026-07-15' },
    { id: 'an_3', tag: 'NOTICE', title: 'CS-Chrono Mode Grand Duels', desc: 'Standard rules: Grenades are limited to 2, No double sniper combinations, Character active-skill cooldown standard 1.2x.', date: '2026-07-14' }
  ];

  const filteredFaqs = faqs.filter(f => 
    f.q.toLowerCase().includes(faqSearch.toLowerCase()) || 
    f.a.toLowerCase().includes(faqSearch.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-[#1F2633] to-[#171C24] border border-[#2B313D] rounded-[32px] p-8 text-left relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-full bg-gradient-to-l from-amber-500/5 to-transparent pointer-events-none" />
        <div className="absolute top-[-50%] right-[-10%] w-[350px] h-[350px] bg-amber-500/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-xl space-y-3 relative z-10">
          <div className="flex items-center gap-2">
            <span className="bg-esSecondary/20 text-esSecondary border border-esSecondary/30 text-[9px] font-mono font-black px-3 py-1 rounded-full uppercase tracking-widest">
              🌟 PREMIUM ARENA ZONE
            </span>
            <span className="bg-amber-500/15 text-amber-500 text-[9px] font-mono font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
              ● FREE LOOT & SUPPORT
            </span>
          </div>

          <h2 className="text-3xl font-black uppercase text-white tracking-tight font-heading leading-none">
            GLADIATOR <span className="text-transparent bg-clip-text bg-gradient-to-r from-esPrimary to-esSecondary">QUESTS & LOOT</span>
          </h2>

          <p className="text-xs text-esTextSecondary leading-relaxed">
            Claim daily coins, invite friends to earn elite virtual voucher prizes, and contact support instantly.
          </p>
        </div>
      </div>

      {/* 2. Top Navigation Sub-Tabs */}
      <div className="flex flex-wrap gap-2.5 border-b border-[#2B313D]/40 pb-4">
        {[
          { id: 'rewards', label: 'Check-In Rewards', icon: Calendar },
          { id: 'referral', label: 'Referral System', icon: Share2 },
          { id: 'support', label: 'Support & Help', icon: HelpCircle },
          { id: 'rules', label: 'Lobby Rules', icon: BookOpen }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-[10px] font-mono font-bold uppercase tracking-wider transition-all cursor-pointer ${
                isActive 
                  ? 'bg-gradient-to-r from-esPrimary/20 to-esSecondary/10 text-white border border-esPrimary/40' 
                  : 'bg-[#1F2633]/60 hover:bg-[#1F2633] text-esTextSecondary hover:text-white border border-transparent'
              }`}
            >
              <Icon size={12} className={isActive ? 'text-esPrimary' : 'text-esTextSecondary'} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 3. Sub-Tab Content Rendering */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Active panel details (8 Columns) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* A. CHECK-IN REWARDS TAB */}
          {activeSubTab === 'rewards' && (
            !settings.features.dailyReward ? (
              <div className="bg-[#1F2633] border border-amber-500/30 rounded-[32px] p-12 text-center space-y-4 animate-in fade-in duration-300">
                <span className="text-4xl animate-bounce inline-block">🛠️</span>
                <h4 className="text-sm font-black text-white uppercase tracking-wider">FEATURE TEMPORARILY OFFLINE</h4>
                <p className="text-xs text-esTextSecondary max-w-md mx-auto leading-relaxed">
                  The Daily Check-In reward system is currently undergoing scheduled backend maintenance. Check back later for active bonuses!
                </p>
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left">
                <div className="flex justify-between items-center mb-6">
                  <div className="space-y-1">
                    <span className="text-[9px] font-mono font-black text-esPrimary uppercase tracking-widest block">DAILY INCENTIVES</span>
                    <h3 className="text-lg font-black text-white uppercase font-heading">7-Day Gladiator Check-In</h3>
                  </div>
                  <button
                    onClick={handleDailyCheckIn}
                    disabled={isDailyClaimedToday}
                    className={`px-6 py-3 rounded-xl font-mono font-black text-[10px] uppercase tracking-widest transition-all ${
                      isDailyClaimedToday 
                        ? 'bg-[#171C24] text-esTextSecondary/40 border border-[#2B313D] cursor-not-allowed'
                        : 'bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] shadow-lg shadow-esPrimary/15 cursor-pointer hover:scale-[1.02]'
                    }`}
                  >
                    {isDailyClaimedToday ? 'Already Claimed Today' : 'Claim Daily Bonus'}
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
                  {dailyRewards.map((item, idx) => {
                    const isClaimed = idx < checkInDayIndex;
                    const isCurrent = idx === checkInDayIndex && !isDailyClaimedToday;
                    return (
                      <div 
                        key={item.day}
                        className={`p-3.5 rounded-2xl border text-center relative flex flex-col justify-between h-32 transition-all ${
                          isClaimed 
                            ? 'bg-[#171C24]/50 border-emerald-500/20 text-[#4CAF50]'
                            : isCurrent 
                              ? 'bg-[#1F2633] border-esPrimary/80 shadow-[0_0_15px_rgba(255,138,0,0.15)] text-white scale-[1.03]'
                              : 'bg-[#171C24] border-[#2B313D] text-esTextSecondary'
                        }`}
                      >
                        <span className="text-[8px] font-mono font-bold block uppercase tracking-wider">Day {item.day}</span>
                        <div className="my-2 flex flex-col items-center">
                          <Gift size={20} className={isClaimed ? 'text-emerald-500' : isCurrent ? 'text-esPrimary animate-bounce' : 'text-esTextSecondary/50'} />
                          <span className="text-xs font-black font-mono block mt-2">${item.amount.toFixed(0)}</span>
                        </div>
                        <span className={`text-[7px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${
                          isClaimed 
                            ? 'bg-emerald-500/10 text-emerald-400' 
                            : isCurrent 
                              ? 'bg-esPrimary/10 text-esPrimary' 
                              : 'bg-[#1F2633] text-esTextSecondary/40'
                        }`}>
                          {isClaimed ? 'CLAIMED' : isCurrent ? 'READY' : item.badge}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Claim History List */}
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left">
                <h4 className="text-xs font-mono font-black text-white uppercase tracking-widest mb-4 flex items-center gap-2">
                  <History size={14} className="text-esSecondary" />
                  <span>CLAIM LEDGER HISTORY</span>
                </h4>
                <div className="space-y-2.5 max-h-64 overflow-y-auto pr-2">
                  {claimHistory.length === 0 ? (
                    <p className="text-[10px] font-mono text-esTextSecondary/40 uppercase">No claims recorded in history.</p>
                  ) : (
                    claimHistory.map(item => (
                      <div key={item.id} className="bg-[#171C24] border border-[#2B313D]/60 p-3 rounded-xl flex justify-between items-center">
                        <div className="text-left space-y-0.5">
                          <span className="text-[8px] font-mono text-esSecondary font-bold uppercase tracking-wider block">{item.type} REWARD</span>
                          <span className="text-xs font-semibold text-white block">{item.description}</span>
                          <span className="text-[8px] font-mono text-esTextSecondary/40 block">{item.timestamp}</span>
                        </div>
                        <span className="text-xs font-mono font-black text-emerald-400">+${item.amount.toFixed(2)} BONUS</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          ))}

          {/* B. REFERRAL SYSTEM TAB */}
          {activeSubTab === 'referral' && (
            !settings.features.referral ? (
              <div className="bg-[#1F2633] border border-amber-500/30 rounded-[32px] p-12 text-center space-y-4 animate-in fade-in duration-300">
                <span className="text-4xl animate-bounce inline-block">🛠️</span>
                <h4 className="text-sm font-black text-white uppercase tracking-wider">FEATURE TEMPORARILY OFFLINE</h4>
                <p className="text-xs text-esTextSecondary max-w-md mx-auto leading-relaxed">
                  The Gladiator Referral system is currently offline for routine system updates. Bring your squad back shortly!
                </p>
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left space-y-6">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono font-black text-esPrimary uppercase tracking-widest block">COMMUNITY CAMPAIGN</span>
                  <h3 className="text-lg font-black text-white uppercase font-heading">Gladiator Referral Hub</h3>
                  <p className="text-xs text-esTextSecondary">Invite your competitive squad friends to AST Arena. When they verify accounts and enter your code, both gain premium Bonus Wallet Coins.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Your code */}
                  <div className="bg-[#171C24] border border-[#2B313D] p-4.5 rounded-2xl text-left space-y-3">
                    <span className="text-[8px] font-mono text-esTextSecondary block uppercase tracking-wider">YOUR UNIQUE REFERRAL CODE</span>
                    <div className="flex items-center gap-2">
                      <span className="flex-1 bg-[#0B0F14] border border-[#2B313D] px-4 py-3 rounded-xl text-xs font-mono font-black text-esPrimary select-all">
                        {userReferralCode}
                      </span>
                      <button 
                        onClick={copyReferralCode}
                        className="px-4 py-3 bg-[#1F2633] hover:bg-[#0B0F14] border border-esPrimary/20 hover:border-esPrimary/60 rounded-xl text-esTextSecondary hover:text-white transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        {copiedReferral ? <CheckCircle2 size={13} className="text-emerald-400" /> : <Copy size={13} />}
                        <span className="text-[10px] font-mono font-bold uppercase">{copiedReferral ? 'COPIED' : 'COPY'}</span>
                      </button>
                    </div>
                    <p className="text-[9px] text-esTextSecondary/60 italic leading-normal">
                      💡 Share this code with friends. They earn ${settings.referrals.rewardAmount.toFixed(2)} instantly, and you receive ${settings.referrals.rewardAmount.toFixed(2)} once they claim it!
                    </p>
                  </div>

                  {/* Claim friend code */}
                  <div className="bg-[#171C24] border border-[#2B313D] p-4.5 rounded-2xl text-left space-y-3">
                    <span className="text-[8px] font-mono text-esTextSecondary block uppercase tracking-wider">REDEEM FRIENDS CODE</span>
                    <form onSubmit={handleClaimReferralCode} className="flex gap-2">
                      <input 
                        type="text" 
                        value={friendReferralCode}
                        onChange={(e) => setFriendReferralCode(e.target.value)}
                        placeholder="e.g. AST-GAMER-7291"
                        className="flex-1 bg-[#0B0F14] border border-[#2B313D] rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-esTextSecondary/30 uppercase tracking-widest focus:outline-none focus:border-esPrimary"
                      />
                      <button 
                        type="submit"
                        className="px-5 py-3 bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] font-mono font-black text-[10px] uppercase tracking-widest rounded-xl transition-all cursor-pointer hover:scale-[1.02] active:scale-95"
                      >
                        REDEEM
                      </button>
                    </form>
                    <p className="text-[9px] text-esTextSecondary/60 italic leading-normal">
                      💡 Claim a friend's code once to instantly add ${settings.referrals.rewardAmount.toFixed(2)} virtual coins to your Tournament Bonus Wallet.
                    </p>
                  </div>
                </div>
              </div>

              {/* Referral Friends List */}
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left">
                <h4 className="text-xs font-mono font-black text-white uppercase tracking-widest mb-4 flex items-center gap-2">
                  <Share2 size={14} className="text-esSecondary" />
                  <span>SQUAD INVITED FRIENDS HISTORY</span>
                </h4>
                <div className="space-y-2.5">
                  {referralHistory.map(ref => (
                    <div key={ref.id} className="bg-[#171C24] border border-[#2B313D]/60 p-3 rounded-xl flex justify-between items-center">
                      <div className="text-left space-y-0.5">
                        <span className="text-xs font-bold text-white block uppercase">{ref.name}</span>
                        <span className="text-[8px] font-mono text-esTextSecondary/40 block">{ref.timestamp}</span>
                      </div>
                      <div className="text-right">
                        <span className="bg-emerald-500/10 text-emerald-400 text-[8px] font-mono font-bold px-2 py-0.5 rounded border border-emerald-500/20 uppercase tracking-wider inline-block mb-1">
                          {ref.status}
                        </span>
                        <span className="text-xs font-mono font-black text-esPrimary block">+${ref.reward.toFixed(2)} BONUS</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}

          {/* D. SUPPORT & HELP TAB */}
          {activeSubTab === 'support' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Dispute and Support Ticket */}
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left space-y-4">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono font-black text-esPrimary uppercase tracking-widest block">DISPUTE CENTER</span>
                  <h3 className="text-lg font-black text-white uppercase font-heading">Lobby Support Desks</h3>
                  <p className="text-xs text-esTextSecondary">Encountered an issue, credential delays, or suspicious player behavior? Create an official ticket to notify active administrators instantly.</p>
                </div>

                <form onSubmit={handleRaiseTicket} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[8px] font-mono font-bold text-esTextSecondary/60 block uppercase tracking-wider">TICKET DISPUTE SUBJECT</label>
                      <input 
                        type="text" 
                        value={ticketSubject}
                        onChange={(e) => setTicketSubject(e.target.value)}
                        placeholder="e.g. Room ID password failed"
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-esTextSecondary/30 focus:outline-none focus:border-esPrimary"
                        required
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[8px] font-mono font-bold text-esTextSecondary/60 block uppercase tracking-wider">ISSUE CATEGORY</label>
                      <select 
                        value={ticketCategory}
                        onChange={(e) => setTicketCategory(e.target.value)}
                        className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl px-4 py-3 text-xs font-mono text-white focus:outline-none focus:border-esPrimary"
                      >
                        <option value="WALLET">Main Wallet Deposit / Payouts</option>
                        <option value="CREDENTIALS">Custom Room ID & Password</option>
                        <option value="HACKER">Report Suspicious Behavior/Hacks</option>
                        <option value="BONUS">Bonus Wallet Issues</option>
                        <option value="OTHER">Other Custom Lobby Inquiries</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[8px] font-mono font-bold text-esTextSecondary/60 block uppercase tracking-wider">DETAILED GUIDELINES / ROOM NUMBER / TIMELINE</label>
                    <textarea 
                      value={ticketDesc}
                      onChange={(e) => setTicketDesc(e.target.value)}
                      placeholder="Please supply specific match details or reference IDs so admins can audit the server log instantly..."
                      rows={3}
                      className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl p-4 text-xs font-mono text-white placeholder-esTextSecondary/30 focus:outline-none focus:border-esPrimary"
                      required
                    />
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-3.5 bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] font-mono font-black text-[10px] uppercase tracking-widest rounded-xl transition-all cursor-pointer hover:scale-[1.01]"
                  >
                    SUBMIT DISPUTE TICKET
                  </button>
                </form>
              </div>

              {/* Tickets List */}
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left">
                <h4 className="text-xs font-mono font-black text-white uppercase tracking-widest mb-4 flex items-center gap-2">
                  <MessageSquare size={14} className="text-esSecondary" />
                  <span>YOUR ACTIVE SUPPORT CASES ({supportTickets.length})</span>
                </h4>
                <div className="space-y-2.5 max-h-52 overflow-y-auto">
                  {supportTickets.length === 0 ? (
                    <p className="text-[10px] font-mono text-esTextSecondary/40 uppercase">No active support tickets.</p>
                  ) : (
                    supportTickets.map(tk => (
                      <div key={tk.id} className="bg-[#171C24] border border-[#2B313D]/60 p-4 rounded-xl space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[8px] font-mono text-esSecondary font-bold block uppercase">{tk.category}</span>
                            <h5 className="text-xs font-bold text-white">{tk.subject}</h5>
                          </div>
                          <span className={`text-[8px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${
                            tk.status === 'RESOLVED' 
                              ? 'bg-[#4CAF50]/10 text-[#4CAF50] border-[#4CAF50]/20' 
                              : 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                          }`}>
                            {tk.status}
                          </span>
                        </div>
                        <p className="text-[10px] text-esTextSecondary/80 font-mono leading-normal">{tk.description}</p>
                        <span className="text-[8px] font-mono text-esTextSecondary/40 block pt-1">{tk.timestamp}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* FAQs Accordion */}
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-mono font-black text-white uppercase tracking-widest flex items-center gap-2">
                    <HelpCircle size={14} className="text-esSecondary" />
                    <span>FREQUENTLY ASKED LOBBY FAQS</span>
                  </h4>
                  <input 
                    type="text"
                    value={faqSearch}
                    onChange={(e) => setFaqSearch(e.target.value)}
                    placeholder="Search FAQs..."
                    className="bg-[#0B0F14] border border-[#2B313D] rounded-lg px-2.5 py-1 text-[10px] font-mono text-white placeholder-esTextSecondary/30"
                  />
                </div>

                <div className="space-y-2">
                  {filteredFaqs.map((faq, idx) => (
                    <div key={idx} className="border border-[#2B313D]/40 rounded-xl overflow-hidden">
                      <button
                        onClick={() => setFaqExpanded(faqExpanded === idx ? null : idx)}
                        className="w-full bg-[#171C24] hover:bg-[#171C24]/80 p-3.5 flex justify-between items-center text-left cursor-pointer transition-colors"
                      >
                        <span className="text-xs font-bold text-white uppercase font-mono">{faq.q}</span>
                        <span className="text-esSecondary text-xs">{faqExpanded === idx ? '−' : '+'}</span>
                      </button>
                      {faqExpanded === idx && (
                        <div className="bg-[#171C24]/30 p-3.5 border-t border-[#2B313D]/20 text-[10px] font-mono text-esTextSecondary/95 leading-relaxed">
                          {faq.a}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Feedback Form */}
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left space-y-4">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono font-black text-esPrimary uppercase tracking-widest block">FEEDBACK DESK</span>
                  <h3 className="text-lg font-black text-white uppercase font-heading font-black">RATE AST ARENA</h3>
                </div>

                <form onSubmit={handleSendFeedback} className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[8px] font-mono font-bold text-esTextSecondary uppercase tracking-wider block">YOUR RATING:</span>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map(star => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setFbRating(star)}
                          className="p-1 hover:scale-110 transition-transform cursor-pointer"
                        >
                          <Star 
                            size={16} 
                            className={star <= fbRating ? 'fill-esPrimary text-esPrimary' : 'text-esTextSecondary/30'} 
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={fbComment}
                      onChange={(e) => setFbComment(e.target.value)}
                      placeholder="e.g. Lobby syncs are incredibly clean, 10/10 matchmaking!"
                      className="flex-1 bg-[#0B0F14] border border-[#2B313D] rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-esTextSecondary/30 focus:outline-none focus:border-esPrimary"
                      required
                    />
                    <button 
                      type="submit"
                      className="px-5 py-3 bg-[#171C24] hover:bg-[#0B0F14] border border-esPrimary/20 hover:border-esPrimary text-esPrimary hover:text-white font-mono font-black text-[10px] uppercase tracking-widest rounded-xl transition-all cursor-pointer"
                    >
                      SEND
                    </button>
                  </div>
                </form>

                <div className="space-y-2">
                  {feedbacks.map(fb => (
                    <div key={fb.id} className="bg-[#171C24] p-3 rounded-xl border border-[#2B313D]/40 text-left">
                      <div className="flex justify-between items-center mb-1">
                        <div className="flex gap-0.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star 
                              key={i} 
                              size={9} 
                              className={i < fb.rating ? 'fill-esPrimary text-esPrimary' : 'text-esTextSecondary/20'} 
                            />
                          ))}
                        </div>
                        <span className="text-[7px] font-mono text-esTextSecondary/40">{fb.timestamp}</span>
                      </div>
                      <p className="text-[10px] text-white font-mono leading-normal">"{fb.comment}"</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* E. TOURNAMENT RULES TAB */}
          {activeSubTab === 'rules' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left space-y-4">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono font-black text-esPrimary uppercase tracking-widest block">REGULATORY MATRIX</span>
                  <h3 className="text-lg font-black text-white uppercase font-heading">Official Custom Match Rules</h3>
                  <p className="text-xs text-esTextSecondary">Read all competitive guidelines strictly. Failure to obey rules will result in lobby disqualification and loss of entry fees.</p>
                </div>

                <div className="bg-[#0B0F14] rounded-2xl p-5 border border-[#2B313D] text-[11px] font-mono text-esTextSecondary space-y-4 leading-relaxed">
                  <div>
                    <h5 className="text-white font-black uppercase mb-1 flex items-center gap-1.5 text-xs text-esSecondary">
                      ● 1. BEHAVIORAL PROTOCOLS
                    </h5>
                    <p>All participants must enter rooms using registered names matching their profile data. Sharing lobby credentials (ROOM ID/PASSWORDS) to non-registered external friends triggers automatic database blacklisting.</p>
                  </div>
                  <div>
                    <h5 className="text-white font-black uppercase mb-1 flex items-center gap-1.5 text-xs text-esSecondary">
                      ● 2. ANTI-CHEAT INGRESS
                    </h5>
                    <p>No emulators allowed in standard SQUAD / SOLO mobile-only formats. Third-party visual enhancers, DPI modifications, config scripts, and script modules trigger instant anticheat protection kicks. All match histories are recorded on device.</p>
                  </div>
                  <div>
                    <h5 className="text-white font-black uppercase mb-1 flex items-center gap-1.5 text-xs text-esSecondary">
                      ● 3. WEAPON & LOADOUT RESTRAINTS
                    </h5>
                    <p>Unless specified, double snipers (AWM/M82B) are strictly banned. Grenade spamming in clash squad mode is restricted to maximum 2 per round. Landmines can only be positioned in designated outdoor environments.</p>
                  </div>
                  <div>
                    <h5 className="text-white font-black uppercase mb-1 flex items-center gap-1.5 text-xs text-esSecondary">
                      ● 4. DISPUTE & REFUND SCHEMES
                    </h5>
                    <p>To declare match cancellation or request entry fee refunds, submit a high-priority ticket in the 'Support Center' within 1 hour. Include custom room screenshots of leaderboard stats.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Bonus Wallet & Statistics Panel (4 Columns) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* A. Separate Bonus Wallet Card */}
          <div className="bg-gradient-to-tr from-[#1F2633] to-[#171C24] border-2 border-esSecondary/40 rounded-3xl p-6 text-left relative overflow-hidden shadow-xl">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-l from-esSecondary/10 to-transparent pointer-events-none" />
            
            <div className="flex items-center gap-1.5">
              <Wallet size={14} className="text-esSecondary animate-pulse" />
              <span className="text-[9px] font-mono font-black text-esSecondary uppercase tracking-widest">
                Bonus Balance (Tournament Use Only)
              </span>
            </div>

            <div className="mt-4 flex items-baseline gap-1.5">
              <span className="text-3xl font-mono font-black text-white">${userProfile.bonusBalance.toFixed(2)}</span>
              <span className="text-[10px] font-mono text-esTextSecondary uppercase tracking-wider">BONUS</span>
            </div>

            <div className="mt-4 p-3.5 bg-[#0B0F14]/80 border border-[#2B313D] rounded-2xl space-y-1.5">
              <div className="flex items-center gap-1 text-[9px] font-mono text-esSecondary font-bold">
                <Info size={11} className="text-esSecondary shrink-0" />
                <span>BONUS USE POLICY</span>
              </div>
              <p className="text-[10px] text-esTextSecondary leading-relaxed">
                Bonus Balance is promotional virtual credit. It can only be used to join tournaments and cannot be withdrawn or converted into cash.
              </p>
            </div>

            <div className="mt-4 pt-3.5 border-t border-[#2B313D] space-y-2">
              <div className="flex justify-between items-center text-[10px] font-mono">
                <span className="text-esTextSecondary uppercase">Withdrawable cash</span>
                <span className="text-[#4CAF50] font-bold">${userProfile.walletBalance.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-mono">
                <span className="text-esTextSecondary uppercase">Lobby entry usage</span>
                <span className="text-white font-bold">100% Eligible</span>
              </div>
            </div>
          </div>

          {/* B. Player Stats Dossier */}
          <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left">
            <span className="text-[8px] font-mono font-black text-esPrimary block uppercase tracking-widest mb-3">🏅 GLADIATOR PROFILE DOSSIER</span>
            
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-esPrimary to-esSecondary flex items-center justify-center font-black text-[#0B0F14] text-lg">
                  {userProfile.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h4 className="text-sm font-black text-white uppercase font-heading">{userProfile.name}</h4>
                  <span className="text-[8px] font-mono text-esSecondary font-bold uppercase tracking-wider block">LEVEL 78 PLATINUM</span>
                </div>
              </div>

              {/* Grid statistics */}
              <div className="grid grid-cols-2 gap-3 text-left font-mono">
                <div className="bg-[#171C24] p-3 rounded-xl border border-[#2B313D]/60">
                  <span className="text-esTextSecondary text-[8px] block uppercase tracking-wide">MATCHES PLAYED</span>
                  <span className="font-bold text-white text-xs block mt-0.5">{userProfile.playedCount}</span>
                </div>
                <div className="bg-[#171C24] p-3 rounded-xl border border-[#2B313D]/60">
                  <span className="text-esTextSecondary text-[8px] block uppercase tracking-wide">VICTORIES</span>
                  <span className="font-bold text-white text-xs block mt-0.5">{userProfile.wonCount}</span>
                </div>
                <div className="bg-[#171C24] p-3 rounded-xl border border-[#2B313D]/60">
                  <span className="text-esTextSecondary text-[8px] block uppercase tracking-wide">K/D RATIO</span>
                  <span className="font-bold text-esPrimary text-xs block mt-0.5">3.45</span>
                </div>
                <div className="bg-[#171C24] p-3 rounded-xl border border-[#2B313D]/60">
                  <span className="text-esTextSecondary text-[8px] block uppercase tracking-wide">HEADSHOT RATE</span>
                  <span className="font-bold text-esSecondary text-xs block mt-0.5">58.4%</span>
                </div>
              </div>
            </div>
          </div>

          {/* C. Achievement Badges List */}
          <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left">
            <span className="text-[8px] font-mono font-black text-esPrimary block uppercase tracking-widest mb-3">🏆 UNLOCKED ACCOMPLISHMENTS</span>
            
            <div className="space-y-3">
              {[
                { title: "SQUAD TERMINATOR", desc: "Won squad match with 10+ collective headshots.", unlocked: userProfile.playedCount >= 10 },
                { title: "BOOYAH HIGHLANDER", desc: "Won 5 consecutive solo custom matches.", unlocked: userProfile.wonCount >= 5 },
                { title: "PREMIUM SPONSOR", desc: "Completed manual wallet deposit synchronization.", unlocked: transactions.some(x => x.type === 'DEPOSIT') },
                { title: "SHERIFF CLAIMER", desc: "Redeemed 3 friend referral invite codes.", unlocked: referralHistory.length >= 2 }
              ].map((ach, idx) => (
                <div 
                  key={idx} 
                  className={`p-3 rounded-2xl border transition-all flex items-start gap-2.5 ${
                    ach.unlocked 
                      ? 'bg-gradient-to-r from-esPrimary/10 to-[#171C24] border-esPrimary/30 text-white' 
                      : 'bg-[#171C24]/50 border-[#2B313D]/40 text-esTextSecondary/50'
                  }`}
                >
                  <Award size={18} className={ach.unlocked ? 'text-esPrimary shrink-0 mt-0.5' : 'text-esTextSecondary/20 shrink-0 mt-0.5'} />
                  <div className="text-left space-y-0.5">
                    <h5 className="text-[10px] font-black uppercase font-heading">{ach.title}</h5>
                    <p className="text-[9px] font-mono leading-normal">{ach.desc}</p>
                    <span className={`text-[7px] font-mono font-black uppercase px-1.5 py-0.5 rounded inline-block mt-1 ${
                      ach.unlocked ? 'bg-esPrimary/20 text-esPrimary' : 'bg-[#1F2633] text-esTextSecondary/30'
                    }`}>
                      {ach.unlocked ? 'UNLOCKED ●' : 'LOCKED'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* D. News & Announcements Center */}
          <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-6 text-left space-y-3">
            <span className="text-[8px] font-mono font-black text-esPrimary block uppercase tracking-widest">📢 ANNOUNCEMENT CENTER</span>
            
            <div className="space-y-2.5">
              {announcements.map(ann => (
                <div key={ann.id} className="bg-[#171C24] border border-[#2B313D]/50 p-3.5 rounded-2xl text-left space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="bg-esSecondary/25 text-esSecondary text-[7px] font-mono font-black px-1.5 py-0.5 rounded uppercase">
                      {ann.tag}
                    </span>
                    <span className="text-[7px] font-mono text-esTextSecondary/40">{ann.date}</span>
                  </div>
                  <h5 className="text-[10px] font-black text-white uppercase">{ann.title}</h5>
                  <p className="text-[9px] font-mono text-esTextSecondary/80 leading-normal">{ann.desc}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
