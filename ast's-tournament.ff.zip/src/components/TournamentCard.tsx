import React, { useState, useEffect } from 'react';
import { Calendar, Users, Trophy, DollarSign, Clock, Play, Star } from 'lucide-react';
import { Tournament } from '../types';
import { appStrings } from '../config/appStrings';

interface TournamentCardProps {
  tournament: Tournament;
  userId: string;
  onSelect: () => void;
  onRegister: (e: React.MouseEvent) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (e: React.MouseEvent) => void;
}

export default function TournamentCard({
  tournament,
  userId,
  onSelect,
  onRegister,
  isFavorite = false,
  onToggleFavorite,
}: TournamentCardProps) {
  const isRegistered = tournament.participants.includes(userId);
  const progress = Math.min(100, (tournament.joinedCount / tournament.totalSlots) * 100);
  const slotsLeft = tournament.totalSlots - tournament.joinedCount;

  // Map posters based on tournament ID
  let posterUrl = "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80"; // default
  if (tournament.id.includes("diamond")) {
    posterUrl = "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80"; // squad arena
  } else if (tournament.id.includes("rush")) {
    posterUrl = "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80"; // solo striker
  } else if (tournament.id.includes("clash")) {
    posterUrl = "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=600&q=80"; // CS chrono cup
  } else {
    // Custom match created by Admin
    posterUrl = "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=600&q=80";
  }

  // Live countdown state
  const [countdownText, setCountdownText] = useState('04h : 15m : 30s');

  useEffect(() => {
    // Generate a beautiful countdown based on match time
    const interval = setInterval(() => {
      const matchTime = new Date(tournament.dateTime.replace(' ', 'T')).getTime();
      const now = new Date().getTime();
      const diff = matchTime - now;

      if (diff <= 0) {
        setCountdownText("Started / Live Lobby");
      } else {
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);
        
        const hStr = hours < 10 ? `0${hours}` : hours;
        const mStr = mins < 10 ? `0${mins}` : mins;
        const sStr = secs < 10 ? `0${secs}` : secs;

        setCountdownText(`${hStr}h : ${mStr}m : ${sStr}s`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [tournament.dateTime]);

  return (
    <div 
      onClick={onSelect}
      className="bg-[#1F2633] border border-[#2B313D] hover:border-esPrimary/40 rounded-3xl overflow-hidden transition-all duration-300 shadow-xl hover:shadow-[0_0_35px_rgba(255,138,0,0.12)] hover:-translate-y-1 cursor-pointer flex flex-col group relative"
    >
      {/* 1. Poster Container with Overlays */}
      <div className="relative h-44 w-full overflow-hidden shrink-0">
        <div className="absolute inset-0 bg-gradient-to-t from-[#1F2633] via-transparent to-black/50 z-10" />
        <img 
          src={posterUrl} 
          alt={tournament.title} 
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />

        {/* 2. Live Badge on Poster */}
        <div className="absolute top-4 left-4 z-20 flex items-center gap-1.5 bg-[#0B0F14]/75 backdrop-blur-md px-3 py-1.5 rounded-full border border-esPrimary/30">
          <span className="w-1.5 h-1.5 rounded-full bg-esPrimary animate-ping" />
          <span className="w-1.5 h-1.5 rounded-full bg-esPrimary absolute top-2.5 left-5" />
          <span className="text-[8px] font-mono font-black text-esPrimary uppercase tracking-wider">
            {appStrings.tournamentCard.liveBadge}
          </span>
        </div>

        {/* Favorite Star Button */}
        {onToggleFavorite && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(e);
            }}
            className="absolute top-16 right-4 z-20 w-8 h-8 rounded-xl bg-[#0B0F14]/80 backdrop-blur-md border border-[#2B313D]/60 flex items-center justify-center hover:scale-110 transition-transform cursor-pointer"
            title={isFavorite ? "Remove from Favorites" : "Add to Favorites"}
          >
            <Star 
              size={13} 
              className={isFavorite ? "fill-amber-500 text-amber-500" : "text-esTextSecondary"} 
            />
          </button>
        )}

        {/* Tags on Poster */}
        <div className="absolute bottom-4 left-4 z-20 flex items-center gap-2">
          <span className="bg-esPrimary/20 text-esPrimary border border-esPrimary/30 text-[9px] font-mono font-black px-2.5 py-1 rounded-xl">
            {tournament.mapName}
          </span>
          <span className="bg-white/10 text-white border border-white/20 text-[9px] font-mono font-black px-2.5 py-1 rounded-xl uppercase">
            {tournament.type}
          </span>
        </div>

        {/* 3. Prize Pool Metallic Golden Badge */}
        <div className="absolute top-4 right-4 z-20 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-[#0B0F14] px-4 py-2 rounded-2xl font-mono font-black text-xs uppercase tracking-widest flex items-center gap-1.5 shadow-[0_8px_20px_rgba(255,193,7,0.3)] border border-yellow-300/40">
          <Trophy size={13} className="text-[#0B0F14] animate-bounce" />
          <span>${tournament.prizePool} POOL</span>
        </div>
      </div>

      {/* Content Space */}
      <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
        {/* Title and Countdown */}
        <div className="space-y-1 text-left">
          <h4 className="text-base font-black text-white tracking-wide group-hover:text-esSecondary transition-colors font-heading uppercase">
            {tournament.title}
          </h4>
          
          {/* 4. Countdown Timer */}
          <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-esSecondary bg-esSecondary/5 px-2.5 py-1 rounded-lg border border-esSecondary/15 w-max">
            <Clock size={11} className="text-esSecondary animate-pulse" />
            <span>{appStrings.tournamentCard.startsIn}{countdownText}</span>
          </div>
        </div>

        {/* Date, Time, Entry Fee */}
        <div className="grid grid-cols-2 gap-3 pt-1 text-left border-t border-[#2B313D]/40">
          <div className="space-y-0.5">
            <span className="text-[8px] font-mono text-esTextSecondary block uppercase tracking-wider">{appStrings.tournamentCard.dateTimeLabel}</span>
            <span className="text-xs font-semibold text-white font-mono flex items-center gap-1">
              <Calendar size={11} className="text-esPrimary shrink-0" />
              {tournament.dateTime}
            </span>
          </div>
          <div className="space-y-0.5 text-right">
            <span className="text-[8px] font-mono text-esTextSecondary block uppercase tracking-wider">{appStrings.tournamentCard.entryCostLabel}</span>
            <span className="text-sm font-black text-esPrimary font-mono block">
              ${tournament.entryFee} {appStrings.tournamentCard.mainLabel}
            </span>
          </div>
        </div>

        {/* 5. Slots left, Progress bar */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-[10px] font-mono font-bold">
            <span className="text-esTextSecondary uppercase tracking-wider">{appStrings.tournamentCard.progressLabel}</span>
            <span className="text-white bg-[#171C24] px-2 py-0.5 rounded border border-[#2B313D] font-mono">
              {tournament.joinedCount}/{tournament.totalSlots} {appStrings.tournamentCard.slotsLabel}
            </span>
          </div>

          <div className="w-full h-3 bg-[#0B0F14]/80 rounded-full overflow-hidden border border-[#2B313D]/50 p-[2px] relative">
            <div 
              className="h-full bg-gradient-to-r from-esPrimary to-esSecondary rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(255,138,0,0.3)]" 
              style={{ width: `${progress}%` }} 
            />
          </div>

          <div className="flex justify-between items-center text-[9px] font-mono font-bold text-esTextSecondary uppercase tracking-wider">
            <span>{appStrings.tournamentCard.capacityLabel}{progress.toFixed(0)}%</span>
            <span className="text-esSecondary font-extrabold">{slotsLeft} {appStrings.tournamentCard.slotsLeftLabel}</span>
          </div>
        </div>

        {/* 6. Premium Join Button */}
        <div className="pt-2">
          {isRegistered ? (
            <div className="w-full text-center py-3 bg-esPrimary/10 border border-esPrimary/30 rounded-2xl text-esPrimary font-black text-xs uppercase tracking-widest shadow-inner">
              {appStrings.tournamentCard.registeredStatus}
            </div>
          ) : (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onRegister(e);
              }}
              className="w-full py-3.5 bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] font-black text-xs uppercase tracking-widest rounded-2xl transition-all duration-300 shadow-md shadow-esPrimary/10 hover:shadow-[0_0_20px_rgba(255,138,0,0.35)] hover:scale-[1.02] flex items-center justify-center gap-1.5 cursor-pointer font-heading"
            >
              <Play size={12} className="fill-[#0B0F14] text-[#0B0F14]" />
              <span>{appStrings.tournamentCard.joinButtonText}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

