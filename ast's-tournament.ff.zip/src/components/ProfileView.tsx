import React from 'react';
import { Award, Shield, User, Trophy, Mail, Phone, ExternalLink } from 'lucide-react';
import { UserProfile } from '../types';
import { appStrings } from '../config/appStrings';
import firebaseConfig from '../firebase-applet-config.json';

interface ProfileViewProps {
  userProfile: UserProfile;
  onTriggerAdmin?: () => void;
  onUpdateUsername?: (newName: string) => void;
}

export default function ProfileView({ userProfile, onTriggerAdmin, onUpdateUsername }: ProfileViewProps) {
  const [tempName, setTempName] = React.useState(userProfile.name);
  const [saveSuccess, setSaveSuccess] = React.useState(false);

  React.useEffect(() => {
    setTempName(userProfile.name);
  }, [userProfile.name]);

  const handleSaveUsername = () => {
    if (tempName.trim() && onUpdateUsername) {
      onUpdateUsername(tempName.trim());
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  const isUserAdmin = userProfile.isAdmin || (userProfile as any).role === 'admin';

  // Win rate ratio
  const winRate = userProfile.playedCount > 0 
    ? ((userProfile.wonCount / userProfile.playedCount) * 100).toFixed(0) 
    : "0";

  return (
    <div className="space-y-6 animate-in fade-in duration-300 text-left">
      
      {/* Cinematic Banner profile */}
      <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-esPrimary/10 to-transparent pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-10%] w-72 h-72 bg-gradient-to-tr from-esSecondary/5 to-transparent pointer-events-none" />

        <div className="flex flex-col md:flex-row items-center gap-6 relative z-10">
          {/* Avatar sphere */}
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-esPrimary to-esSecondary flex items-center justify-center font-black text-[#0B0F14] text-4xl shadow-xl relative animate-pulse shrink-0">
            <span className="absolute -top-3 -left-3 text-2xl transform -rotate-12 select-none">👑</span>
            {userProfile.name.charAt(0).toUpperCase()}
          </div>

          <div className="flex-1 space-y-2 text-center md:text-left">
            <div className="flex flex-col md:flex-row md:items-center gap-2">
              <h2 
                className="text-2xl font-black text-white uppercase tracking-tight font-heading select-none"
              >
                {userProfile.name}
              </h2>
              <span className="bg-esSecondary/15 text-esSecondary border border-esSecondary/25 text-[9px] font-mono font-black px-3 py-1 rounded-full w-max mx-auto md:mx-0 uppercase tracking-widest">
                🛡️ {appStrings.profile.levelLabel} {userProfile.wonCount >= 10 ? appStrings.profile.levelPlatinum : appStrings.profile.levelElite}
              </span>
            </div>

            <p className="text-xs text-esTextSecondary max-w-md leading-relaxed">
              {appStrings.profile.bioDesc}
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs font-mono font-bold text-esTextSecondary pt-1">
              <span className="flex items-center gap-1.5">
                <Mail size={12} className="text-esPrimary" />
                {userProfile.email}
              </span>
              <span className="hidden md:inline">•</span>
              <span className="flex items-center gap-1.5">
                <Phone size={12} className="text-esSecondary" />
                {userProfile.phone}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid statistics tiles */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-[#1F2633] border border-[#2B313D] rounded-2xl p-6 text-left shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] text-esTextSecondary font-mono font-black uppercase tracking-widest">{appStrings.profile.playedHeader}</span>
            <Trophy size={14} className="text-esPrimary" />
          </div>
          <p className="text-3xl font-black text-white font-mono">{userProfile.playedCount}</p>
          <p className="text-[10px] text-esTextSecondary/60 font-mono tracking-wider mt-1 uppercase">{appStrings.profile.playedSub}</p>
        </div>

        <div className="bg-[#1F2633] border border-[#2B313D] rounded-2xl p-6 text-left shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] text-esTextSecondary font-mono font-black uppercase tracking-widest">{appStrings.profile.wonHeader}</span>
            <Award size={14} className="text-esSecondary" />
          </div>
          <p className="text-3xl font-black text-white font-mono">{userProfile.wonCount}</p>
          <p className="text-[10px] text-esTextSecondary/60 font-mono tracking-wider mt-1 uppercase">{appStrings.profile.wonSub}</p>
        </div>

        <div className="bg-[#1F2633] border border-[#2B313D] rounded-2xl p-6 text-left shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] text-esTextSecondary font-mono font-black uppercase tracking-widest">{appStrings.profile.winRateHeader}</span>
            <span className="text-xs font-mono text-[#4CAF50] font-black">{winRate}%</span>
          </div>
          <p className="text-3xl font-black text-[#4CAF50] font-mono">{winRate}%</p>
          <p className="text-[10px] text-esTextSecondary/60 font-mono tracking-wider mt-1 uppercase">{appStrings.profile.winRateSub}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Achievements */}
        <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
          <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-3">
            {appStrings.profile.achievementsHeader}
          </h4>

          <div className="space-y-3">
            <div className="flex items-center gap-3.5 bg-[#1F2633]/60 p-3.5 rounded-2xl border border-[#2B313D]/70">
              <span className="text-2xl shrink-0">🎯</span>
              <div className="text-left">
                <h5 className="text-xs font-black text-white uppercase font-heading">{appStrings.profile.ach1Title}</h5>
                <p className="text-[10px] text-esTextSecondary mt-0.5">{appStrings.profile.ach1Desc}</p>
              </div>
            </div>

            <div className="flex items-center gap-3.5 bg-[#1F2633]/60 p-3.5 rounded-2xl border border-[#2B313D]/70">
              <span className="text-2xl shrink-0">💎</span>
              <div className="text-left">
                <h5 className="text-xs font-black text-white uppercase font-heading">{appStrings.profile.ach2Title}</h5>
                <p className="text-[10px] text-esTextSecondary mt-0.5">{appStrings.profile.ach2Desc}</p>
              </div>
            </div>

            <div className="flex items-center gap-3.5 bg-[#1F2633]/60 p-3.5 rounded-2xl border border-[#2B313D]/70">
              <span className="text-2xl shrink-0">👑</span>
              <div className="text-left">
                <h5 className="text-xs font-black text-white uppercase font-heading">{appStrings.profile.ach3Title}</h5>
                <p className="text-[10px] text-esTextSecondary mt-0.5">{appStrings.profile.ach3Desc}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Profile Settings */}
        <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
          <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-3 flex items-center justify-between">
            <span>PROFILE SETTINGS</span>
            <span className="text-[9px] font-mono font-black text-esPrimary bg-esPrimary/10 border border-esPrimary/25 px-2 py-0.5 rounded uppercase tracking-widest">PERSONAL</span>
          </h4>

          <div className="space-y-4">
            <div className="space-y-2 text-left">
              <label className="text-[10px] font-mono font-black text-esTextSecondary uppercase tracking-wider block">
                GLADIATOR USERNAME
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  placeholder="Enter custom username"
                  className="flex-1 bg-[#0B0F14] border border-[#2B313D] rounded-xl px-3 py-2 text-xs text-white placeholder-esTextSecondary/30 focus:outline-none focus:border-esPrimary font-mono font-bold"
                />
                <button
                  type="button"
                  onClick={handleSaveUsername}
                  disabled={!tempName.trim() || tempName.trim() === userProfile.name}
                  className="px-4 py-2 bg-gradient-to-r from-esPrimary to-esSecondary disabled:from-gray-500/20 disabled:to-gray-500/20 disabled:text-gray-500/40 text-[#0B0F14] font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer whitespace-nowrap"
                >
                  SAVE
                </button>
              </div>
              {saveSuccess && (
                <p className="text-[10px] text-[#4CAF50] font-mono uppercase font-black mt-1 animate-pulse">
                  ✓ Username updated successfully!
                </p>
              )}
            </div>
          </div>
        </div>

        {/* System Settings info */}
        <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
          <h4 className="text-xs font-black text-white uppercase tracking-wider border-b border-[#2B313D]/60 pb-3">
            {appStrings.profile.envHeader}
          </h4>

          <div className="space-y-2.5 font-mono text-[10px] text-esTextSecondary">
            <div className="flex justify-between items-center py-2 border-b border-[#2B313D]/30">
              <span>{appStrings.profile.envLabel}</span>
              <span className="text-white font-bold font-mono">{appStrings.profile.envValue}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-[#2B313D]/30">
              <span>{appStrings.profile.sdkLabel}</span>
              <span className="text-white font-bold font-mono">{appStrings.profile.sdkValue}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-[#2B313D]/30">
              <span>{appStrings.profile.dbLabel}</span>
              <span className="text-[#4CAF50] font-bold font-mono">{appStrings.profile.dbValue}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span>{appStrings.profile.cryptoLabel}</span>
              <span className="text-esSecondary font-bold font-mono">{appStrings.profile.cryptoValue}</span>
            </div>
          </div>

          {isUserAdmin && (
            <div className="bg-[#1F2633] border border-[#2B313D] rounded-2xl p-4 flex items-center justify-between text-xs font-bold">
              <div className="flex items-center gap-2 text-white font-heading">
                <Shield size={14} className="text-esPrimary" />
                <span>{appStrings.profile.adminLobbyLabel}</span>
              </div>
              <span className="bg-esSecondary/10 text-esSecondary px-3 py-1 rounded font-mono font-black text-[9px] border border-esSecondary/25">
                {appStrings.profile.authorizedLabel}
              </span>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}

