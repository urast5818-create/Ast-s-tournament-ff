import React from 'react';
import { Award, Zap, Shield, Sparkles } from 'lucide-react';
import { UserProfile } from '../types';
import { appStrings } from '../config/appStrings';

interface LeaderboardProps {
  sortedLeaderboard: any[];
  userProfile: UserProfile;
  onSelectPlayer: (player: any) => void;
  onSimulateVictory: () => void;
}

export default function Leaderboard({
  sortedLeaderboard,
  userProfile,
  onSelectPlayer,
  onSimulateVictory,
}: LeaderboardProps) {
  return (
    <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 space-y-6 shadow-xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-esSecondary/5 to-transparent pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#2B313D]/60 pb-4">
        <div className="flex items-center gap-2">
          <Award size={18} className="text-esSecondary" />
          <h3 className="text-sm font-black text-white uppercase tracking-wider font-heading">
            {appStrings.leaderboard.title}
          </h3>
        </div>
        <span className="text-[9px] font-mono font-black text-esPrimary bg-esPrimary/10 border border-esPrimary/25 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
          {appStrings.leaderboard.seasonBadge}
        </span>
      </div>

      {/* Action: Record Victory Button */}
      <button 
        onClick={onSimulateVictory}
        className="w-full py-3.5 bg-gradient-to-r from-esPrimary/15 via-esSecondary/10 to-esPrimary/5 hover:from-esPrimary/20 hover:via-esSecondary/15 hover:to-esPrimary/10 border border-esPrimary/30 hover:border-esPrimary/60 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all duration-300 shadow-md hover:shadow-[0_0_15px_rgba(255,138,0,0.15)] flex items-center justify-center gap-2 cursor-pointer font-mono group"
      >
        <Zap size={12} className="text-esSecondary animate-bounce group-hover:scale-125 transition-transform" />
        <span>{appStrings.leaderboard.simulateButtonText}</span>
      </button>

      {/* Players List */}
      <div className="space-y-3">
        {sortedLeaderboard.map((player, idx) => {
          const isUser = player.uid === userProfile.uid;
          const standing = idx + 1;
          
          // Custom avatar colors matching theme (Orange/Gold instead of Blue)
          let avatarColor = "from-amber-500 to-orange-700";
          if (standing === 1) avatarColor = "from-yellow-400 via-amber-500 to-yellow-600";
          else if (standing === 2) avatarColor = "from-amber-600 to-orange-600";
          else if (isUser) avatarColor = "from-orange-500 to-amber-700";

          return (
            <div 
              key={player.uid}
              onClick={() => onSelectPlayer(player)}
              className={`p-3.5 rounded-2xl border transition-all duration-300 flex items-center justify-between cursor-pointer group ${
                isUser 
                  ? 'bg-gradient-to-r from-esPrimary/15 to-[#1F2633] border-esPrimary/50 shadow-md shadow-esPrimary/5' 
                  : 'bg-[#1F2633]/60 border-[#2B313D] hover:border-[#2B313D]/90'
              }`}
            >
              {/* Left detail */}
              <div className="flex items-center gap-3">
                {/* Standing label */}
                <div className="w-5 text-center text-xs font-mono font-black text-esTextSecondary">
                  {standing === 1 ? '👑' : `#${standing}`}
                </div>

                {/* Avatar sphere */}
                <div className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${avatarColor} flex items-center justify-center font-black text-[#0B0F14] text-xs shadow-md relative`}>
                  {standing === 1 && (
                    <span className="absolute -top-1.5 -left-1.5 text-[9px] transform -rotate-12 select-none">👑</span>
                  )}
                  {player.name.charAt(0).toUpperCase()}
                </div>

                {/* Info details */}
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-xs font-extrabold truncate max-w-[120px] ${isUser ? "text-esPrimary" : "text-white"}`}>
                      {player.name}
                    </span>
                    {isUser && (
                      <span className="bg-esPrimary/20 text-esPrimary text-[6px] px-1.5 py-0.5 rounded font-black font-mono">{appStrings.leaderboard.youBadge}</span>
                    )}
                  </div>
                  <span className="text-[8px] text-esTextSecondary font-mono block uppercase tracking-wider mt-0.5">
                    {player.tier} • {player.favWeapon}
                  </span>
                </div>
              </div>

              {/* Right statistics */}
              <div className="text-right">
                <p className="text-xs font-mono font-black text-esSecondary">{player.wonCount} {appStrings.leaderboard.winsLabel}</p>
                <p className="text-[8px] text-esTextSecondary font-mono uppercase tracking-wider mt-0.5">
                  {player.playedCount > 0 ? ((player.wonCount / player.playedCount) * 100).toFixed(0) : 0}% {appStrings.leaderboard.winRateLabel}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <p className="text-[8px] font-mono text-esTextSecondary/60 text-center uppercase tracking-wider select-none pt-2">
        {appStrings.leaderboard.tipText}
      </p>
    </div>
  );
}

