import React, { useState } from 'react';
import { 
  Trophy, Layers, Wallet, User, Shield, FileCode, LogOut, Send, ChevronRight, ChevronLeft, Gift, Smartphone
} from 'lucide-react';
import { UserProfile } from '../types';
import { appStrings } from '../config/appStrings';
import { AppSettings } from '../dbStore';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: any) => void;
  userProfile: UserProfile;
  onLogout: () => void;
  settings: AppSettings;
  isAdminPanelUnlocked?: boolean;
}

export default function Sidebar({
  currentTab,
  setCurrentTab,
  userProfile,
  onLogout,
  settings,
  isAdminPanelUnlocked,
}: SidebarProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isLocked, setIsLocked] = useState(false);

  const isExpanded = isHovered || isLocked;

  const showQuests = settings.features.dailyReward || settings.features.referral || settings.features.supportCenter;
  const menuItems = [
    { id: 'home', label: appStrings.sidebar.exploreLabel, icon: Trophy },
    { id: 'matches', label: appStrings.sidebar.myRoomsLabel, icon: Layers },
    { id: 'wallet', label: appStrings.sidebar.walletLabel, icon: Wallet },
    { id: 'profile', label: appStrings.sidebar.profileLabel, icon: User },
  ];

  if (showQuests) {
    menuItems.push({ id: 'quests', label: 'Arena Hub', icon: Gift });
  }

  // Developer tab as first-class citizen!
  menuItems.push({ id: 'developer', label: appStrings.sidebar.developerLabel, icon: FileCode });

  return (
    <aside 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`hidden md:flex flex-col min-h-screen bg-[#171C24] border-r border-[#2B313D] relative z-30 transition-all duration-300 ease-out shrink-0 select-none ${
        isExpanded ? 'w-64' : 'w-[72px]'
      }`}
      id="desktop-sidebar"
    >
      {/* Top Banner Branding */}
      <div className={`p-4 border-b border-[#2B313D] flex items-center justify-between ${isExpanded ? 'px-6' : 'px-4'} h-20 shrink-0`}>
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-esPrimary to-esSecondary flex items-center justify-center shadow-lg shadow-esPrimary/20 shrink-0">
            <Trophy size={20} className="text-[#0B0F14]" />
          </div>
          {isExpanded && (
            <div className="text-left animate-in fade-in slide-in-from-left-2 duration-300">
              <h2 className="text-sm font-black text-white tracking-wide uppercase font-heading whitespace-nowrap">
                {settings.appName || appStrings.sidebar.brandName}
              </h2>
              <span className="bg-esSecondary/10 text-esSecondary text-[8px] font-mono font-black px-2 py-0.5 rounded border border-esSecondary/25 block w-max uppercase tracking-wider mt-0.5">
                {appStrings.sidebar.brandBadge}
              </span>
            </div>
          )}
        </div>

        {/* Manual Lock/Unlock toggle only visible when expanded */}
        {isExpanded && (
          <button 
            onClick={() => setIsLocked(!isLocked)}
            className="p-1.5 rounded-lg bg-[#1F2633] border border-[#2B313D] text-esTextSecondary hover:text-white transition-colors cursor-pointer ml-2"
            title={isLocked ? "Unpin sidebar" : "Pin sidebar"}
          >
            {isLocked ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
          </button>
        )}
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 p-3 space-y-2 overflow-y-auto overflow-x-hidden">
        {menuItems.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`w-full flex items-center rounded-xl font-medium text-xs uppercase tracking-wider transition-all duration-300 relative group cursor-pointer ${
                isExpanded ? 'px-4 py-3.5 gap-3.5' : 'px-0 py-3.5 justify-center'
              } ${
                isActive 
                  ? 'bg-gradient-to-r from-esPrimary/10 to-esSecondary/5 text-white border-l-4 border-esPrimary font-bold' 
                  : 'text-esTextSecondary hover:text-white hover:bg-[#1F2633]/60 border-l-4 border-transparent'
              }`}
              title={!isExpanded ? item.label : undefined}
            >
              <Icon 
                size={18} 
                className={`transition-colors duration-300 shrink-0 ${
                  isActive ? 'text-esPrimary' : 'text-esTextSecondary group-hover:text-esPrimary'
                }`} 
              />
              {isExpanded && (
                <span className="animate-in fade-in slide-in-from-left-2 duration-300 whitespace-nowrap">
                  {item.label}
                </span>
              )}
              {isActive && isExpanded && (
                <span className="absolute right-4 w-1.5 h-1.5 rounded-full bg-esPrimary shadow-[0_0_8px_rgba(255,138,0,0.8)]" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom User Card / Wallet Balance Summary */}
      <div className={`p-3 border-t border-[#2B313D] space-y-4 bg-[#0B0F14]/50 shrink-0 ${isExpanded ? 'px-4' : 'px-3'}`}>
        <div className={`flex items-center bg-[#1F2633]/60 p-2.5 rounded-2xl border border-[#2B313D] relative overflow-hidden ${
          isExpanded ? 'gap-3' : 'justify-center'
        }`}>
          {/* Avatar */}
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-esPrimary to-esSecondary flex items-center justify-center shadow-md font-black text-[#0B0F14] text-sm shrink-0">
            {userProfile.name.charAt(0).toUpperCase()}
          </div>
          {isExpanded && (
            <div className="text-left flex-1 min-w-0 animate-in fade-in slide-in-from-left-2 duration-300">
              <h4 className="text-xs font-bold text-white truncate font-heading">{userProfile.name}</h4>
              <p className="text-[9px] text-esTextSecondary truncate font-mono mt-0.5">{userProfile.email}</p>
            </div>
          )}
        </div>

        {/* Balance metrics */}
        {isExpanded ? (
          <div className="grid grid-cols-2 gap-2 text-left animate-in fade-in duration-300">
            <div className="bg-[#171C24] border border-[#2B313D] p-2 rounded-xl">
              <span className="text-[8px] font-mono text-esTextSecondary block uppercase tracking-wider">MAIN</span>
              <span className="text-xs font-bold text-esPrimary font-mono block mt-0.5">${userProfile.walletBalance.toFixed(2)}</span>
            </div>
            <div className="bg-[#171C24] border border-[#2B313D] p-2 rounded-xl">
              <span className="text-[8px] font-mono text-esTextSecondary block uppercase tracking-wider">BONUS</span>
              <span className="text-xs font-bold text-esSecondary font-mono block mt-0.5">${userProfile.bonusBalance.toFixed(2)}</span>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-1 items-center">
            <span className="text-[8px] font-mono text-esPrimary font-bold">${userProfile.walletBalance.toFixed(0)}</span>
          </div>
        )}

        {/* Telegram Direct Action Button */}
        {isExpanded ? (
          <div className="bg-gradient-to-r from-esPrimary/10 to-[#171C24] border border-esPrimary/20 rounded-xl p-3 flex items-center justify-between animate-in fade-in duration-300">
            <div className="text-left space-y-0.5">
              <span className="text-[8px] font-mono text-esSecondary font-bold block uppercase tracking-wider">{appStrings.sidebar.telegramHeader}</span>
              <span className="text-[9px] text-white block">{appStrings.sidebar.telegramSub}</span>
            </div>
            <a 
              href={settings.supportTelegram || "https://t.me/your_channel"} 
              target="_blank" 
              rel="noreferrer"
              className="w-7 h-7 bg-gradient-to-tr from-esPrimary to-esSecondary rounded-lg flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
            >
              <Send size={10} className="text-[#0B0F14] transform -rotate-12" />
            </a>
          </div>
        ) : (
          <div className="flex justify-center">
            <a 
              href={settings.supportTelegram || "https://t.me/your_channel"} 
              target="_blank" 
              rel="noreferrer"
              className="w-8 h-8 bg-gradient-to-tr from-esPrimary to-esSecondary rounded-xl flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
              title="Telegram channel"
            >
              <Send size={12} className="text-[#0B0F14] transform -rotate-12" />
            </a>
          </div>
        )}

        {/* Sign Out Trigger */}
        <button 
          onClick={onLogout}
          className={`w-full py-3 hover:bg-[#F44336]/10 text-esTextSecondary hover:text-[#F44336] rounded-xl text-xs font-bold font-mono transition-all duration-300 flex items-center justify-center gap-2 border border-transparent hover:border-[#F44336]/20 cursor-pointer ${
            isExpanded ? 'px-4' : 'px-0'
          }`}
          title="Sign Out"
        >
          <LogOut size={14} className="shrink-0" />
          {isExpanded && <span className="animate-in fade-in duration-300">{appStrings.sidebar.signOutLabel}</span>}
        </button>
      </div>
    </aside>
  );
}

