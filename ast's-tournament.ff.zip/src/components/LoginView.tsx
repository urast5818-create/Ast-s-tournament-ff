import React, { useState, useEffect, useRef } from 'react';
import { Phone, Trophy, ArrowRight, ArrowLeft, RefreshCw, CheckCircle, Shield } from 'lucide-react';
import { appStrings } from '../config/appStrings';
import { sendPhoneOTP } from '../firebase';
import { FirestoreDb } from '../dbStore';
import { UserProfile } from '../types';
import firebaseConfig from '../firebase-applet-config.json';

interface LoginViewProps {
  onLoginSuccess: (user: UserProfile) => void;
  onTriggerAdmin?: () => void;
}

export default function LoginView({ onLoginSuccess, onTriggerAdmin }: LoginViewProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  
  // OTP Digits state
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Sending/verifying loading states
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // For storing actual firebase result if real, or simulated code if mock
  const [isMockFlow, setIsMockFlow] = useState(false);
  const [mockCode, setMockCode] = useState('');
  const [firebaseConfirmation, setFirebaseConfirmation] = useState<any>(null);

  // Development banner state
  const [showMockToast, setShowMockToast] = useState(false);

  // Resend OTP countdown
  const [countdown, setCountdown] = useState(0);

  // Secret Admin states
  const [adminTaps, setAdminTaps] = useState<number[]>([]);
  const [showAdminSecretDialog, setShowAdminSecretDialog] = useState(false);
  const [adminSecretUsername, setAdminSecretUsername] = useState('');
  const [adminSecretPassword, setAdminSecretPassword] = useState('');
  const [adminDialogError, setAdminDialogError] = useState<string | null>(null);

  const handleTrophyClick = () => {
    const now = Date.now();
    const updatedTaps = [...adminTaps, now].filter(t => now - t <= 3000);
    setAdminTaps(updatedTaps);

    if (updatedTaps.length >= 5) {
      setAdminTaps([]);
      setShowAdminSecretDialog(true);
      setAdminSecretUsername('');
      setAdminSecretPassword('');
      setAdminDialogError(null);
    }
  };

  const handleVerifyAdminCredentials = () => {
    const targetUser = (firebaseConfig as any).adminUsername || 'admin';
    const targetPass = (firebaseConfig as any).adminPassword || 'adminPassword123';
    if (adminSecretUsername === targetUser && adminSecretPassword === targetPass) {
      setShowAdminSecretDialog(false);
      if (onTriggerAdmin) {
        onTriggerAdmin();
      }
    } else {
      setAdminDialogError('Access Denied');
    }
  };

  // Countdown timer effect
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // Handle Send OTP
  const handleSendOTP = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!phoneNumber.trim()) return;

    setLoading(true);
    setErrorMsg(null);
    setShowMockToast(false);

    try {
      const result = await sendPhoneOTP(phoneNumber, 'recaptcha-container');
      
      if (result.success) {
        setIsMockFlow(result.isMock);
        if (result.isMock) {
          setMockCode(result.mockOtp || '123456');
          setShowMockToast(true);
        } else {
          setFirebaseConfirmation(result.confirmationResult);
        }
        
        // Advance to OTP step
        setStep('otp');
        setOtpDigits(['', '', '', '', '', '']);
        setCountdown(30); // 30 second resend cooldown
      } else {
        setErrorMsg(result.error || 'Failed to send OTP. Please check the mobile number and try again.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred while sending OTP.');
    } finally {
      setLoading(false);
    }
  };

  // Handle Verify OTP and Login/Signup
  const handleVerifyOTP = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const enteredOtp = otpDigits.join('');
    if (enteredOtp.length !== 6) return;

    setLoading(true);
    setErrorMsg(null);

    try {
      let isVerified = false;
      let phoneToUse = phoneNumber.trim().replace(/[\s-()]/g, '');

      // Standardize phone number for user query (clean spaces and prefix with +91 if 10-digit)
      if (!phoneToUse.startsWith('+')) {
        if (phoneToUse.startsWith('0')) {
          phoneToUse = phoneToUse.substring(1);
        }
        if (phoneToUse.length === 10) {
          phoneToUse = '+91' + phoneToUse;
        } else {
          phoneToUse = '+' + phoneToUse;
        }
      }

      if (isMockFlow) {
        // Mock verification check
        if (enteredOtp === mockCode || enteredOtp === '123456') {
          isVerified = true;
        } else {
          setErrorMsg('Invalid simulated verification code. Please try again.');
        }
      } else {
        // Real Firebase verification check
        try {
          const userCredential = await firebaseConfirmation.confirm(enteredOtp);
          if (userCredential && userCredential.user) {
            isVerified = true;
            phoneToUse = userCredential.user.phoneNumber || phoneToUse;
          }
        } catch (verifyError: any) {
          setErrorMsg(verifyError.message || 'Invalid Firebase OTP code. Please enter the correct code.');
        }
      }

      if (isVerified) {
        setShowMockToast(false);
        
        // Look up user profile in local store
        const users = FirestoreDb.getUsers();
        let matchedUser = users.find(u => u.phone.replace(/[\s-()]/g, '') === phoneToUse.replace(/[\s-()]/g, ''));

        if (!matchedUser) {
          // If no match found, create account automatically
          const cleanedPhoneDigits = phoneToUse.replace(/\D/g, '');
          const phoneLastFour = cleanedPhoneDigits.slice(-4) || '9999';
          
          matchedUser = {
            uid: `user_${Date.now()}`,
            name: `Gladiator_${phoneLastFour}`,
            email: `${cleanedPhoneDigits || 'new_player'}@astsarena.com`,
            phone: phoneToUse,
            walletBalance: 0.0,
            bonusBalance: 50.0, // Standard signup bonus coins to participate in tournaments
            playedCount: 0,
            wonCount: 0,
            totalEarnings: 0.0,
            isAdmin: false
          };

          // Append to user database
          const updatedUsers = [...users, matchedUser];
          FirestoreDb.saveUsers(updatedUsers);
        }

        // Successfully log the user in
        onLoginSuccess(matchedUser);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Verification failed. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  // Automatically trigger verification when all digits are filled
  useEffect(() => {
    const fullOtp = otpDigits.join('');
    if (fullOtp.length === 6) {
      handleVerifyOTP();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [otpDigits]);

  // OTP Digits keyboard handlers
  const handleDigitChange = (value: string, index: number) => {
    const char = value.slice(-1);
    if (char && !/^\d$/.test(char)) return;

    const newDigits = [...otpDigits];
    newDigits[index] = char;
    setOtpDigits(newDigits);

    // Auto-focus next input
    if (char && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === 'Backspace') {
      if (!otpDigits[index] && index > 0) {
        const newDigits = [...otpDigits];
        newDigits[index - 1] = '';
        setOtpDigits(newDigits);
        inputRefs.current[index - 1]?.focus();
      } else {
        const newDigits = [...otpDigits];
        newDigits[index] = '';
        setOtpDigits(newDigits);
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').trim();
    if (!/^\d{6}$/.test(pastedData)) return;

    const digits = pastedData.split('');
    setOtpDigits(digits);
    // Focus last input and blur to let effect trigger automatically
    inputRefs.current[5]?.focus();
  };

  return (
    <div className="flex-1 min-h-screen flex items-center justify-center bg-[#0B0F14] text-white p-6 relative overflow-hidden select-none">
      {/* Invisible Recaptcha container for Firebase Auth */}
      <div id="recaptcha-container" className="absolute invisible pointer-events-none"></div>

      {/* Simulated OTP Overlay Toast */}
      {showMockToast && (
        <div className="absolute top-6 left-1/2 -translate-x-1/2 max-w-sm w-full bg-[#171C24] border border-amber-500/40 rounded-2xl p-4 shadow-2xl z-50 animate-in slide-in-from-top-6 duration-300">
          <div className="flex items-start gap-3 text-left">
            <Shield className="text-amber-500 shrink-0 mt-0.5" size={16} />
            <div className="space-y-1">
              <span className="text-[8px] font-mono font-black text-amber-500 uppercase tracking-widest block">DEVELOPER SANDBOX</span>
              <p className="text-xs font-bold text-white uppercase font-heading">Simulated Firebase SMS Sent</p>
              <p className="text-[10px] text-esTextSecondary leading-relaxed">
                Use verification code: <strong className="text-amber-400 text-xs font-mono tracking-wider select-all bg-[#0B0F14] px-2 py-0.5 rounded border border-amber-500/20">{mockCode}</strong>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Glow Effects */}
      <div className="absolute top-[20%] left-[20%] w-[450px] h-[450px] bg-esPrimary/5 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[20%] w-[450px] h-[450px] bg-esSecondary/5 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-md w-full relative z-10 animate-in fade-in duration-500">
        
        {/* Brand/Header */}
        <div className="text-center mb-8 space-y-3">
          <div 
            onClick={handleTrophyClick}
            className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-esPrimary to-esSecondary shadow-[0_0_30px_rgba(255,138,0,0.2)] cursor-pointer"
          >
            <Trophy size={28} className="text-[#0B0F14]" />
          </div>
          <div>
            <h2 className="text-2xl font-black uppercase text-white tracking-tight">{appStrings.login.title}</h2>
            <p className="text-xs text-esTextSecondary mt-1">{appStrings.login.subtitle}</p>
          </div>
        </div>

        {/* Login Card */}
        <div className="bg-[#171C24]/60 backdrop-blur-md border border-[#2B313D] rounded-3xl p-8 space-y-6 shadow-2xl relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[2px] w-32 bg-gradient-to-r from-transparent via-esPrimary to-transparent" />

          {errorMsg && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-200 text-xs p-3.5 rounded-xl text-left font-mono">
              ⚠️ {errorMsg}
            </div>
          )}

          {step === 'phone' ? (
            /* PHASE 1: ENTER MOBILE NUMBER */
            <form onSubmit={handleSendOTP} className="space-y-5">
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-mono font-bold text-esTextSecondary uppercase tracking-widest block">
                  {appStrings.login.phoneLabel}
                </label>
                <div className="relative">
                  <Phone size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-esTextSecondary" />
                  <input 
                    type="tel"
                    required
                    value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)}
                    placeholder="Enter phone number (e.g. +91 9876543210)"
                    disabled={loading}
                    className="w-full bg-[#0B0F14]/80 border border-[#2B313D] rounded-xl pl-11 pr-4 py-3.5 text-xs text-white placeholder-esTextSecondary/40 focus:outline-none focus:border-esPrimary focus:shadow-[0_0_15px_rgba(255,138,0,0.15)] focus:ring-1 focus:ring-esPrimary font-mono transition-all duration-300"
                  />
                </div>
              </div>

              <button 
                type="submit"
                disabled={loading || !phoneNumber.trim()}
                className={`w-full py-4 bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] font-black text-xs uppercase tracking-widest rounded-xl transition-all duration-300 shadow-md shadow-esPrimary/10 hover:shadow-[0_0_20px_rgba(255,138,0,0.3)] flex items-center justify-center gap-2 group cursor-pointer ${
                  loading ? 'opacity-80 cursor-not-allowed' : ''
                }`}
              >
                {loading ? (
                  <>
                    <RefreshCw size={14} className="animate-spin text-[#0B0F14]" />
                    <span>Sending Security Code...</span>
                  </>
                ) : (
                  <>
                    <span>Send Verification Code</span>
                    <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-300" />
                  </>
                )}
              </button>
            </form>
          ) : (
            /* PHASE 2: ENTER OTP CODE */
            <form onSubmit={handleVerifyOTP} className="space-y-6">
              <div className="space-y-3 text-left">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono font-bold text-esTextSecondary uppercase tracking-widest block">
                    Verification Code (OTP)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setStep('phone');
                      setShowMockToast(false);
                      setErrorMsg(null);
                    }}
                    className="text-[10px] font-mono text-esPrimary hover:text-esSecondary uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <ArrowLeft size={10} />
                    <span>Change Phone</span>
                  </button>
                </div>
                
                {/* Spaced out 6-digit OTP fields */}
                <div className="grid grid-cols-6 gap-2">
                  {otpDigits.map((digit, idx) => (
                    <input
                      key={idx}
                      ref={el => inputRefs.current[idx] = el}
                      type="text"
                      maxLength={1}
                      pattern="\d*"
                      value={digit}
                      onChange={e => handleDigitChange(e.target.value, idx)}
                      onKeyDown={e => handleKeyDown(e, idx)}
                      onPaste={idx === 0 ? handlePaste : undefined}
                      disabled={loading}
                      placeholder="•"
                      className="w-full h-12 text-center bg-[#0B0F14]/80 border border-[#2B313D] rounded-xl text-lg font-black text-white placeholder-esTextSecondary/20 focus:outline-none focus:border-esPrimary focus:shadow-[0_0_12px_rgba(255,138,0,0.12)] focus:ring-1 focus:ring-esPrimary transition-all duration-300"
                    />
                  ))}
                </div>
              </div>

              <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-wider">
                <span className="text-esTextSecondary/50">Sent code to:</span>
                <span className="text-white font-bold">{phoneNumber}</span>
              </div>

              <div className="space-y-3">
                <button 
                  type="submit"
                  disabled={loading || otpDigits.join('').length !== 6}
                  className={`w-full py-4 bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] font-black text-xs uppercase tracking-widest rounded-xl transition-all duration-300 shadow-md shadow-esPrimary/10 hover:shadow-[0_0_20px_rgba(255,138,0,0.3)] flex items-center justify-center gap-2 group cursor-pointer ${
                    loading || otpDigits.join('').length !== 6 ? 'opacity-80 cursor-not-allowed' : ''
                  }`}
                >
                  {loading ? (
                    <>
                      <RefreshCw size={14} className="animate-spin text-[#0B0F14]" />
                      <span>Authenticating...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle size={14} className="text-[#0B0F14]" />
                      <span>Verify & Enter Arena</span>
                    </>
                  )}
                </button>

                {/* Resend button */}
                <div className="text-center">
                  {countdown > 0 ? (
                    <span className="text-[9px] font-mono text-esTextSecondary/50 uppercase tracking-widest">
                      Resend OTP in {countdown}s
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSendOTP()}
                      disabled={loading}
                      className="text-[10px] font-mono text-esSecondary hover:text-esPrimary uppercase tracking-widest font-black hover:underline cursor-pointer transition-colors"
                    >
                      Resend Code (OTP)
                    </button>
                  )}
                </div>
              </div>
            </form>
          )}

          {/* Arena account helper */}
          <div className="bg-[#1F2633]/50 border border-[#2B313D] rounded-2xl p-4 text-left">
            <h5 className="text-[10px] font-mono font-black text-esSecondary uppercase tracking-wider mb-1">
              AUTOMATIC ACCOUNT SYNCHRONIZATION
            </h5>
            <p className="text-[10px] text-esTextSecondary leading-relaxed font-mono">
              We verify your identities safely using Firebase SMS One-Time Passwords. Existing profiles are synchronized instantly; new gladiators receive 50 Free Arena Coins upon verification.
            </p>
          </div>
        </div>

        <div className="text-center mt-6 text-[10px] text-esTextSecondary/40 font-mono uppercase tracking-wider">
          {appStrings.login.footerSecureText}
        </div>
      </div>

      {showAdminSecretDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl max-w-sm w-full p-6 shadow-2xl relative space-y-4">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[2px] w-32 bg-gradient-to-r from-transparent via-esPrimary to-transparent" />
            
            <div className="text-center space-y-1">
              <Shield className="text-esPrimary mx-auto mb-2" size={32} />
              <h3 className="text-base font-black text-white uppercase tracking-tight font-heading">
                Secret Admin Login
              </h3>
              <p className="text-[10px] text-esTextSecondary">
                Enter credentials to authorize Admin Panel access.
              </p>
            </div>

            {adminDialogError && (
              <div className="bg-red-500/10 border border-red-500/30 text-red-200 text-[10px] p-2.5 rounded-xl text-center font-mono uppercase tracking-wide">
                ⚠️ {adminDialogError}
              </div>
            )}

            <div className="space-y-3">
              <div className="space-y-1 text-left">
                <label className="text-[8px] font-mono font-bold text-esTextSecondary uppercase tracking-widest block">
                  Secret Username
                </label>
                <input
                  type="text"
                  value={adminSecretUsername}
                  onChange={(e) => setAdminSecretUsername(e.target.value)}
                  placeholder="Username"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl px-3 py-2 text-xs text-white placeholder-esTextSecondary/30 focus:outline-none focus:border-esPrimary font-mono"
                />
              </div>

              <div className="space-y-1 text-left">
                <label className="text-[8px] font-mono font-bold text-esTextSecondary uppercase tracking-widest block">
                  Secret Password
                </label>
                <input
                  type="password"
                  value={adminSecretPassword}
                  onChange={(e) => setAdminSecretPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl px-3 py-2 text-xs text-white placeholder-esTextSecondary/30 focus:outline-none focus:border-esPrimary font-mono"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleVerifyAdminCredentials();
                    }
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAdminSecretDialog(false)}
                className="py-2.5 bg-[#1F2633] hover:bg-[#2B313D] border border-[#2B313D] text-white font-bold text-[10px] uppercase tracking-wider rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleVerifyAdminCredentials}
                className="py-2.5 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] font-black text-[10px] uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-md shadow-esPrimary/10 hover:shadow-esPrimary/25"
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
