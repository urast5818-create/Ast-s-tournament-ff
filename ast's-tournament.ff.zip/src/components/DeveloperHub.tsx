import React from 'react';
import { FileCode, Copy, CheckCircle, Terminal, HelpCircle, ChevronRight, Hammer } from 'lucide-react';
import { appStrings } from '../config/appStrings';

interface DeveloperHubProps {
  DART_FILES: Record<string, { path: string; code: string }>;
  activeCodeTab: string;
  setActiveCodeTab: (tab: string) => void;
  copiedCodeFile: string | null;
  onCopyCode: (id: string, code: string) => void;
}

export default function DeveloperHub({
  DART_FILES,
  activeCodeTab,
  setActiveCodeTab,
  copiedCodeFile,
  onCopyCode,
}: DeveloperHubProps) {
  
  const currentFile = DART_FILES[activeCodeTab] || DART_FILES.main_dart;

  return (
    <div className="space-y-6 animate-in fade-in duration-300 text-left">
      
      {/* Title */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileCode size={18} className="text-esSecondary" />
          <h3 className="text-sm font-black text-white uppercase tracking-wider font-heading">
            {appStrings.devHub.title}
          </h3>
        </div>
        <span className="text-[9px] font-mono font-black text-esPrimary bg-esPrimary/10 border border-esPrimary/25 px-3 py-1 rounded-full uppercase tracking-wider">
          {appStrings.devHub.repoBadge}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Repo File Explorer and Code Viewer (8 cols) */}
        <div className="lg:col-span-8 bg-[#171C24] border border-[#2B313D] rounded-3xl overflow-hidden shadow-xl flex flex-col">
          
          {/* File Explorer tabs header */}
          <div className="bg-[#1F2633] border-b border-[#2B313D] px-4 py-3 flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2 font-mono text-xs text-white">
              <Terminal size={14} className="text-esPrimary" />
              <span>{appStrings.devHub.compilerHeader}</span>
            </div>

            {/* Reset / Copy indicator */}
            <button 
              onClick={() => onCopyCode(activeCodeTab, currentFile.code)}
              className={`px-3 py-1.5 rounded-lg text-[9px] font-mono font-black uppercase tracking-wider transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                copiedCodeFile === activeCodeTab
                  ? 'bg-esSuccess/20 text-esSuccess border border-esSuccess/35'
                  : 'bg-[#0B0F14] hover:bg-esBg/50 text-esTextSecondary hover:text-white border border-[#2B313D]'
              }`}
            >
              {copiedCodeFile === activeCodeTab ? (
                <>
                  <CheckCircle size={10} />
                  <span>{appStrings.devHub.copiedText}</span>
                </>
              ) : (
                <>
                  <Copy size={10} />
                  <span>{appStrings.devHub.copyButtonText}</span>
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 flex-1">
            {/* Sidebar Explorer columns (3 cols) */}
            <div className="md:col-span-4 bg-[#0B0F14]/40 border-r border-[#2B313D] p-3 space-y-1.5 overflow-y-auto max-h-[500px]">
              <span className="text-[8px] font-mono text-esTextSecondary block uppercase tracking-widest px-2 mb-2 font-bold">
                {appStrings.devHub.projectSourceLabel}
              </span>
              {Object.keys(DART_FILES).map(key => {
                const isSelected = activeCodeTab === key;
                return (
                  <button
                    key={key}
                    onClick={() => setActiveCodeTab(key)}
                    className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-left font-mono text-[10px] uppercase truncate transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-esPrimary/10 text-esPrimary font-black border-l-2 border-esPrimary'
                        : 'text-esTextSecondary hover:bg-[#1F2633]/50 hover:text-white'
                    }`}
                  >
                    <FileCode size={11} className={isSelected ? 'text-esPrimary' : 'text-esTextSecondary'} />
                    <span className="truncate">{DART_FILES[key].path.split('/').pop()}</span>
                  </button>
                );
              })}
            </div>

            {/* Right code visual editor column (8 cols) */}
            <div className="md:col-span-8 flex flex-col bg-[#0B0F14]/90 p-4">
              <div className="flex justify-between text-[9px] font-mono text-esTextSecondary uppercase tracking-widest pb-3 border-b border-[#2B313D]/40">
                <span>{appStrings.devHub.filePathLabel}{currentFile.path}</span>
                <span className="text-esSecondary font-bold">{appStrings.devHub.sourceLabel}</span>
              </div>

              {/* Code text frame */}
              <pre className="text-left font-mono text-[10px] leading-relaxed text-slate-300 overflow-auto p-3 max-h-[440px] whitespace-pre-wrap selection:bg-esPrimary/25 select-text">
                <code>{currentFile.code}</code>
              </pre>
            </div>
          </div>
        </div>

        {/* Right Side: Compilation Guide & Sandbox instructions (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Compilation Card */}
          <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2 border-b border-[#2B313D]/40 pb-3">
              <Hammer size={16} className="text-esSecondary" />
              <h4 className="text-xs font-black text-white uppercase tracking-wider">
                {appStrings.devHub.guideHeader}
              </h4>
            </div>

            <p className="text-[10px] text-esTextSecondary leading-relaxed">
              {appStrings.devHub.guideDesc}
            </p>

            <div className="space-y-3.5">
              <div className="space-y-1.5 text-[10px] font-mono">
                <span className="text-esPrimary font-bold block">{appStrings.devHub.step1Title}</span>
                <div className="bg-[#0B0F14] border border-[#2B313D] p-2.5 rounded-lg select-all">
                  flutter pub get
                </div>
              </div>

              <div className="space-y-1.5 text-[10px] font-mono">
                <span className="text-esSecondary font-bold block">{appStrings.devHub.step2Title}</span>
                <div className="bg-[#0B0F14] border border-[#2B313D] p-2.5 rounded-lg select-all text-slate-300">
                  flutter build apk --release
                </div>
              </div>

              <div className="space-y-1.5 text-[10px] font-mono">
                <span className="text-esSecondary font-bold block">{appStrings.devHub.step3Title}</span>
                <div className="bg-[#0B0F14] border border-[#2B313D] p-2.5 rounded-lg select-all text-slate-300">
                  flutter build ipa --no-codesign
                </div>
              </div>
            </div>
          </div>

          {/* Setup Help */}
          <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2 border-b border-[#2B313D]/40 pb-3">
              <HelpCircle size={15} className="text-esPrimary" />
              <h4 className="text-xs font-black text-white uppercase tracking-wider">
                {appStrings.devHub.architectureHeader}
              </h4>
            </div>

            <div className="space-y-2.5 text-[10px] leading-relaxed text-esTextSecondary">
              <div className="flex gap-2 text-left">
                <ChevronRight size={14} className="text-esPrimary shrink-0 mt-0.5" />
                <p><strong>{appStrings.devHub.feature1Title}</strong> {appStrings.devHub.feature1Desc}</p>
              </div>

              <div className="flex gap-2 text-left">
                <ChevronRight size={14} className="text-esPrimary shrink-0 mt-0.5" />
                <p><strong>{appStrings.devHub.feature2Title}</strong> {appStrings.devHub.feature2Desc}</p>
              </div>

              <div className="flex gap-2 text-left">
                <ChevronRight size={14} className="text-esPrimary shrink-0 mt-0.5" />
                <p><strong>{appStrings.devHub.feature3Title}</strong> {appStrings.devHub.feature3Desc}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
