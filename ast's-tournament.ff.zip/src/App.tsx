import React, { useState, useEffect } from 'react';
import { 
  Trophy, RefreshCw, Layers, Calendar, Key, Copy, CheckCircle, 
  Terminal, Shield, FileCode, Clock, Bell, User, Send, Search, Sparkles, Star, Gift, ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';

import { Tournament, Coupon, Transaction, UserProfile } from './types';
import { INITIAL_TOURNAMENTS, INITIAL_COUPONS, DART_FILES } from './data';
import { appStrings } from './config/appStrings';
import { FirestoreDb } from './dbStore';

import SplashView from './components/SplashView';
import LoginView from './components/LoginView';
import Sidebar from './components/Sidebar';
import BottomNav from './components/BottomNav';
import TournamentCard from './components/TournamentCard';
import Leaderboard from './components/Leaderboard';
import WalletView from './components/WalletView';
import ProfileView from './components/ProfileView';
import AdminView from './components/AdminView';
import DeveloperHub from './components/DeveloperHub';
import ArenaHub from './components/ArenaHub';
import EarnTab from './components/EarnTab';

export default function App() {
  // --- STATE DECLARATIONS ---
  const [appState, setAppState] = useState<'splash' | 'login' | 'home'>('splash');
  const [splashProgress, setSplashProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [stringsVersion, setStringsVersion] = useState(0);
  const [splashStatus, setSplashStatus] = useState('Launching Esports Arena environment...');
  const [isAdminPanelUnlocked, setIsAdminPanelUnlocked] = useState(false);
  

  const [currentTab, setCurrentTab] = useState<'home' | 'matches' | 'wallet' | 'profile' | 'admin' | 'developer' | 'quests' | 'earn'>('home');

  // Search & Filter & Favorite state
  const [searchQuery, setSearchQuery] = useState('');
  const [mapFilter, setMapFilter] = useState('ALL');
  const [feeFilter, setFeeFilter] = useState('ALL');
  const [formatFilter, setFormatFilter] = useState('ALL');
  const [favOnlyFilter, setFavOnlyFilter] = useState(false);
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('AST_FAVORITES');
    return saved ? JSON.parse(saved) : [];
  });

  // Selected payment method in join modal
  const [paymentMethod, setPaymentMethod] = useState<'bonus' | 'main' | 'combine'>('bonus');

  useEffect(() => {
    localStorage.setItem('AST_FAVORITES', JSON.stringify(favoriteIds));
  }, [favoriteIds]);

  // Interactive Code Tabs (used in developer hub)
  const [activeCodeTab, setActiveCodeTab] = useState('main_dart');
  const [copiedCodeFile, setCopiedCodeFile] = useState<string | null>(null);

  const [settings, setSettings] = useState(() => FirestoreDb.getSettings());

  // User details - load "user_01" by default, or get from users list
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const list = FirestoreDb.getUsers();
    const adminUser = list.find(u => u.isAdmin);
    return adminUser || {
      uid: "user_01",
      name: "Ast Gamer",
      email: "urast5818@gmail.com",
      phone: "+91 98765 43210",
      walletBalance: 250.0,
      bonusBalance: 50.0,
      playedCount: 14,
      wonCount: 8,
      totalEarnings: 1200.0,
      isAdmin: true
    };
  });

  const DEFAULT_TXS: Transaction[] = [
    { id: "tx_01", type: "DEPOSIT", amount: 100.0, status: "APPROVED", upiTxnId: "UPI993201492", description: "Added to Main Wallet", timestamp: "2026-07-14 10:20" },
    { id: "tx_02", type: "WITHDRAWAL", amount: 50.0, status: "PENDING", upiId: "ast@ybl", description: "Withdrawal to UPI", timestamp: "2026-07-15 08:30" }
  ];

  // Database lists
  const [tournaments, setTournaments] = useState<Tournament[]>(() => FirestoreDb.getTournaments(INITIAL_TOURNAMENTS));
  const [coupons, setCoupons] = useState<Coupon[]>(() => FirestoreDb.getCoupons(INITIAL_COUPONS));
  const [notifications, setNotifications] = useState<string[]>([
    "Welcome to Ast's Free Fire Arena! Get ready to claim your Booyah!",
    "Promo coupon code GOLDREDEEM is now active for a limited time.",
    "Lobby Grand Duels updated with Custom Room login credentials."
  ]);
  const [transactions, setTransactions] = useState<Transaction[]>(() => FirestoreDb.getTransactions(DEFAULT_TXS));

  // Sync back to FirestoreDb
  useEffect(() => {
    FirestoreDb.saveTournaments(tournaments);
  }, [tournaments]);

  useEffect(() => {
    FirestoreDb.saveCoupons(coupons);
  }, [coupons]);

  useEffect(() => {
    FirestoreDb.saveTransactions(transactions);
  }, [transactions]);

  useEffect(() => {
    const users = FirestoreDb.getUsers();
    const updated = users.map(u => u.uid === userProfile.uid ? userProfile : u);
    if (!updated.some(u => u.uid === userProfile.uid)) {
      updated.push(userProfile);
    }
    FirestoreDb.saveUsers(updated);
  }, [userProfile]);

  // Keep settings state synchronized with FirestoreDb changes
  useEffect(() => {
    const handleStorageChange = () => {
      setSettings(FirestoreDb.getSettings());
    };
    window.addEventListener('storage_change', handleStorageChange);
    return () => window.removeEventListener('storage_change', handleStorageChange);
  }, []);

  const [registrationTrends, setRegistrationTrends] = useState([
    { date: '07/10', registrations: 48 },
    { date: '07/11', registrations: 72 },
    { date: '07/12', registrations: 95 },
    { date: '07/13', registrations: 110 },
    { date: '07/14', registrations: 140 },
    { date: '07/15', registrations: 180 },
    { date: '07/16', registrations: 220 }
  ]);

  // Form inputs
  const [depositAmount, setDepositAmount] = useState('100');
  const [depositUpi, setDepositUpi] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('50');
  const [withdrawUpi, setWithdrawUpi] = useState('');
  const [promoCode, setPromoCode] = useState('');

  // Selected overlays/modals
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [credentialsCopied, setCredentialsCopied] = useState(false);
  const [selectedLeaderboardPlayer, setSelectedLeaderboardPlayer] = useState<any | null>(null);

  // Leaderboard mock players (Changed avatar gradients to orange/gold instead of blue/purple!)
  const [mockLeaderboardData, setMockLeaderboardData] = useState([
    { uid: "user_02", name: "Gladiator_Pro", wonCount: 15, playedCount: 22, totalEarnings: 2400, tier: "Grandmaster", avatarColor: "from-amber-600 to-orange-700", favWeapon: "M1887" },
    { uid: "user_03", name: "Booyah_King", wonCount: 12, playedCount: 20, totalEarnings: 1850, tier: "Heroic", avatarColor: "from-amber-500 to-yellow-600", favWeapon: "AWM" },
    { uid: "user_04", name: "Aman Gaming", wonCount: 10, playedCount: 18, totalEarnings: 1500, tier: "Heroic", avatarColor: "from-orange-500 to-amber-700", favWeapon: "MP40" },
    { uid: "user_05", name: "Prowler_FF", wonCount: 6, playedCount: 11, totalEarnings: 950, tier: "Diamond IV", avatarColor: "from-amber-700 to-orange-900", favWeapon: "Scar-L" },
    { uid: "user_06", name: "Phoenix_Fire", wonCount: 5, playedCount: 9, totalEarnings: 800, tier: "Diamond III", avatarColor: "from-orange-600 to-amber-800", favWeapon: "AK47" }
  ]);

  const allLeaderboardPlayers = [
    ...mockLeaderboardData,
    { 
      uid: userProfile.uid, 
      name: userProfile.name, 
      wonCount: userProfile.wonCount, 
      playedCount: userProfile.playedCount, 
      totalEarnings: userProfile.totalEarnings,
      tier: userProfile.wonCount >= 15 ? "Grandmaster" : userProfile.wonCount >= 10 ? "Heroic" : "Diamond IV",
      avatarColor: "from-orange-500 to-amber-700",
      favWeapon: "M4A1"
    }
  ];

  const sortedLeaderboard = [...allLeaderboardPlayers]
    .sort((a, b) => b.wonCount - a.wonCount)
    .slice(0, 5);

  const dailyParticipationData = tournaments.map(t => ({
    name: t.title.split(':')[0],
    joined: t.joinedCount,
    empty: t.totalSlots - t.joinedCount
  }));

  // Admin form inputs
  const [newTitle, setNewTitle] = useState('');
  const [newFee, setNewFee] = useState('10');
  const [newPrize, setNewPrize] = useState('200');
  const [newSlots, setNewSlots] = useState('48');
  const [newMap, setNewMap] = useState('Bermuda');
  const [newType, setNewType] = useState('SQUAD');

  // --- ACTIONS & HANDLERS ---
  const triggerConfetti = () => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.8 },
      colors: ['#FF8A00', '#FFC107', '#FFFFFF', '#4CAF50']
    });
  };



  const handleJoinTournament = (tId: string, chosenMethod?: 'bonus' | 'main' | 'combine') => {
    const t = tournaments.find(x => x.id === tId);
    if (!t) return;

    if (t.participants.includes(userProfile.uid)) {
      alert(appStrings.notifications.alreadyRegistered);
      return;
    }

    const method = chosenMethod || paymentMethod;
    let deductBonus = 0;
    let deductMain = 0;

    if (method === 'bonus') {
      if (userProfile.bonusBalance < t.entryFee) {
        alert("Insufficient Balance in Bonus Wallet! Please select another payment method or claim daily rewards.");
        return;
      }
      deductBonus = t.entryFee;
    } else if (method === 'main') {
      if (userProfile.walletBalance < t.entryFee) {
        alert(appStrings.notifications.insufficientBalance);
        setCurrentTab('wallet');
        return;
      }
      deductMain = t.entryFee;
    } else {
      // combine both
      const totalAvailable = userProfile.bonusBalance + userProfile.walletBalance;
      if (totalAvailable < t.entryFee) {
        alert("Insufficient combined funds in Main + Bonus Wallets! Please claim daily rewards or deposit cash.");
        return;
      }
      if (userProfile.bonusBalance >= t.entryFee) {
        deductBonus = t.entryFee;
      } else {
        deductBonus = userProfile.bonusBalance;
        deductMain = t.entryFee - userProfile.bonusBalance;
      }
    }

    // Deduct entry fee & register
    setUserProfile(prev => ({
      ...prev,
      bonusBalance: prev.bonusBalance - deductBonus,
      walletBalance: prev.walletBalance - deductMain,
      playedCount: prev.playedCount + 1
    }));

    setRegistrationTrends(prev => prev.map((item, idx) => {
      if (idx === prev.length - 1) {
        return { ...item, registrations: item.registrations + 1 };
      }
      return item;
    }));

    setTournaments(prev => prev.map(x => {
      if (x.id === tId) {
        return {
          ...x,
          joinedCount: x.joinedCount + 1,
          participants: [...x.participants, userProfile.uid]
        };
      }
      return x;
    }));

    // Add transaction
    const desc = deductBonus > 0 && deductMain > 0
      ? `Registered: ${t.title} (Paid: $${deductBonus.toFixed(2)} Bonus + $${deductMain.toFixed(2)} Main)`
      : deductBonus > 0
        ? `Registered: ${t.title} (Paid with Bonus Wallet)`
        : `Registered: ${t.title} (Paid with Main Wallet)`;

    const newTx: Transaction = {
      id: "tx_" + Date.now(),
      type: "ENTRY_FEE",
      amount: t.entryFee,
      status: "APPROVED",
      description: desc,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setTransactions([newTx, ...transactions]);

    setNotifications(prev => [
      `Successfully registered for ${t.title}. Fee: $${t.entryFee} (${deductBonus > 0 ? `$${deductBonus.toFixed(2)} Bonus` : ''}${deductBonus > 0 && deductMain > 0 ? ' + ' : ''}${deductMain > 0 ? `$${deductMain.toFixed(2)} Main` : ''})`,
      ...prev
    ]);

    triggerConfetti();
  };

  const simulateVictory = () => {
    setUserProfile(prev => ({
      ...prev,
      wonCount: prev.wonCount + 1,
      playedCount: prev.playedCount + 1,
      totalEarnings: prev.totalEarnings + 150.0,
      walletBalance: prev.walletBalance + 150.0
    }));

    setRegistrationTrends(prev => prev.map((item, idx) => {
      if (idx === prev.length - 1) {
        return { ...item, registrations: item.registrations + 1 };
      }
      return item;
    }));

    const newTx: Transaction = {
      id: "tx_sim_" + Date.now(),
      type: "DEPOSIT",
      amount: 150.0,
      status: "APPROVED",
      description: "Victory Prize: Solo Striker Booyah!",
      timestamp: "2026-07-16 12:00"
    };
    setTransactions(prev => [newTx, ...prev]);

    setNotifications(prev => [
      "🔥 BOOYAH! You won the Solo Striker match! +$150 added to wallet.",
      ...prev
    ]);

    triggerConfetti();
  };

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(depositAmount);
    if (isNaN(amt) || amt <= 0) return;
    if (!depositUpi) {
      alert(appStrings.notifications.enterUpiRef);
      return;
    }

    const newTx: Transaction = {
      id: "tx_" + Date.now(),
      type: "DEPOSIT",
      amount: amt,
      status: "PENDING",
      upiTxnId: depositUpi,
      description: "Added money to Wallet",
      timestamp: "2026-07-16 11:26"
    };

    setTransactions([newTx, ...transactions]);
    setNotifications(prev => [
      `Deposit request of $${amt} submitted with Txn ID ${depositUpi}. Awaiting Admin approval.`,
      ...prev
    ]);

    setDepositUpi('');
    alert(appStrings.notifications.depositSubmitted);
  };

  const handleWithdrawal = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(withdrawAmount);
    if (isNaN(amt) || amt <= 0) return;
    if (amt > userProfile.walletBalance) {
      alert(appStrings.notifications.insufficientFundsWithdraw);
      return;
    }
    if (!withdrawUpi) {
      alert(appStrings.notifications.enterUpiWithdraw);
      return;
    }

    setUserProfile(prev => ({
      ...prev,
      walletBalance: prev.walletBalance - amt
    }));

    const newTx: Transaction = {
      id: "tx_" + Date.now(),
      type: "WITHDRAWAL",
      amount: amt,
      status: "PENDING",
      upiId: withdrawUpi,
      description: `Withdrawn to ${withdrawUpi}`,
      timestamp: "2026-07-16 11:27"
    };

    setTransactions([newTx, ...transactions]);
    setNotifications(prev => [
      `Withdrawal of $${amt} submitted to UPI ${withdrawUpi}. Status is currently PENDING.`,
      ...prev
    ]);

    setWithdrawUpi('');
    alert(appStrings.notifications.withdrawSubmitted);
  };

  const handleRedeemCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const codeClean = promoCode.trim().toUpperCase();
    if (!codeClean) return;

    const coup = coupons.find(c => c.code === codeClean);
    if (!coup) {
      alert(appStrings.notifications.invalidPromo);
      return;
    }

    if (coup.redeemedBy.includes(userProfile.uid)) {
      alert(appStrings.notifications.promoAlreadyRedeemed);
      return;
    }

    // All Promo Rewards must go strictly into the separate Bonus Wallet (bonusBalance)
    setUserProfile(prev => ({
      ...prev,
      bonusBalance: prev.bonusBalance + coup.amount
    }));

    setCoupons(prev => prev.map(c => {
      if (c.code === codeClean) {
        return {
          ...c,
          redeemedBy: [...c.redeemedBy, userProfile.uid]
        };
      }
      return c;
    }));

    const newTx: Transaction = {
      id: "tx_" + Date.now(),
      type: "PROMO_CODE",
      amount: coup.amount,
      status: "APPROVED",
      description: `Redeemed promo: ${codeClean}`,
      timestamp: "2026-07-16 11:28"
    };

    setTransactions([newTx, ...transactions]);
    setNotifications(prev => [
      `Promo Code ${codeClean} redeemed! Credited $${coup.amount} to your ${coup.type.toLowerCase()} balance.`,
      ...prev
    ]);

    setPromoCode('');
    triggerConfetti();
  };

  const handleCreateTournament = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const newT: Tournament = {
      id: "ff_tour_" + Date.now(),
      title: newTitle.toUpperCase(),
      gameName: "Free Fire",
      dateTime: "2026-07-16 22:00",
      totalSlots: parseInt(newSlots) || 48,
      joinedCount: 0,
      entryFee: parseFloat(newFee) || 10.0,
      prizePool: parseFloat(newPrize) || 200.0,
      perKillPrize: 2.0,
      mapName: newMap,
      type: newType,
      roomId: "FF-ROOM-" + Math.floor(10000 + Math.random() * 90000),
      roomPassword: "booyah_" + Math.floor(100 + Math.random() * 900),
      participants: [],
      reportedIssues: []
    };

    setTournaments([newT, ...tournaments]);
    setNotifications(prev => [
      `New custom tournament lobby "${newT.title}" published by Admin! Register now.`,
      ...prev
    ]);

    setNewTitle('');
    alert(appStrings.notifications.tournamentCreated);
  };

  const handleApproveTransaction = (txId: string) => {
    const tx = transactions.find(x => x.id === txId);
    if (!tx) return;

    if (tx.type === "DEPOSIT") {
      setUserProfile(prev => ({
        ...prev,
        walletBalance: prev.walletBalance + tx.amount
      }));
    }

    setTransactions(prev => prev.map(x => {
      if (x.id === txId) return { ...x, status: "APPROVED" };
      return x;
    }));

    setNotifications(prev => [
      `Admin approved transaction reference ${txId}. Funds available in Main wallet!`,
      ...prev
    ]);

    alert(appStrings.notifications.txnApproved);
  };

  const handleRejectTransaction = (txId: string) => {
    setTransactions(prev => prev.map(x => {
      if (x.id === txId) return { ...x, status: "REJECTED" };
      return x;
    }));

    alert(appStrings.notifications.txnRejected);
  };

  const handleCopyCredentials = (room: string, pass: string) => {
    const txt = `Room ID: ${room}\nPassword: ${pass}`;
    navigator.clipboard.writeText(txt).then(() => {
      setCredentialsCopied(true);
      setTimeout(() => setCredentialsCopied(false), 2000);
    });
  };

  const handleCopyCodeFile = (id: string, text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedCodeFile(id);
      setTimeout(() => setCopiedCodeFile(null), 2000);
    });
  };

  // --- SPLASH ENGINE ONSTARTUP ---
  useEffect(() => {
    if (appState === 'splash') {
      setSplashProgress(0);
      let step = 0;
      const statusSteps = [
        { progress: 0, text: "Initializing Ast's Arena..." },
        { progress: 20, text: "Synchronizing tournament lobby databases..." },
        { progress: 40, text: "Loading active custom match schedules..." },
        { progress: 65, text: "Verifying security protocols..." },
        { progress: 85, text: "Loading wallet balance systems..." },
        { progress: 100, text: "Gladiator Arena is ready." }
      ];

      const interval = setInterval(() => {
        step += 1;
        const prog = Math.min(Math.round((step / 35) * 100), 100);
        setSplashProgress(prog);

        const currentStatus = [...statusSteps]
          .reverse()
          .find(s => prog >= s.progress);
        if (currentStatus) {
          setSplashStatus(currentStatus.text);
        }

        if (step >= 35) {
          clearInterval(interval);
          setTimeout(() => {
            setAppState('login');
          }, 400);
        }
      }, 70);

      return () => clearInterval(interval);
    }
  }, [appState]);

  // --- LIVE CLOCK TICKER ---
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // --- VIEW RENDERING ENGINE ---
  if (appState === 'splash') {
    return <SplashView progress={splashProgress} status={splashStatus} />;
  }

  if (appState === 'login') {
    return (
      <LoginView 
        onLoginSuccess={(user) => {
          setUserProfile(user);
          setAppState('home');
          triggerConfetti();
        }}
        onTriggerAdmin={() => {
          const users = FirestoreDb.getUsers();
          const adminUser = users.find(u => u.isAdmin) || {
            uid: "user_01",
            name: "Ast Gamer",
            email: "urast5818@gmail.com",
            phone: "+91 98765 43210",
            walletBalance: 250.0,
            bonusBalance: 50.0,
            playedCount: 14,
            wonCount: 8,
            totalEarnings: 1200.0,
            isAdmin: true,
          };
          const finalAdmin = {
            ...adminUser,
            isAdmin: true,
            role: 'admin'
          };
          setUserProfile(finalAdmin);
          setIsAdminPanelUnlocked(true);
          setAppState('home');
          setCurrentTab('admin');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0F14] text-white flex font-sans antialiased relative overflow-hidden select-none">
      {/* Decorative atmospheric elements */}
      <div className="absolute top-0 left-0 w-full h-full bg-[linear-gradient(rgba(255,138,0,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,138,0,0.02)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none" />
      <div className="absolute -top-[20%] -left-[10%] w-[600px] h-[600px] bg-esPrimary/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-[40%] -right-[15%] w-[600px] h-[600px] bg-esSecondary/5 rounded-full blur-[160px] pointer-events-none" />

      {/* Persistent Left Sidebar Navigation */}
      <Sidebar 
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        userProfile={userProfile}
        onLogout={() => {
          setAppState('login');
          setCurrentTab('home');
          setIsAdminPanelUnlocked(false);
        }}
        settings={settings}
        isAdminPanelUnlocked={isAdminPanelUnlocked}
      />

      {/* Main Container Viewport (No mobile framework, occupies full width!) */}
      <div className="flex-1 flex flex-col min-h-screen relative overflow-y-auto max-h-screen pb-16 md:pb-0">
        
        {/* Dynamic App Header */}
        <header className="bg-[#171C24]/60 backdrop-blur-xl border-b border-[#2B313D] px-8 py-5 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <Trophy className="text-esPrimary shrink-0" size={16} />
            <span className="text-[11px] font-mono uppercase tracking-[0.15em] text-white font-black flex items-center gap-2">
              {settings.appName || "AST'S ARENA"} 
              <span className="text-[#2B313D] font-normal">/</span> 
              <span className="text-esSecondary">
                {currentTab === 'home' ? 'EXPLORE LOBBIES' : 
                 currentTab === 'matches' ? 'MY ROOMS' : 
                 currentTab === 'wallet' ? 'WALLET SUITE' : 
                 currentTab === 'profile' ? 'GLADIATOR PROFILE' : 
                 currentTab === 'admin' ? 'ADMIN CONTROL Suite' : 
                 currentTab === 'earn' ? 'EARN ZONE' :
                 'DEVELOPER DESK'}
              </span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Quick Live Clock */}
            {(() => {
              const formattedDate = currentTime.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
              const formattedDay = currentTime.toLocaleDateString('en-US', { weekday: 'long' });
              const formattedTime = currentTime.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                hour12: true 
              });
              return (
                <div className="bg-[#171C24]/60 backdrop-blur-xl border border-white/[0.12] rounded-xl px-4 py-2.5 text-white flex items-center gap-3.5 shadow-[0_8px_32px_0_rgba(0,0,0,0.5),0_0_15px_rgba(255,138,0,0.12)] hover:border-esPrimary/40 transition-all duration-300 relative overflow-hidden group">
                  {/* Premium micro reflection effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.04] to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  <Clock size={15} className="text-esPrimary shrink-0 animate-pulse drop-shadow-[0_0_8px_rgba(255,138,0,0.6)]" />
                  <div className="flex flex-col text-left relative z-10 leading-none">
                    {/* Time */}
                    <span className="text-esSecondary font-sans font-extrabold text-[13px] tracking-wide drop-shadow-[0_0_8px_rgba(255,138,0,0.3)]">
                      {formattedTime}
                    </span>
                    {/* Date below */}
                    <span className="text-white/95 font-sans font-bold text-[9px] tracking-wide mt-1">
                      {formattedDate}
                    </span>
                    {/* Weekday below date */}
                    <span className="text-white/40 font-sans font-medium text-[8px] tracking-wider mt-0.5 uppercase">
                      {formattedDay}
                    </span>
                  </div>
                </div>
              );
            })()}

            {/* Quick reset compilation simulation */}
            <button 
              onClick={() => {
                setAppState('splash');
                setSplashProgress(0);
                setCurrentTab('home');
              }}
              className="px-4 py-2 bg-[#1F2633] hover:bg-[#0B0F14] border border-esPrimary/20 hover:border-esPrimary/60 rounded-xl text-[10px] font-mono font-bold text-esPrimary hover:text-white transition-all duration-300 flex items-center gap-1.5 cursor-pointer shadow-md hover:scale-[1.02] active:scale-95"
            >
              <RefreshCw size={11} className="text-esPrimary animate-spin-slow" />
              <span>RELOAD PORTAL</span>
            </button>
          </div>
        </header>

        {/* Content Box */}
        <main className="flex-1 p-8">
          
          {/* TAB 1: Explore Matches */}
          {currentTab === 'home' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Earn Money Action Button */}
              <button 
                onClick={() => setCurrentTab('earn')}
                className="w-full py-4 px-6 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-black font-black text-xs uppercase tracking-wider rounded-2xl transition-all duration-300 shadow-lg shadow-amber-500/10 hover:shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer font-heading"
              >
                <span>Earn Money 💰</span>
              </button>

              {/* Massive Cinematic Event Header Banner */}
              <div className="bg-gradient-to-r from-esPrimary/15 via-[#1F2633] to-[#171C24] border border-[#2B313D] rounded-[32px] p-8 text-left relative overflow-hidden shadow-xl">
                <div className="absolute top-0 right-0 w-80 h-full bg-gradient-to-l from-esPrimary/5 to-transparent pointer-events-none" />
                <div className="absolute top-[-50%] right-[-10%] w-[350px] h-[350px] bg-esPrimary/10 rounded-full blur-[100px] pointer-events-none" />
                
                <div className="max-w-xl space-y-3 relative z-10">
                  <div className="flex items-center gap-2">
                    <span className="bg-esSecondary/20 text-esSecondary border border-esSecondary/30 text-[9px] font-mono font-black px-3 py-1 rounded-full uppercase tracking-widest">
                      🏆 CHAMPIONSHIP WEEK
                    </span>
                    <span className="bg-[#4CAF50]/15 text-[#4CAF50] text-[9px] font-mono font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                      ● LIVE LOBBY UPDATING
                    </span>
                  </div>

                  <h2 className="text-3xl font-black uppercase text-white tracking-tight font-heading leading-none">
                    FREE FIRE <span className="text-transparent bg-clip-text bg-gradient-to-r from-esPrimary to-esSecondary">GLADIATOR CUP</span>
                  </h2>

                  <p className="text-xs text-esTextSecondary leading-relaxed">
                    Welcome to the arena! Participate in high-stakes tactical room duels, secure your slots, win premium Booyah prize pools, and verify room login keys directly in the panel.
                  </p>

                  <div className="flex items-center gap-3 pt-2 text-[10px] font-mono font-bold text-esSecondary">
                    <Sparkles size={12} className="animate-spin text-esSecondary" />
                    <span>GUARANTEED ANTICHEAT SECURE PLAYOUTS</span>
                  </div>
                </div>
              </div>

              {/* Desktop Responsive Columns Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Left Side: Tournament Lobbies List (8 Cols) */}
                <div className="lg:col-span-8 space-y-4">
                  {/* Premium Interactive Filters Bar */}
                  <div className="bg-[#1F2633]/60 border border-[#2B313D] rounded-3xl p-5 space-y-4">
                    <div className="flex flex-col md:flex-row gap-3">
                      {/* Search Input */}
                      <div className="flex-1 relative">
                        <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-esTextSecondary" />
                        <input 
                          type="text" 
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="Search matches or titles..." 
                          className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white placeholder-esTextSecondary/30 focus:outline-none focus:border-esPrimary/80"
                        />
                      </div>

                      {/* Map Filter */}
                      <div className="w-full md:w-36">
                        <select 
                          value={mapFilter} 
                          onChange={(e) => setMapFilter(e.target.value)}
                          className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-esPrimary"
                        >
                          <option value="ALL">All Arenas</option>
                          <option value="BERMUDA">Bermuda</option>
                          <option value="PURGATORY">Purgatory</option>
                          <option value="KALAHARI">Kalahari</option>
                        </select>
                      </div>

                      {/* Fee Type Filter */}
                      <div className="w-full md:w-36">
                        <select 
                          value={feeFilter} 
                          onChange={(e) => setFeeFilter(e.target.value)}
                          className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-esPrimary"
                        >
                          <option value="ALL">All Price tags</option>
                          <option value="FREE">Free Enrolls</option>
                          <option value="PAID">Premium paid</option>
                        </select>
                      </div>

                      {/* Format Filter */}
                      <div className="w-full md:w-36">
                        <select 
                          value={formatFilter} 
                          onChange={(e) => setFormatFilter(e.target.value)}
                          className="w-full bg-[#0B0F14] border border-[#2B313D] rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-esPrimary"
                        >
                          <option value="ALL">All Formats</option>
                          <option value="SOLO">Solo Striker</option>
                          <option value="DUO">Duo Duel</option>
                          <option value="SQUAD">Squad Battle</option>
                        </select>
                      </div>

                      {/* Favorite Only Filter */}
                      <button 
                        onClick={() => setFavOnlyFilter(!favOnlyFilter)}
                        className={`px-4 py-2.5 rounded-xl border font-mono text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          favOnlyFilter 
                            ? 'bg-amber-500/10 border-amber-500 text-amber-500' 
                            : 'bg-[#0B0F14] border-[#2B313D] text-esTextSecondary hover:text-white'
                        }`}
                        title="Show Bookmarked Favorites Only"
                      >
                        <Star size={12} className={favOnlyFilter ? 'fill-amber-500' : ''} />
                        <span>FAVS</span>
                      </button>
                    </div>
                  </div>

                  {/* Filtered Tournaments computation */}
                  {(() => {
                    const filtered = tournaments.filter(t => {
                      if (searchQuery && !t.title.toLowerCase().includes(searchQuery.toLowerCase()) && !t.gameName.toLowerCase().includes(searchQuery.toLowerCase())) {
                        return false;
                      }
                      if (mapFilter !== 'ALL' && t.mapName.toUpperCase() !== mapFilter.toUpperCase()) {
                        return false;
                      }
                      if (feeFilter !== 'ALL') {
                        if (feeFilter === 'FREE' && t.entryFee > 0) return false;
                        if (feeFilter === 'PAID' && t.entryFee === 0) return false;
                      }
                      if (formatFilter !== 'ALL' && t.type.toUpperCase() !== formatFilter.toUpperCase()) {
                        return false;
                      }
                      if (favOnlyFilter && !favoriteIds.includes(t.id)) {
                        return false;
                      }
                      return true;
                    });

                    return (
                      <>
                        <div className="flex items-center justify-between font-mono text-[11px] text-esTextSecondary px-1 font-black pt-2">
                          <span className="uppercase tracking-widest flex items-center gap-2">
                            ⚔️ ACTIVE CUSTOM MATCHES ({filtered.length})
                          </span>
                          <span className="text-esSecondary uppercase tracking-wider">FREE FIRE COMPETITIVE</span>
                        </div>

                        {filtered.length === 0 ? (
                          <div className="bg-[#1F2633] border border-[#2B313D] rounded-3xl p-12 text-center text-esTextSecondary">
                            <p className="font-mono text-xs uppercase">No active match found matching chosen filters.</p>
                            <button 
                              onClick={() => {
                                setSearchQuery('');
                                setMapFilter('ALL');
                                setFeeFilter('ALL');
                                setFormatFilter('ALL');
                                setFavOnlyFilter(false);
                              }}
                              className="mt-4 px-4 py-2 bg-[#171C24] border border-[#2B313D] hover:border-esPrimary text-xs font-mono text-esPrimary hover:text-white rounded-xl transition-all cursor-pointer"
                            >
                              RESET FILTERS
                            </button>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {filtered.map(t => (
                              <TournamentCard 
                                key={t.id}
                                tournament={t}
                                userId={userProfile.uid}
                                isFavorite={favoriteIds.includes(t.id)}
                                onToggleFavorite={() => {
                                  if (favoriteIds.includes(t.id)) {
                                    setFavoriteIds(prev => prev.filter(id => id !== t.id));
                                  } else {
                                    setFavoriteIds(prev => [...prev, t.id]);
                                  }
                                }}
                                onSelect={() => setSelectedTournament(t)}
                                onRegister={() => handleJoinTournament(t.id)}
                              />
                            ))}
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>

                {/* Right Side: Leaderboard Standings (4 Cols) */}
                <div className="lg:col-span-4">
                  <Leaderboard 
                    sortedLeaderboard={sortedLeaderboard}
                    userProfile={userProfile}
                    onSelectPlayer={setSelectedLeaderboardPlayer}
                    onSimulateVictory={simulateVictory}
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: My Rooms */}
          {currentTab === 'matches' && (
            <div className="space-y-6 animate-in fade-in duration-300 text-left">
              <div className="border-b border-[#2B313D] pb-4">
                <h3 className="text-xl font-black text-white uppercase tracking-tight font-heading">My Registered Lobbies</h3>
                <p className="text-xs text-esTextSecondary mt-1">Verify credentials, passwords, and custom room schedule guidelines for your active slots.</p>
              </div>

              {tournaments.filter(t => t.participants.includes(userProfile.uid)).length === 0 ? (
                <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-12 text-center max-w-lg mx-auto space-y-4">
                  <span className="text-4xl">🎮</span>
                  <h4 className="text-sm font-black text-white uppercase tracking-wider">NO SLOTS REGISTERED</h4>
                  <p className="text-xs text-esTextSecondary">
                    You haven't purchased slots in any active matches. Go to Explore tab and register in a tournament!
                  </p>
                  <button 
                    onClick={() => setCurrentTab('home')}
                    className="px-6 py-3 bg-gradient-to-r from-esPrimary to-esSecondary text-[#0B0F14] text-xs font-black uppercase tracking-widest rounded-xl hover:scale-105 transition-transform"
                  >
                    EXPLORE LOBBIES
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {tournaments.filter(t => t.participants.includes(userProfile.uid)).map(t => (
                    <div key={t.id} className="bg-[#171C24] border border-esPrimary/20 rounded-3xl p-6 space-y-4 shadow-xl">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <span className="text-[9px] font-mono font-black text-esPrimary bg-esPrimary/10 border border-esPrimary/25 px-2.5 py-0.5 rounded-full uppercase">
                            SLOT ASSIGNED
                          </span>
                          <h4 className="text-sm font-black text-white uppercase font-heading mt-2">{t.title}</h4>
                        </div>
                        <span className="text-xs font-mono font-black text-esSecondary bg-esSecondary/10 border border-esSecondary/25 px-3 py-1 rounded-xl">
                          ${t.prizePool} PRIZE
                        </span>
                      </div>

                      <div className="bg-[#0B0F14] border border-[#2B313D] rounded-2xl p-4 space-y-3 font-mono text-xs">
                        <div className="flex justify-between items-center pb-2.5 border-b border-[#2B313D]/40">
                          <span className="text-esTextSecondary">MAP STATUS:</span>
                          <span className="text-white font-bold uppercase">{t.mapName}</span>
                        </div>
                        <div className="flex justify-between items-center pb-2.5 border-b border-[#2B313D]/40">
                          <span className="text-esTextSecondary">ROOM ID:</span>
                          <span className="text-white font-bold select-all">{t.roomId || 'TBD (PENDING)'}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-esTextSecondary">PASSWORD:</span>
                          <span className="text-white font-bold select-all">{t.roomPassword || 'TBD (PENDING)'}</span>
                        </div>
                      </div>

                      <button 
                        onClick={() => handleCopyCredentials(t.roomId, t.roomPassword)}
                        className="w-full py-3 bg-[#1F2633] hover:bg-[#0B0F14] text-esTextSecondary hover:text-white rounded-xl text-xs font-bold font-mono transition-colors border border-[#2B313D] flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Copy size={13} />
                        <span>Copy Room Credentials</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Wallet Hub */}
          {currentTab === 'wallet' && (
            <WalletView 
              userProfile={userProfile}
              transactions={transactions}
              promoCode={promoCode}
              setPromoCode={setPromoCode}
              depositAmount={depositAmount}
              setDepositAmount={setDepositAmount}
              depositUpi={depositUpi}
              setDepositUpi={setDepositUpi}
              withdrawAmount={withdrawAmount}
              setWithdrawAmount={setWithdrawAmount}
              withdrawUpi={withdrawUpi}
              setWithdrawUpi={setWithdrawUpi}
              onRedeemCoupon={handleRedeemCoupon}
              onDeposit={handleDeposit}
              onWithdrawal={handleWithdrawal}
              setPromoCodeClean={setPromoCode}
            />
          )}

          {/* TAB 3b: Earn Zone */}
          {currentTab === 'earn' && (
            <EarnTab 
              userProfile={userProfile}
              setUserProfile={setUserProfile}
              onAddNotification={(msg) => {
                setNotifications(prev => [msg, ...prev]);
              }}
            />
          )}

          {/* TAB 4: Profile */}
          {currentTab === 'profile' && (
            <ProfileView 
              userProfile={userProfile} 
              onUpdateUsername={(newName) => {
                setUserProfile(prev => ({
                  ...prev,
                  name: newName
                }));
              }}
              onTriggerAdmin={() => {
                setUserProfile(prev => ({
                  ...prev,
                  isAdmin: true,
                  role: 'admin'
                }));
                setIsAdminPanelUnlocked(true);
                setCurrentTab('admin');
              }}
            />
          )}

          {/* TAB 4b: Arena Hub (Referrals, Rewards, Spin, FAQ) */}
          {currentTab === 'quests' && (
            <ArenaHub 
              userProfile={userProfile}
              setUserProfile={setUserProfile}
              transactions={transactions}
              setTransactions={setTransactions}
              notifications={notifications}
              setNotifications={setNotifications}
              tournaments={tournaments}
              favoriteIds={favoriteIds}
              setFavoriteIds={setFavoriteIds}
            />
          )}

          {/* TAB 5: Admin Panel */}
          {currentTab === 'admin' && userProfile.isAdmin && (
            <AdminView 
              tournaments={tournaments}
              setTournaments={setTournaments}
              transactions={transactions}
              setTransactions={setTransactions}
              registrationTrends={registrationTrends}
              dailyParticipationData={dailyParticipationData}
              userProfile={userProfile}
              onApproveTransaction={handleApproveTransaction}
              onRejectTransaction={handleRejectTransaction}
              onStringsUpdate={() => setStringsVersion(v => v + 1)}
              onRefreshData={() => setSettings(FirestoreDb.getSettings())}
            />
          )}

          {/* TAB 6: Developer Hub */}
          {currentTab === 'developer' && (
            <DeveloperHub 
              DART_FILES={DART_FILES}
              activeCodeTab={activeCodeTab}
              setActiveCodeTab={setActiveCodeTab}
              copiedCodeFile={copiedCodeFile}
              onCopyCode={handleCopyCodeFile}
            />
          )}

        </main>
      </div>

      {/* --- CENTRED DETAILS OVERLAY MODAL --- */}
      {selectedTournament && (
        <div className="fixed inset-0 bg-[#0B0F14]/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 max-w-md w-full relative space-y-4 shadow-2xl animate-in scale-in duration-250">
            
            <div className="flex justify-between items-start gap-4">
              <div className="text-left space-y-1">
                <span className="bg-esPrimary/10 text-esPrimary text-[9px] font-mono font-black px-2.5 py-1 rounded border border-esPrimary/25 uppercase">
                  {selectedTournament.gameName} LOBBY DETAILS
                </span>
                <h3 className="text-lg font-black text-white uppercase mt-2 font-heading tracking-wide">
                  {selectedTournament.title}
                </h3>
              </div>
              <button 
                onClick={() => setSelectedTournament(null)}
                className="w-8 h-8 bg-[#0B0F14] border border-[#2B313D] rounded-xl flex items-center justify-center text-esTextSecondary hover:text-white text-xs transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-left font-mono text-xs">
              <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]/60">
                <span className="text-esTextSecondary text-[8px] block uppercase font-bold tracking-wide">MAP ARENA</span>
                <span className="font-bold text-white uppercase block mt-0.5">{selectedTournament.mapName}</span>
              </div>
              <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]/60">
                <span className="text-esTextSecondary text-[8px] block uppercase font-bold tracking-wide">TEAM FORMAT</span>
                <span className="font-bold text-white uppercase block mt-0.5">{selectedTournament.type}</span>
              </div>
              <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]/60">
                <span className="text-esTextSecondary text-[8px] block uppercase font-bold tracking-wide">ENTRY FEE</span>
                <span className="font-black text-esPrimary block mt-0.5">${selectedTournament.entryFee} MAIN</span>
              </div>
              <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]/60">
                <span className="text-esTextSecondary text-[8px] block uppercase font-bold tracking-wide">SLOTS ASSIGNED</span>
                <span className="font-black text-white block mt-0.5">{selectedTournament.joinedCount} / {selectedTournament.totalSlots}</span>
              </div>
            </div>

            {/* Description, Rules and Match Duration if present */}
            {(selectedTournament.description || selectedTournament.rules || selectedTournament.durationMinutes) && (
              <div className="bg-[#0B0F14] border border-[#2B313D]/60 rounded-2xl p-4 text-left text-xs space-y-2 max-h-36 overflow-y-auto">
                {selectedTournament.durationMinutes && (
                  <div className="flex justify-between text-[10px] font-mono border-b border-[#2B313D]/20 pb-1.5">
                    <span className="text-esTextSecondary uppercase">Duration:</span>
                    <span className="text-white font-bold">{selectedTournament.durationMinutes} Mins</span>
                  </div>
                )}
                {selectedTournament.description && (
                  <div>
                    <h5 className="text-[9px] font-mono font-bold text-esPrimary uppercase tracking-wider">Description</h5>
                    <p className="text-[11px] text-esTextSecondary/90 mt-0.5 leading-relaxed">{selectedTournament.description}</p>
                  </div>
                )}
                {selectedTournament.rules && (
                  <div className="pt-1">
                    <h5 className="text-[9px] font-mono font-bold text-esSecondary uppercase tracking-wider">Match Rules</h5>
                    <p className="text-[11px] text-esTextSecondary/90 mt-0.5 leading-relaxed whitespace-pre-line">{selectedTournament.rules}</p>
                  </div>
                )}
              </div>
            )}

            {/* Room login keys if registered */}
            {selectedTournament.participants.includes(userProfile.uid) ? (
              <div className="bg-[#1F2633] border border-[#4CAF50]/30 rounded-2xl p-4.5 space-y-3.5 text-left">
                <div className="flex items-center gap-1.5 text-[9px] font-mono font-black text-[#4CAF50] uppercase tracking-wider">
                  <Key size={12} className="text-[#4CAF50]" />
                  <span>SECURED CUSTOM ROOM CREDENTIALS</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]">
                    <p className="text-[8px] text-esTextSecondary font-mono font-bold uppercase">ROOM ID</p>
                    <p className="text-xs font-mono font-black text-white select-all mt-0.5">{selectedTournament.roomId || 'TBD'}</p>
                  </div>
                  <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]">
                    <p className="text-[8px] text-esTextSecondary font-mono font-bold uppercase">PASSWORD</p>
                    <p className="text-xs font-mono font-black text-white select-all mt-0.5">{selectedTournament.roomPassword || 'TBD'}</p>
                  </div>
                </div>

                <button 
                  onClick={() => handleCopyCredentials(selectedTournament.roomId || 'TBD', selectedTournament.roomPassword || 'TBD')}
                  className={`w-full py-3 px-4 rounded-xl font-mono font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                    credentialsCopied 
                      ? 'bg-[#4CAF50]/20 text-[#4CAF50] border-[#4CAF50]/40 shadow-[0_0_15px_rgba(74,222,128,0.15)]' 
                      : 'bg-[#0B0F14] hover:bg-[#0B0F14]/70 text-esTextSecondary hover:text-white border-[#2B313D]'
                  }`}
                >
                  {credentialsCopied ? (
                    <>
                      <CheckCircle size={13} className="text-[#4CAF50]" />
                      <span>Copied Keys successfully!</span>
                    </>
                  ) : (
                    <>
                      <Copy size={13} />
                      <span>Copy Credentials</span>
                    </>
                  )}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {selectedTournament.entryFee > 0 && (
                  <div className="bg-[#0B0F14]/60 border border-[#2B313D] rounded-2xl p-4 space-y-3">
                    <div className="text-[10px] font-mono font-black uppercase text-esSecondary tracking-wider">
                      Select Payment Wallet:
                    </div>
                    
                    <div className="grid grid-cols-1 gap-2.5">
                      {/* 1. Bonus Balance Option */}
                      <label 
                        className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer select-none ${
                          paymentMethod === 'bonus' 
                            ? 'bg-esPrimary/5 border-esPrimary text-white' 
                            : 'bg-[#171C24] border-[#2B313D]/60 hover:border-[#2B313D] text-esTextSecondary'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input 
                            type="radio" 
                            name="checkout_payment"
                            checked={paymentMethod === 'bonus'}
                            onChange={() => setPaymentMethod('bonus')}
                            className="text-esPrimary focus:ring-0 accent-esPrimary"
                          />
                          <div className="text-left">
                            <p className="text-xs font-bold uppercase tracking-wider text-white">Bonus Wallet</p>
                            <p className="text-[9px] font-mono mt-0.5 text-esTextSecondary">Promo credit (No Cashouts)</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-mono font-black text-amber-500">${userProfile.bonusBalance.toFixed(2)}</p>
                          <p className="text-[8px] font-mono text-esTextSecondary/60">Available</p>
                        </div>
                      </label>

                      {/* 2. Main Balance Option */}
                      <label 
                        className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer select-none ${
                          paymentMethod === 'main' 
                            ? 'bg-esPrimary/5 border-esPrimary text-white' 
                            : 'bg-[#171C24] border-[#2B313D]/60 hover:border-[#2B313D] text-esTextSecondary'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input 
                            type="radio" 
                            name="checkout_payment"
                            checked={paymentMethod === 'main'}
                            onChange={() => setPaymentMethod('main')}
                            className="text-esPrimary focus:ring-0 accent-esPrimary"
                          />
                          <div className="text-left">
                            <p className="text-xs font-bold uppercase tracking-wider text-white">Main Wallet</p>
                            <p className="text-[9px] font-mono mt-0.5 text-esTextSecondary">Deposit/Winnings balance</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-mono font-black text-white">${userProfile.walletBalance.toFixed(2)}</p>
                          <p className="text-[8px] font-mono text-esTextSecondary/60">Available</p>
                        </div>
                      </label>

                      {/* 3. Combined Option */}
                      <label 
                        className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer select-none ${
                          paymentMethod === 'combine' 
                            ? 'bg-esPrimary/5 border-esPrimary text-white' 
                            : 'bg-[#171C24] border-[#2B313D]/60 hover:border-[#2B313D] text-esTextSecondary'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input 
                            type="radio" 
                            name="checkout_payment"
                            checked={paymentMethod === 'combine'}
                            onChange={() => setPaymentMethod('combine')}
                            className="text-esPrimary focus:ring-0 accent-esPrimary"
                          />
                          <div className="text-left">
                            <p className="text-xs font-bold uppercase tracking-wider text-white">Combine Both</p>
                            <p className="text-[9px] font-mono mt-0.5 text-esTextSecondary">Use Bonus first, rest from Main</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-mono font-black text-[#4CAF50]">${(userProfile.bonusBalance + userProfile.walletBalance).toFixed(2)}</p>
                          <p className="text-[8px] font-mono text-esTextSecondary/60">Combined</p>
                        </div>
                      </label>
                    </div>

                    <p className="text-[9px] font-mono text-esTextSecondary/70 leading-relaxed pt-2 border-t border-[#2B313D]/40">
                      ℹ️ <span className="text-esSecondary font-bold">Wallet Rule:</span> Bonus Balance is promotional virtual credit. It can only be used to join tournaments and cannot be withdrawn or converted into cash.
                    </p>
                  </div>
                )}

                <button 
                  onClick={() => {
                    handleJoinTournament(selectedTournament.id, selectedTournament.entryFee > 0 ? paymentMethod : 'main');
                    setSelectedTournament(null);
                  }}
                  className="w-full py-4 bg-gradient-to-r from-esPrimary to-esSecondary hover:from-esSecondary hover:to-esPrimary text-[#0B0F14] font-black text-xs uppercase tracking-widest rounded-xl transition-all duration-300 shadow-md shadow-esPrimary/10 hover:shadow-[0_0_15px_rgba(255,138,0,0.3)] cursor-pointer font-heading"
                >
                  Register Slot (${selectedTournament.entryFee})
                </button>
              </div>
            )}

            <div className="text-[8px] font-mono text-esTextSecondary/50 text-center uppercase tracking-wider pt-1">
              * Matches schedule starts strictly at {selectedTournament.dateTime}
            </div>

          </div>
        </div>
      )}

      {/* --- CENTRED LEADERBOARD PLAYER BIO OVERLAY MODAL --- */}
      {selectedLeaderboardPlayer && (
        <div className="fixed inset-0 bg-[#0B0F14]/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#171C24] border border-[#2B313D] rounded-3xl p-6 max-w-md w-full relative space-y-4 shadow-2xl animate-in scale-in duration-250">
            
            <div className="flex justify-between items-start gap-4">
              <div className="text-left space-y-1">
                <span className="bg-esSecondary/20 text-esSecondary text-[9px] font-mono font-black px-2.5 py-1 rounded border border-esSecondary/25 uppercase">
                  🏆 PLAYER PROFILE DOSSIER
                </span>
                <h3 className="text-lg font-black text-white uppercase mt-2 font-heading tracking-wide">
                  {selectedLeaderboardPlayer.name}
                </h3>
              </div>
              <button 
                onClick={() => setSelectedLeaderboardPlayer(null)}
                className="w-8 h-8 bg-[#0B0F14] border border-[#2B313D] rounded-xl flex items-center justify-center text-esTextSecondary hover:text-white text-xs transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="flex items-center gap-4 bg-[#0B0F14] p-4 rounded-2xl border border-[#2B313D]">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-esPrimary to-esSecondary flex items-center justify-center text-[#0B0F14] font-black text-lg shadow-md shrink-0">
                {selectedLeaderboardPlayer.name.charAt(0).toUpperCase()}
              </div>
              <div className="text-left font-mono text-xs space-y-1">
                <p className="text-white font-extrabold text-sm uppercase">{selectedLeaderboardPlayer.name}</p>
                <p className="text-esSecondary font-bold">TIER: {selectedLeaderboardPlayer.tier}</p>
                <p className="text-esTextSecondary">FAV WEAPON: {selectedLeaderboardPlayer.favWeapon}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-left font-mono text-xs">
              <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]/60">
                <span className="text-esTextSecondary text-[8px] block uppercase font-bold tracking-wide">MATCHES PLAYED</span>
                <span className="font-bold text-white block mt-0.5">{selectedLeaderboardPlayer.playedCount} Matches</span>
              </div>
              <div className="bg-[#0B0F14] rounded-xl p-3 border border-[#2B313D]/60">
                <span className="text-esTextSecondary text-[8px] block uppercase font-bold tracking-wide">MATCHES WON</span>
                <span className="font-bold text-esPrimary block mt-0.5">{selectedLeaderboardPlayer.wonCount} Booyahs</span>
              </div>
            </div>

            <div className="text-[9px] text-esTextSecondary leading-relaxed text-left p-3.5 bg-[#1F2633]/60 rounded-xl border border-[#2B313D]">
              🛡️ <strong>Battle Status Notes:</strong> Officially verified esports participant with competitive combat logs. Recommended partner for Squad Arena matches.
            </div>

          </div>
        </div>
      )}

      {/* Persistent Bottom Mobile Navigation */}
      <BottomNav 
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        userProfile={userProfile}
        settings={settings}
        isAdminPanelUnlocked={isAdminPanelUnlocked}
      />

    </div>
  );
}
