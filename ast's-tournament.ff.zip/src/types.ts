export interface Tournament {
  id: string;
  title: string;
  gameName: string;
  dateTime: string;
  totalSlots: number;
  joinedCount: number;
  entryFee: number;
  prizePool: number;
  perKillPrize: number;
  mapName: string;
  type: string;
  roomId: string;
  roomPassword: string;
  participants: string[];
  reportedIssues: Array<{
    id: string;
    userId: string;
    userName: string;
    description: string;
    status: string;
    timestamp: string;
  }>;
  published?: boolean;
  registrationOpen?: boolean;
  durationMinutes?: number;
  posterUrl?: string;
  bannerUrl?: string;
  description?: string;
  rules?: string;
  customFields?: string;
  autoReleaseRoom?: boolean;
  releaseTimeMins?: number;
}

export interface Coupon {
  code: string;
  amount: number;
  type: string;
  redeemedBy: string[];
}

export interface Transaction {
  id: string;
  type: string;
  amount: number;
  status: string;
  upiTxnId?: string;
  upiId?: string;
  description: string;
  timestamp: string;
}

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  phone: string;
  walletBalance: number;
  bonusBalance: number;
  playedCount: number;
  wonCount: number;
  totalEarnings: number;
  isAdmin: boolean;
  status?: string;
}

export interface OfferApp {
  id: string;
  appName: string;
  logoUrl: string;
  downloadUrl: string;
  rewardAmount: number;
  packageName: string;
}

