import { Tournament, Coupon, Transaction, UserProfile, OfferApp } from './types';

export interface MatchType {
  id: string;
  name: string;
  icon: string;
  color: string;
  order: number;
  enabled: boolean;
}

export interface MapItem {
  id: string;
  name: string;
  order: number;
  enabled: boolean;
}

export interface PromoCode {
  id: string;
  code: string;
  rewardAmount: number;
  type: 'MAIN' | 'BONUS';
  expiryDate: string;
  usageLimit: number;
  redeemedCount: number;
  redeemedBy: string[];
  enabled: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  scheduledTime: string;
  pinned: boolean;
  timestamp: string;
}

export interface AdminNotification {
  id: string;
  title: string;
  content: string;
  targetUsers: 'all' | string[];
  scheduledTime?: string;
  timestamp: string;
}

export interface AppSettings {
  appName: string;
  logoUrl: string;
  splashScreenUrl: string;
  maintenanceMode: boolean;
  supportTelegram: string;
  supportWhatsapp: string;
  supportFacebook: string;
  supportInstagram: string;
  supportYoutube: string;
  terms: string;
  privacyPolicy: string;
  about: string;
  contact: string;
  
  // Feature Toggles
  features: {
    tournamentRegistration: boolean;
    deposit: boolean;
    withdraw: boolean;
    bonusWallet: boolean;
    referral: boolean;
    dailyReward: boolean;
    promoCode: boolean;
    leaderboard: boolean;
    tournamentHistory: boolean;
    playerStatistics: boolean;
    announcements: boolean;
    notifications: boolean;
    supportCenter: boolean;
    feedback: boolean;
    faq: boolean;
    matchReminder: boolean;
  };

  // Referral System Settings
  referrals: {
    rewardAmount: number;
    maxReferrals: number;
    cooldownHours: number;
    enabled: boolean;
  };

  // Daily Reward Settings
  daily: {
    rewardAmount: number;
    daysCount: number;
    cooldownHours: number;
    enabled: boolean;
  };

  // Leaderboard Type Settings
  leaderboardPeriod: 'daily' | 'weekly' | 'monthly';
}

const DEFAULT_MATCH_TYPES: MatchType[] = [
  { id: 'mt_br_ranked', name: 'BR Ranked', icon: 'Trophy', color: '#FF8A00', order: 1, enabled: true },
  { id: 'mt_br_custom', name: 'BR Custom', icon: 'Layers', color: '#FFC107', order: 2, enabled: true },
  { id: 'mt_cs_ranked', name: 'CS Ranked', icon: 'Shield', color: '#4CAF50', order: 3, enabled: true },
  { id: 'mt_cs_custom', name: 'CS Custom', icon: 'Key', color: '#00BCD4', order: 4, enabled: true },
  { id: 'mt_lone_wolf', name: 'Lone Wolf', icon: 'User', color: '#9C27B0', order: 5, enabled: true },
  { id: 'mt_clash_squad', name: 'Clash Squad', icon: 'Users', color: '#E91E63', order: 6, enabled: true },
  { id: 'mt_solo', name: 'Solo', icon: 'Target', color: '#FF5722', order: 7, enabled: true },
  { id: 'mt_duo', name: 'Duo', icon: 'Sparkles', color: '#3F51B5', order: 8, enabled: true },
  { id: 'mt_squad', name: 'Squad', icon: 'Gift', color: '#2196F3', order: 9, enabled: true },
];

const DEFAULT_MAPS: MapItem[] = [
  { id: 'map_bermuda', name: 'Bermuda', order: 1, enabled: true },
  { id: 'map_purgatory', name: 'Purgatory', order: 2, enabled: true },
  { id: 'map_kalahari', name: 'Kalahari', order: 3, enabled: true },
  { id: 'map_alpine', name: 'Alpine', order: 4, enabled: true },
];

const DEFAULT_APP_SETTINGS: AppSettings = {
  appName: "AST'S ARENA",
  logoUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=120&h=120&fit=crop",
  splashScreenUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&h=600&fit=crop",
  maintenanceMode: false,
  supportTelegram: "https://t.me/your_channel",
  supportWhatsapp: "https://wa.me/919876543210",
  supportFacebook: "https://facebook.com/astsarena",
  supportInstagram: "https://instagram.com/astsarena",
  supportYoutube: "https://youtube.com/astsarena",
  terms: "By participating in tournaments, you agree to play fairly. Cheat tools, hacks, or team-teaming with adversaries will result in an immediate lifetime device ban and forfeit of wallet balances.",
  privacyPolicy: "We collect your phone number strictly for customized room slot notifications and payment transfers. Your details are secured via high-grade local cryptographic keys.",
  about: "Ast's Arena is the world's premier tactical custom room automated workspace. Built by gaming veterans for professionals seeking secure, high-stakes competition.",
  contact: "Email: support@astsarena.com | Live Admin Helpdesk operational 24/7 inside the Telegram Broadcast channel.",
  
  features: {
    tournamentRegistration: true,
    deposit: true,
    withdraw: true,
    bonusWallet: true,
    referral: true,
    dailyReward: true,
    promoCode: true,
    leaderboard: true,
    tournamentHistory: true,
    playerStatistics: true,
    announcements: true,
    notifications: true,
    supportCenter: true,
    feedback: true,
    faq: true,
    matchReminder: true,
  },

  referrals: {
    rewardAmount: 10.0,
    maxReferrals: 10,
    cooldownHours: 24,
    enabled: true,
  },

  daily: {
    rewardAmount: 2.50,
    daysCount: 7,
    cooldownHours: 24,
    enabled: true,
  },

  leaderboardPeriod: 'weekly',
};

const DEFAULT_USERS: UserProfile[] = [
  {
    uid: "user_01",
    name: "Ast Gamer",
    email: "urast5818@gmail.com",
    phone: "+91 98765 43210",
    walletBalance: 250.0,
    bonusBalance: 50.0,
    playedCount: 14,
    wonCount: 8,
    totalEarnings: 1200.0,
    isAdmin: true,
  },
  {
    uid: "user_02",
    name: "Cobra FF",
    email: "cobra@freefire.com",
    phone: "+91 88877 66554",
    walletBalance: 120.0,
    bonusBalance: 30.0,
    playedCount: 42,
    wonCount: 22,
    totalEarnings: 4500.0,
    isAdmin: false,
  },
  {
    uid: "user_03",
    name: "Booyah Slayer",
    email: "slayer@garena.com",
    phone: "+91 77766 55443",
    walletBalance: 15.0,
    bonusBalance: 15.0,
    playedCount: 9,
    wonCount: 2,
    totalEarnings: 300.0,
    isAdmin: false,
  },
  {
    uid: "user_04",
    name: "Aman Gaming",
    email: "aman@esports.in",
    phone: "+91 99900 11223",
    walletBalance: 5.0,
    bonusBalance: 8.0,
    playedCount: 1,
    wonCount: 0,
    totalEarnings: 0.0,
    isAdmin: false,
  },
];

const DEFAULT_PROMO_CODES: PromoCode[] = [
  { id: 'pc1', code: "FREE50", rewardAmount: 50.0, type: "BONUS", expiryDate: "2026-12-31", usageLimit: 100, redeemedCount: 0, redeemedBy: [], enabled: true },
  { id: 'pc2', code: "GOLDREDEEM", rewardAmount: 100.0, type: "MAIN", expiryDate: "2026-12-31", usageLimit: 50, redeemedCount: 0, redeemedBy: [], enabled: true },
  { id: 'pc3', code: "BOOYAH25", rewardAmount: 25.0, type: "BONUS", expiryDate: "2026-12-31", usageLimit: 200, redeemedCount: 0, redeemedBy: [], enabled: true }
];

const DEFAULT_ANNOUNCEMENTS: Announcement[] = [
  {
    id: "ann_01",
    title: "FREE FIRE CHAMPIONS LEAGUE S12",
    content: "Greetings Gladiators! Registration for the competitive Season 12 is officially open. Verify your custom slots and stand a chance to claim up to $500 Golden Prize Pools. Play fair!",
    scheduledTime: "2026-07-16 12:00",
    pinned: true,
    timestamp: "2026-07-16 10:00"
  },
  {
    id: "ann_02",
    title: "ANTI-CHEAT ENGINE UPGRADE",
    content: "Our custom server-side security protocols have been reinforced to AES-256 standard. Any participant running secondary macro-clickers or modified APKs will be auto-suspended in real time.",
    scheduledTime: "2026-07-15 15:00",
    pinned: false,
    timestamp: "2026-07-15 14:30"
  }
];

export const DEFAULT_OFFERS: OfferApp[] = [
  {
    id: "off_1",
    appName: "Telegram",
    logoUrl: "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=100",
    downloadUrl: "https://play.google.com/store/apps/details?id=org.telegram.messenger",
    rewardAmount: 20.0,
    packageName: "org.telegram.messenger"
  },
  {
    id: "off_2",
    appName: "Discord",
    logoUrl: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?q=80&w=100",
    downloadUrl: "https://play.google.com/store/apps/details?id=com.discord",
    rewardAmount: 15.0,
    packageName: "com.discord"
  },
  {
    id: "off_3",
    appName: "Free Fire Max",
    logoUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=100",
    downloadUrl: "https://play.google.com/store/apps/details?id=com.dts.freefiremax",
    rewardAmount: 50.0,
    packageName: "com.dts.freefiremax"
  }
];


export class FirestoreDb {
  static getStorage<T>(key: string, defaults: T): T {
    try {
      const saved = localStorage.getItem(`FIRESTORE_${key}`);
      return saved ? JSON.parse(saved) : defaults;
    } catch {
      return defaults;
    }
  }

  static setStorage<T>(key: string, data: T): void {
    try {
      localStorage.setItem(`FIRESTORE_${key}`, JSON.stringify(data));
      // Dispatch storage event to notify other components/tabs if any
      window.dispatchEvent(new Event('storage_change'));
    } catch (e) {
      console.error(`Failed to write FIRESTORE_${key}`, e);
    }
  }

  // APP SETTINGS CRUD
  static getSettings(): AppSettings {
    return this.getStorage<AppSettings>('settings', DEFAULT_APP_SETTINGS);
  }

  static saveSettings(settings: AppSettings): void {
    this.setStorage<AppSettings>('settings', settings);
  }

  // MATCH TYPES CRUD
  static getMatchTypes(): MatchType[] {
    const list = this.getStorage<MatchType[]>('match_types', DEFAULT_MATCH_TYPES);
    return list.sort((a, b) => a.order - b.order);
  }

  static saveMatchTypes(list: MatchType[]): void {
    this.setStorage<MatchType[]>('match_types', list);
  }

  // MAPS CRUD
  static getMaps(): MapItem[] {
    const list = this.getStorage<MapItem[]>('maps', DEFAULT_MAPS);
    return list.sort((a, b) => a.order - b.order);
  }

  static saveMaps(list: MapItem[]): void {
    this.setStorage<MapItem[]>('maps', list);
  }

  // PROMO CODES CRUD
  static getPromoCodes(): PromoCode[] {
    return this.getStorage<PromoCode[]>('promo_codes', DEFAULT_PROMO_CODES);
  }

  static savePromoCodes(list: PromoCode[]): void {
    this.setStorage<PromoCode[]>('promo_codes', list);
  }

  // ANNOUNCEMENTS CRUD
  static getAnnouncements(): Announcement[] {
    return this.getStorage<Announcement[]>('announcements', DEFAULT_ANNOUNCEMENTS);
  }

  static saveAnnouncements(list: Announcement[]): void {
    this.setStorage<Announcement[]>('announcements', list);
  }

  // USER MANAGEMENT
  static getUsers(): UserProfile[] {
    return this.getStorage<UserProfile[]>('users', DEFAULT_USERS);
  }

  static saveUsers(list: UserProfile[]): void {
    this.setStorage<UserProfile[]>('users', list);
  }

  // NOTIFICATIONS
  static getNotifications(): AdminNotification[] {
    return this.getStorage<AdminNotification[]>('notifications_log', []);
  }

  static saveNotifications(list: AdminNotification[]): void {
    this.setStorage<AdminNotification[]>('notifications_log', list);
  }

  // TOURNAMENTS CRUD
  static getTournaments(initialTournaments: Tournament[]): Tournament[] {
    return this.getStorage<Tournament[]>('tournaments', initialTournaments);
  }

  static saveTournaments(list: Tournament[]): void {
    this.setStorage<Tournament[]>('tournaments', list);
  }

  // TRANSACTIONS CRUD
  static getTransactions(initialTransactions: Transaction[]): Transaction[] {
    return this.getStorage<Transaction[]>('transactions', initialTransactions);
  }

  static saveTransactions(list: Transaction[]): void {
    this.setStorage<Transaction[]>('transactions', list);
  }

  // COUPONS CRUD
  static getCoupons(initialCoupons: Coupon[]): Coupon[] {
    return this.getStorage<Coupon[]>('coupons', initialCoupons);
  }

  static saveCoupons(list: Coupon[]): void {
    this.setStorage<Coupon[]>('coupons', list);
  }

  // OFFERS CRUD
  static getOffers(): OfferApp[] {
    return this.getStorage<OfferApp[]>('offers', DEFAULT_OFFERS);
  }

  static saveOffers(list: OfferApp[]): void {
    this.setStorage<OfferApp[]>('offers', list);
  }
}
