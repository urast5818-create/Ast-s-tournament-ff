import { Tournament, Coupon } from './types';

export const INITIAL_TOURNAMENTS: Tournament[] = [
  {
    id: "ff_diamond_01",
    title: "GRAND DUELS: SQUAD ARENA",
    gameName: "Free Fire",
    dateTime: "2026-07-16 18:00",
    totalSlots: 48,
    joinedCount: 42,
    entryFee: 15.0,
    prizePool: 500.0,
    perKillPrize: 2.0,
    mapName: "Bermuda Remastered",
    type: "SQUAD",
    roomId: "FF-ROOM-88392",
    roomPassword: "booyah_gladiator",
    participants: ["user_01", "user_02", "user_03", "user_04"],
    reportedIssues: [
      { id: "rep_01", userId: "user_04", userName: "Aman Gaming", description: "Hacker team entered the match", status: "PENDING", timestamp: "2026-07-15 09:12" }
    ]
  },
  {
    id: "ff_rush_02",
    title: "BOOYAH RUSH: SOLO STRIKER",
    gameName: "Free Fire",
    dateTime: "2026-07-16 20:30",
    totalSlots: 100,
    joinedCount: 78,
    entryFee: 5.0,
    prizePool: 400.0,
    perKillPrize: 1.0,
    mapName: "Purgatory",
    type: "SOLO",
    roomId: "FF-ROOM-49102",
    roomPassword: "rush_to_victory",
    participants: ["user_01", "user_03"],
    reportedIssues: []
  },
  {
    id: "ff_clash_03",
    title: "CLASH SQUAD: CHRONO CUP",
    gameName: "Free Fire",
    dateTime: "2026-07-17 15:00",
    totalSlots: 8,
    joinedCount: 8,
    entryFee: 25.0,
    prizePool: 150.0,
    perKillPrize: 5.0,
    mapName: "Kalahari",
    type: "DUO",
    roomId: "FF-ROOM-20412",
    roomPassword: "clash_kings",
    participants: ["user_02", "user_03"],
    reportedIssues: []
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  { code: "FREE50", amount: 50.0, type: "BONUS", redeemedBy: [] },
  { code: "GOLDREDEEM", amount: 100.0, type: "MAIN", redeemedBy: [] },
  { code: "BOOYAH25", amount: 25.0, type: "BONUS", redeemedBy: [] }
];

export const DART_FILES: Record<string, { path: string; code: string }> = {
  app_strings: {
    path: "lib/config/app_strings.dart",
    code: `class AppStrings {
  // App General
  static const String appName = "AST'S ARENA";
  static const String logoText = "AST'S ARENA";

  // Splash Screen
  static const String splashBadge = "BOOYAH ARENA v2.1";
  static const String splashTitle = "AST'S ARENA";
  static const String splashSubtitle = "The premium tactical companion and automated custom tournament workspace for Free Fire professionals.";
  static const String splashFooter = "© 2026 Ast's Arena. All rights reserved.";

  // Login Screen
  static const String loginTitle = "ARENA ACCESS";
  static const String loginSubtitle = "Enter your registered credentials to access your tournament desk.";
  static const String phoneLabel = "Phone Number / Username";
  static const String phonePlaceholder = "+91 98765 43210";
  static const String passwordLabel = "Lobby Password";
  static const String passwordPlaceholder = "••••••••";
  static const String loginButton = "ACCESS ARENA";
  static const String memberHeader = "ARENA MEMBER ACCESS";
  static const String memberDesc = "Enter your active phone number and password to login directly to the tournament. No OTP authentication required for instant access.";
  static const String footerSecure = "🔐 SECURED BY AES-256 ENCRYPTION ENGINE";

  // Sidebar / Navigation
  static const String navExplore = "Explore Matches";
  static const String navMyRooms = "My Rooms";
  static const String navWallet = "Wallet Hub";
  static const String navProfile = "Gladiator Profile";
  static const String navAdmin = "Admin Suite";
  static const String navDevHub = "Developer Hub";
  static const String navTelegramHeader = "TELEGRAM CHAN";
  static const String navTelegramSub = "Daily Promo codes!";
  static const String navSignOut = "SIGN OUT";

  // Explore Tab / Banner
  static const String exploreBannerBadge = "🏆 CHAMPIONSHIP WEEK";
  static const String exploreBannerStatus = "● LIVE LOBBY UPDATING";
  static const String exploreBannerTitle = "FREE FIRE GLADIATOR CUP";
  static const String exploreBannerDesc = "Welcome to the arena! Participate in high-stakes room duels, secure your slots, win premium Booyah prize pools, and verify room login keys directly.";
  static const String exploreBannerSecure = "GUARANTEED SECURE PLAYOUTS";
  static const String exploreActiveMatches = "⚔️ ACTIVE CUSTOM MATCHES";
  static const String exploreCompetitive = "FREE FIRE COMPETITIVE";

  // Tournament Cards & Labels
  static const String cardLiveBadge = "● LIVE ENROLLING";
  static const String cardStartsIn = "Starts in: ";
  static const String cardDateTime = "DATE & TIME";
  static const String cardEntryCost = "ENTRY COST";
  static const String cardMain = "MAIN";
  static const String cardProgress = "REGISTRATION PROGRESS";
  static const String cardSlots = "Slots";
  static const String cardCapacity = "Room Capacity: ";
  static const String cardSlotsLeft = "SLOTS LEFT";
  static const String cardRegistered = "🎮 SLOT REGISTERED";
  static const String cardJoinButton = "JOIN TOURNAMENT";

  // My Rooms Screen
  static const String roomsTitle = "My Registered Lobbies";
  static const String roomsSubtitle = "Verify credentials, passwords, and custom room schedule guidelines for your active slots.";
  static const String roomsNoSlotsTitle = "NO SLOTS REGISTERED";
  static const String roomsNoSlotsDesc = "You haven't purchased slots in any active matches. Go to Explore tab and register in a tournament!";
  static const String roomsExploreButton = "EXPLORE LOBBIES";
  static const String roomsSlotAssigned = "SLOT ASSIGNED";
  static const String roomsPrizeLabel = "PRIZE";
  static const String roomsMapLabel = "MAP STATUS:";
  static const String roomsRoomIdLabel = "ROOM ID:";
  static const String roomsPasswordLabel = "PASSWORD:";
  static const String roomsCopyButton = "Copy Room Credentials";

  // Leaderboard
  static const String leaderboardTitle = "GLADIATOR STANDINGS";
  static const String leaderboardSeason = "SEASON 12";
  static const String leaderboardSimulate = "SIMULATE SOLO MATCH WIN (+1)";
  static const String leaderboardYou = "YOU";
  static const String leaderboardWins = "Wins";
  static const String leaderboardWinRate = "WR";
  static const String leaderboardTip = "💡 Tap any player card to view detailed bio & battle stats";

  // Profile Screen
  static const String profileLevel = "LEVEL ";
  static const String profileLevelPlatinum = "78 PLATINUM";
  static const String profileLevelElite = "52 ELITE";
  static const String profileBio = "Official Free Fire Esports Arena verified participant. Elite guild shooter specializing in mid-range combat and squad strategic layouts.";
  static const String profilePlayedHeader = "MATCHES PARTICIPATED";
  static const String profilePlayedSub = "Cumulative rooms joined";
  static const String profileWonHeader = "MATCHES VICTORIOUS";
  static const String profileWonSub = "Booyah victories claims";
  static const String profileWinRateHeader = "BOOYAH WIN RATIO";
  static const String profileWinRateSub = "Accuracy efficiency rate";
  static const String profileAchievements = "GLADIATOR ACHIEVEMENTS";
  static const String profileAch1Title = "SQUAD TERMINATOR";
  static const String profileAch1Desc = "Won squad tournament with 10+ collective headshots.";
  static const String profileAch2Title = "BOOYAH HIGHLANDER";
  static const String profileAch2Desc = "Completed 5 consecutive solo arena tournament wins.";
  static const String profileAch3Title = "PLATINUM SPONSOR";
  static const String profileAch3Desc = "Deposited cash pool and participated in custom matches.";
  
  static const String profileSummaryHeader = "TOURNAMENT ACCOUNT SUMMARY";
  static const String profileRankLabel = "GLADIATOR VERIFIED RANK";
  static const String profileSeasonLabel = "SEASON MATCHES JOINED";
  static const String profileVictoryLabel = "COMPETITIVE VICTORY POOL";
  static const String profileSecurityLabel = "VERIFICATION SECURITY SIGNATURE";
  static const String profileRankValue = "HEROIC PLATINUM";
  static const String profileSeasonValue = "14 STABLE ATTEMPTS";
  static const String profileVictoryValue = "8 BOOYAH DEEDS";
  static const String profileSecurityValue = "VERIFIED ESPORTS PRO";
  static const String profileAdminLobby = "ADMIN ACCESS LOBBY";
  static const String profileAuthorized = "AUTHORIZED";

  // Wallet Screen
  static const String walletMainHeader = "MAIN WALLET BALANCE";
  static const String walletMainSub = "* 100% redeemable and withdrawable immediately";
  static const String walletBonusHeader = "BONUS VOUCHER BALANCE";
  static const String walletBonusSub = "* Use this to pay up to 50% match entry fees";
  static const String walletDepositLabel = "ADD FUNDS (UPI)";
  static const String walletWithdrawLabel = "WITHDRAW CASH (UPI)";
  static const String walletDepositTitle = "Deposit Funds";
  static const String walletManualBadge = "MANUAL GATEWAY SYNC";
  static const String walletDepositAmount = "AMOUNT TO DEPOSIT ($)";
  static const String walletDepositRef = "UPI TRANSACTION REF ID";
  static const String walletDepositPlaceholder = "e.g. UPI982348234";
  static const String walletDepositButton = "SUBMIT DEPOSIT CLAIM";
  static const String walletDepositTip = "💡 Transfer funds to UPI id: astarena@upi. Copy the reference ID and click submit above!";
  static const String walletWithdrawTitle = "Withdraw Funds";
  static const String walletWithdrawBadge = "ROOT TRANSFERS";
  static const String walletWithdrawAmount = "AMOUNT TO WITHDRAW ($)";
  static const String walletWithdrawUpi = "YOUR PAYOUT UPI ID";
  static const String walletWithdrawPlaceholder = "e.g. username@upi";
  static const String walletWithdrawButton = "SUBMIT WITHDRAWAL REQUEST";
  static const String walletWithdrawTip = "💡 Withdrawals are approved by admins and transferred directly to your wallet within 10-15 minutes!";
  static const String walletRedeemTitle = "REDEEM PROMO CODE";
  static const String walletPromoPlaceholder = "ENTER PROMO CODE";
  static const String walletRedeemButton = "REDEEM";
  static const String walletRedeemTip = "* Enter voucher codes distributed daily on Ast's official Telegram Broadcast to claim instant balances!";
  static const String walletLedgerTitle = "TRANSACTION LEDGER HISTORY";
  static const String walletStatusApproved = "APPROVED";
  static const String walletStatusPending = "PENDING";
  static const String walletStatusRejected = "REJECTED";

  // Admin Panel
  static const String adminTitle = "ADMIN CONTROL PANEL";
  static const String adminSecuredBadge = "SYSTEM SECURED";
  static const String adminPlayersLabel = "TOTAL PLAYERS REGISTERED";
  static const String adminPlayersSub = "Active tournament participants";
  static const String adminPrizesLabel = "COMBINED CASH PRIZES";
  static const String adminPrizesSub = "Active combined prize pools";
  static const String adminFillLabel = "AVERAGE MATCH FILL RATE";
  static const String adminFillSub = "Average slot utilization metrics";
  static const String adminChart1Title = "REGISTRATION GROWTH DEMAND";
  static const String adminChart1Sub = "cumulative registered slots past 7 days";
  static const String adminChart2Title = "ROOM SLOTS OCCUPANCY RATES";
  static const String adminChart2Sub = "filled vs. empty capacity slot indicators";
  static const String adminFilledLabel = "FILLED";
  static const String adminVacantLabel = "VACANT";
  static const String adminPublishHeader = "Publish Custom Tournament Match";
  static const String adminMatchTitle = "TOURNAMENT MATCH TITLE";
  static const String adminEntryCost = "ENTRY COST ($)";
  static const String adminPrizePool = "PRIZE MONEY POOL ($)";
  static const String adminMaxSlots = "MAX SLOTS CAPACITY";
  static const String adminMapLabel = "BATTLE ARENA MAP";
  static const String adminFormatLabel = "MATCH FORMAT TYPE";
  static const String adminPublishButton = "PUBLISH LIVE TOURNAMENT LOBBY";
  static const String adminPendingDeposits = "PENDING UPI MANUAL DEPOSITS";
  static const String adminNoPending = "No pending deposit claims requiring authentication.";
  static const String adminRejectButton = "REJECT";
  static const String adminApproveButton = "APPROVE";
  static const String adminGrowthBadge = "GROW";
  static const String adminMatchPlaceholder = "e.g. ULTIMATE RUSH CUP";
  static const String adminDepositPrefix = "DEPOSIT REQUEST: $";
  static const String adminTxnId = "TXN REF ID:";
  static const String adminStatus = "STATUS:";
  static const String adminVerificationReq = "VERIFICATION REQUIRED";

  // Dialogs / Overlays
  static const String modalDetailsBadge = "LOBBY DETAILS";
  static const String modalMap = "MAP ARENA";
  static const String modalFormat = "TEAM FORMAT";
  static const String modalEntryFee = "ENTRY FEE";
  static const String modalSlots = "SLOTS ASSIGNED";
  static const String modalCredentials = "SECURED CUSTOM ROOM CREDENTIALS";
  static const String modalRoomId = "ROOM ID";
  static const String modalPassword = "PASSWORD";
  static const String modalCopy = "Copy Credentials";
  static const String modalCopied = "Copied Keys successfully!";
  static const String modalRegister = "Register Slot";
  static const String modalStartTime = "* Matches schedule starts strictly at ";
  static const String modalProfileBadge = "PLAYER PROFILE DOSSIER";
  static const String modalTier = "TIER: ";
  static const String modalWeapon = "FAV WEAPON: ";
  static const String modalPlayed = "MATCHES PLAYED";
  static const String modalWon = "MATCHES WON";
  static const String modalBattleNotes = "Battle Status Notes:";
  static const String modalBattleDesc = "Officially verified esports participant with competitive combat logs. Recommended partner for Squad Arena matches.";

  // Announcements & Callouts
  static const String calloutTelegramTitle = "Join our Telegram for Live Updates!";
  static const String calloutTelegramBadge = "Join to get promo code and redeem code";
  static const String calloutTelegramDesc = "Claim daily room schedules, get direct coupon updates, custom game room credentials, and priority dispute support directly.";
  static const String calloutTelegramButton = "JOIN TELEGRAM NOW";

  // Error & Success & Notifications
  static const String notifyAlreadyRegistered = "You are already registered for this tournament!";
  static const String notifyInsufficientBalance = "Insufficient Balance in Main Wallet! Please deposit cash.";
  static const String notifyEnterUpiRef = "Please enter UPI Transaction ID to claim deposit.";
  static const String notifyDepositSubmitted = "Deposit request submitted! Admin will verify UPI ID within 5-10 minutes.";
  static const String notifyInsufficientFundsWithdraw = "Insufficient funds in Main Wallet!";
  static const String notifyEnterUpiWithdraw = "Please enter a valid UPI address.";
  static const String notifyWithdrawSubmitted = "Withdrawal submitted! Funds locked. Admin will transfer directly.";
  static const String notifyInvalidPromo = "Invalid code or voucher code expired.";
  static const String notifyPromoAlreadyRedeemed = "You have already redeemed this promo code!";
  static const String notifyPromoRedeemedSuccess = "Promo code successfully redeemed!";
  static const String notifyTournamentCreated = "New Tournament created successfully!";
  static const String notifyTxnApproved = "Transaction APPROVED & wallet updated!";
  static const String notifyTxnRejected = "Transaction rejected.";
}`
  },
  main_dart: {
    path: "lib/main.dart",
    code: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/firebase_service.dart';
import 'services/offline_db_service.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize local offline fallback SQLite storage
  final offlineDb = OfflineDbService();
  await offlineDb.initDatabase();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => FirebaseService(offlineDb: offlineDb),
        ),
      ],
      child: const AstsEsportsApp(),
    ),
  );
}

class AstsEsportsApp extends StatelessWidget {
  const AstsEsportsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Ast's Free Fire Arena",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF05070F),
        primaryColor: Colors.amber,
        fontFamily: 'SpaceGrotesk',
        colorScheme: const ColorScheme.dark(
          primary: Colors.amber,
          secondary: Colors.amberAccent,
          background: Color(0xFF05070F),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}`
  },
  wallet_tab: {
    path: "lib/screens/tabs/wallet_tab.dart",
    code: `import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/firebase_service.dart';
import 'package:url_launcher/url_launcher.dart';

class WalletTab extends StatefulWidget {
  const WalletTab({super.key});

  @override
  State<WalletTab> createState() => _WalletTabState();
}

class _WalletTabState extends State<WalletTab> {
  final _promoCtrl = TextEditingController();
  final _depAmountCtrl = TextEditingController();
  final _depUpiCtrl = TextEditingController();
  final _withAmountCtrl = TextEditingController();
  final _withUpiCtrl = TextEditingController();

  @override
  void dispose() {
    _promoCtrl.dispose();
    _depAmountCtrl.dispose();
    _depUpiCtrl.dispose();
    _withAmountCtrl.dispose();
    _withUpiCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);
    final user = fb.currentUserProfile;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildBalanceCards(user),
          const SizedBox(height: 16),
          _buildActionForms(fb),
          const SizedBox(height: 24),
          _buildPremiumGoldTelegramCallout(),
          const SizedBox(height: 24),
          const Text(
            'TRANSACTION HISTORIES',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          _buildTransactionLedger(fb),
        ],
      ),
    );
  }

  Widget _buildBalanceCards(dynamic user) {
    return Row(
      children: [
        Expanded(
          child: Card(
            color: const Color(0xFF0F172A),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: const BorderSide(color: Color(0xFF1E293B)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Main Wallet', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(
                    '₹\${user?.walletBalance.toStringAsFixed(2) ?? "0.00"}',
                    style: const TextStyle(color: Colors.orangeAccent, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Card(
            color: const Color(0xFF0F172A),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: const BorderSide(color: Color(0xFF1E293B)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Bonus Balance', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(
                    '₹\${user?.bonusBalance.toStringAsFixed(2) ?? "0.00"}',
                    style: const TextStyle(color: Colors.amberAccent, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPremiumGoldTelegramCallout() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E1D),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.amber.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.amber.withOpacity(0.08),
            blurRadius: 30,
            offset: const Offset(0, 4),
          )
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Colors.orange, Colors.amber],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.send, color: Colors.black, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Join our Telegram for Live Updates!",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.orange.withOpacity(0.2)),
                      ),
                      child: const Text(
                        "Join to get promo code and redeem code",
                        style: TextStyle(
                          color: Colors.orangeAccent,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            "Claim daily room schedules, get direct coupon updates, custom game room credentials, and priority dispute support directly.",
            style: TextStyle(color: Colors.grey, fontSize: 11),
          ),
          const SizedBox(height: 14),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            onPressed: () async {
              final url = Uri.parse("https://t.me/your_channel");
              if (await canLaunchUrl(url)) {
                await launchUrl(url);
              }
            },
            child: const Text('JOIN TELEGRAM NOW', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
          ),
        ],
      ),
    );
  }

  Widget _buildActionForms(dynamic fb) => const Placeholder(fallbackHeight: 80);
  Widget _buildTransactionLedger(dynamic fb) => const Placeholder(fallbackHeight: 120);
}`
  },
  firebase_service: {
    path: "lib/services/firebase_service.dart",
    code: `import 'package:flutter/material.dart';
import '../models/tournament.dart';
import '../models/user_profile.dart';
import '../models/transaction.dart';
import 'offline_db_service.dart';

class FirebaseService extends ChangeNotifier {
  final OfflineDbService offlineDb;
  bool _isOnline = true;
  UserProfile? _currentUserProfile;
  List<Tournament> _mockTournaments = [];
  List<Transaction> _mockTransactions = [];

  FirebaseService({required this.offlineDb}) {
    _initializeLocalDatabase();
  }

  bool get isOnline => _isOnline;
  UserProfile? get currentUserProfile => _currentUserProfile;
  List<Tournament> get tournaments => _mockTournaments;
  List<Transaction> get transactions => _mockTransactions;

  void _initializeLocalDatabase() async {
    final savedUser = await offlineDb.loadUserProfile();
    if (savedUser != null) {
      _currentUserProfile = savedUser;
    } else {
      _currentUserProfile = UserProfile(
        uid: "user_01",
        name: "Ast Gamer",
        email: "urast5818@gmail.com",
        phone: "+91 98765 43210",
        walletBalance: 250.0,
        bonusBalance: 50.0,
        playedCount: 14,
        wonCount: 8,
        totalEarnings: 1200.0,
        isAdmin: true,
      );
    }
    notifyListeners();
  }

  Future<void> joinTournament(String tournamentId, double fee) async {
    if (_currentUserProfile == null) return;
    
    _currentUserProfile = _currentUserProfile!.copyWith(
      walletBalance: _currentUserProfile!.walletBalance - fee,
      playedCount: _currentUserProfile!.playedCount + 1,
    );
    await offlineDb.saveUserProfile(_currentUserProfile!);
    notifyListeners();
  }
}`
  },
  tournament_model: {
    path: "lib/models/tournament.dart",
    code: `class Tournament {
  final String id;
  final String title;
  final String gameName;
  final String dateTime;
  final int totalSlots;
  final int joinedCount;
  final double entryFee;
  final double prizePool;
  final double perKillPrize;
  final String mapName;
  final String type;
  final String? roomId;
  final String? roomPassword;
  final List<String> participants;

  Tournament({
    required this.id,
    required this.title,
    required this.gameName,
    required this.dateTime,
    required this.totalSlots,
    required this.joinedCount,
    required this.entryFee,
    required this.prizePool,
    required this.perKillPrize,
    required this.mapName,
    required this.type,
    this.roomId,
    this.roomPassword,
    required this.participants,
  });

  factory Tournament.fromJson(Map<String, dynamic> json) {
    return Tournament(
      id: json['id'] as String,
      title: json['title'] as String,
      gameName: json['gameName'] as String,
      dateTime: json['dateTime'] as String,
      totalSlots: json['totalSlots'] as int,
      joinedCount: json['joinedCount'] as int,
      entryFee: (json['entryFee'] as num).toDouble(),
      prizePool: (json['prizePool'] as num).toDouble(),
      perKillPrize: (json['perKillPrize'] as num).toDouble(),
      mapName: json['mapName'] as String,
      type: json['type'] as String,
      roomId: json['roomId'] as String?,
      roomPassword: json['roomPassword'] as String?,
      participants: List<String>.from(json['participants'] ?? []),
    );
  }
}`
  }
};
