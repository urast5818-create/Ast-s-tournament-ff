const DEFAULT_STRINGS = {
  // Splash Screen
  splash: {
    badgeText: "BOOYAH ARENA v2.1",
    title: "AST'S ARENA",
    subtitle: "The premium tactical companion and automated custom tournament workspace for Free Fire professionals.",
    footer: "© 2026 Ast's Arena. All rights reserved.",
    statuses: [
      "Initializing Ast's Arena...",
      "Synchronizing tournament lobby databases...",
      "Loading active custom match schedules...",
      "Verifying security protocols...",
      "Loading wallet balance systems...",
      "Gladiator Arena is ready."
    ]
  },

  // Login Screen
  login: {
    title: "ARENA ACCESS",
    subtitle: "Enter your registered credentials to access your tournament desk.",
    phoneLabel: "Phone Number / Username",
    phonePlaceholder: "+91 98765 43210",
    passwordLabel: "Lobby Password",
    passwordPlaceholder: "••••••••",
    buttonText: "ACCESS ARENA",
    memberHeader: "ARENA MEMBER ACCESS",
    memberDesc: "Enter your active phone number and password to login directly to the tournament. No OTP authentication required for instant access.",
    footerSecureText: "🔐 SECURED BY AES-256 ENCRYPTION ENGINE"
  },

  // Sidebar / Navigation
  sidebar: {
    brandName: "AST'S ARENA",
    brandBadge: "● ESPORTS PRO",
    exploreLabel: "Explore Matches",
    myRoomsLabel: "My Rooms",
    walletLabel: "Wallet Hub",
    profileLabel: "Gladiator Profile",
    adminLabel: "Admin Suite",
    developerLabel: "Developer Hub",
    telegramHeader: "TELEGRAM CHAN",
    telegramSub: "Daily Promo codes!",
    signOutLabel: "SIGN OUT"
  },

  // Bottom Navigation
  bottomNav: {
    explore: "Explore",
    rooms: "Rooms",
    wallet: "Wallet",
    profile: "Profile",
    admin: "Admin",
    devHub: "Dev Hub"
  },

  // Explore Tab / Banners
  explore: {
    bannerBadge: "🏆 CHAMPIONSHIP WEEK",
    bannerStatus: "● LIVE LOBBY UPDATING",
    bannerTitle: "FREE FIRE GLADIATOR CUP",
    bannerDesc: "Welcome to the arena! Participate in high-stakes room duels, secure your slots, win premium Booyah prize pools, and verify room login keys directly.",
    bannerSecure: "GUARANTEED SECURE PLAYOUTS",
    activeMatchesHeader: "⚔️ ACTIVE CUSTOM MATCHES",
    competitiveLabel: "FREE FIRE COMPETITIVE"
  },

  // Tournament Cards
  tournamentCard: {
    liveBadge: "● LIVE ENROLLING",
    startsIn: "Starts in: ",
    dateTimeLabel: "DATE & TIME",
    entryCostLabel: "ENTRY COST",
    mainLabel: "MAIN",
    progressLabel: "REGISTRATION PROGRESS",
    slotsLabel: "Slots",
    capacityLabel: "Room Capacity: ",
    slotsLeftLabel: "SLOTS LEFT",
    registeredStatus: "🎮 SLOT REGISTERED",
    joinButtonText: "JOIN TOURNAMENT"
  },

  // My Rooms Tab
  myRooms: {
    title: "My Registered Lobbies",
    subtitle: "Verify credentials, passwords, and custom room schedule guidelines for your active slots.",
    noSlotsTitle: "NO SLOTS REGISTERED",
    noSlotsDesc: "You haven't purchased slots in any active matches. Go to Explore tab and register in a tournament!",
    exploreButtonText: "EXPLORE LOBBIES",
    slotAssigned: "SLOT ASSIGNED",
    prizeLabel: "PRIZE",
    mapLabel: "MAP STATUS:",
    roomIdLabel: "ROOM ID:",
    passwordLabel: "PASSWORD:",
    copyButtonText: "Copy Room Credentials"
  },

  // Leaderboard Widget
  leaderboard: {
    title: "GLADIATOR STANDINGS",
    seasonBadge: "SEASON 12",
    simulateButtonText: "SIMULATE SOLO MATCH WIN (+1)",
    youBadge: "YOU",
    winsLabel: "Wins",
    winRateLabel: "WR",
    tipText: "💡 Tap any player card to view detailed bio & battle stats"
  },

  // Profile Tab
  profile: {
    levelLabel: "LEVEL ",
    levelPlatinum: "78 PLATINUM",
    levelElite: "52 ELITE",
    bioDesc: "Official Free Fire Esports Arena verified participant. Elite guild shooter specializing in mid-range combat and squad strategic layouts.",
    playedHeader: "MATCHES PARTICIPATED",
    playedSub: "Cumulative rooms joined",
    wonHeader: "MATCHES VICTORIOUS",
    wonSub: "Booyah victories claims",
    winRateHeader: "BOOYAH WIN RATIO",
    winRateSub: "Accuracy efficiency rate",
    achievementsHeader: "GLADIATOR ACHIEVEMENTS",
    ach1Title: "SQUAD TERMINATOR",
    ach1Desc: "Won squad tournament with 10+ collective headshots.",
    ach2Title: "BOOYAH HIGHLANDER",
    ach2Desc: "Completed 5 consecutive solo arena tournament wins.",
    ach3Title: "PLATINUM SPONSOR",
    ach3Desc: "Deposited cash pool and participated in custom matches.",
    envHeader: "TOURNAMENT ACCOUNT SUMMARY",
    envLabel: "GLADIATOR VERIFIED RANK",
    sdkLabel: "SEASON MATCHES JOINED",
    dbLabel: "COMPETITIVE VICTORY POOL",
    cryptoLabel: "VERIFICATION SECURITY SIGNATURE",
    envValue: "HEROIC PLATINUM",
    sdkValue: "14 STABLE ATTEMPTS",
    dbValue: "8 BOOYAH DEEDS",
    cryptoValue: "VERIFIED ESPORTS PRO",
    adminLobbyLabel: "ADMIN ACCESS LOBBY",
    authorizedLabel: "AUTHORIZED"
  },

  // Wallet Tab
  wallet: {
    mainWalletHeader: "MAIN WALLET BALANCE",
    mainWalletSub: "* 100% redeemable and withdrawable immediately",
    bonusWalletHeader: "BONUS VOUCHER BALANCE",
    bonusWalletSub: "* Use this to pay up to 50% match entry fees",
    tabDepositLabel: "ADD FUNDS (UPI)",
    tabWithdrawLabel: "WITHDRAW CASH (UPI)",
    depositTitle: "Deposit Funds",
    manualGatewayBadge: "MANUAL GATEWAY SYNC",
    depositAmountLabel: "AMOUNT TO DEPOSIT ($)",
    depositRefLabel: "UPI TRANSACTION REF ID",
    depositRefPlaceholder: "e.g. UPI982348234",
    depositButtonText: "SUBMIT DEPOSIT CLAIM",
    depositTip: "💡 Transfer funds to UPI id: astarena@upi. Copy the reference ID and click submit above!",
    withdrawTitle: "Withdraw Funds",
    rootTransfersBadge: "ROOT TRANSFERS",
    withdrawAmountLabel: "AMOUNT TO WITHDRAW ($)",
    withdrawUpiLabel: "YOUR PAYOUT UPI ID",
    withdrawUpiPlaceholder: "e.g. username@upi",
    withdrawButtonText: "SUBMIT WITHDRAWAL REQUEST",
    withdrawTip: "💡 Withdrawals are approved by admins and transferred directly to your wallet within 10-15 minutes!",
    redeemTitle: "REDEEM PROMO CODE",
    promoPlaceholder: "ENTER PROMO CODE",
    redeemButtonText: "REDEEM",
    redeemTip: "* Enter voucher codes distributed daily on Ast's official Telegram Broadcast to claim instant balances!",
    ledgerTitle: "TRANSACTION LEDGER HISTORY",
    statusApproved: "APPROVED",
    statusPending: "PENDING",
    statusRejected: "REJECTED"
  },

  // Admin Tab
  admin: {
    title: "ADMIN CONTROL PANEL",
    securedBadge: "SYSTEM SECURED",
    totalPlayersLabel: "TOTAL PLAYERS REGISTERED",
    totalPlayersSub: "Active tournament participants",
    totalPrizesLabel: "COMBINED CASH PRIZES",
    totalPrizesSub: "Active combined prize pools",
    avgFillRateLabel: "AVERAGE MATCH FILL RATE",
    avgFillRateSub: "Average slot utilization metrics",
    chart1Title: "REGISTRATION GROWTH DEMAND",
    chart1Sub: "cumulative registered slots past 7 days",
    chart2Title: "ROOM SLOTS OCCUPANCY RATES",
    chart2Sub: "filled vs. empty capacity slot indicators",
    filledLabel: "FILLED",
    vacantLabel: "VACANT",
    formHeader: "Publish Custom Tournament Match",
    matchTitleLabel: "TOURNAMENT MATCH TITLE",
    entryCostLabel: "ENTRY COST ($)",
    prizePoolLabel: "PRIZE MONEY POOL ($)",
    maxSlotsLabel: "MAX SLOTS CAPACITY",
    mapLabel: "BATTLE ARENA MAP",
    formatLabel: "MATCH FORMAT TYPE",
    publishButtonText: "PUBLISH LIVE TOURNAMENT LOBBY",
    pendingDepositsHeader: "PENDING UPI MANUAL DEPOSITS",
    noPendingDeposits: "No pending deposit claims requiring authentication.",
    rejectButton: "REJECT",
    approveButton: "APPROVE",
    growthBadge: "GROW",
    matchTitlePlaceholder: "e.g. ULTIMATE RUSH CUP",
    depositRequestPrefix: "DEPOSIT REQUEST: $",
    txnIdLabel: "TXN REF ID:",
    statusLabel: "STATUS:",
    verificationRequired: "VERIFICATION REQUIRED"
  },

  // Developer Hub Tab
  devHub: {
    title: "DART FLUTTER DEV HUB",
    repoBadge: "LOCAL REPOSITORY",
    compilerHeader: "DART REPOSITORY INTERACTIVE COMPILER",
    copyButtonText: "Copy Dart Code",
    copiedText: "Copied File!",
    projectSourceLabel: "PROJECT SOURCE FILES",
    filePathLabel: "FILEPATH: ",
    sourceLabel: "DART SOURCE",
    guideHeader: "FLUTTER SDK COMPILATION GUIDE",
    guideDesc: "These modular classes reflect AST'S custom offline SQLite fallback architecture synced directly to secure Cloud databases. Follow these directives to compile into native platforms:",
    step1Title: "1. SYNC DEPENDENCIES",
    step2Title: "2. COMPILE TO ANDROID MOBILE APK",
    step3Title: "3. COMPILE TO APPLE IOS CONTAINER",
    architectureHeader: "COHESIVE INTEGRATED ARCHITECTURE",
    feature1Title: "Offline SQLite Integration:",
    feature1Desc: "Utilizes OfflineDbService to write transaction histories in local device storage, operating smoothly without a connection.",
    feature2Title: "Security Protocols:",
    feature2Desc: "Firebase Auth keys and secure coupon models prevent double voucher redemption across duplicate sessions.",
    feature3Title: "Cross-Platform Adaptation:",
    feature3Desc: "Direct interface styling can compile cleanly on iOS, Android, and Web browsers."
  },

  // Overlay Modals / Dialogs
  modals: {
    lobbyDetailsBadge: "LOBBY DETAILS",
    mapArena: "MAP ARENA",
    teamFormat: "TEAM FORMAT",
    entryFee: "ENTRY FEE",
    slotsAssigned: "SLOTS ASSIGNED",
    securedCredentials: "SECURED CUSTOM ROOM CREDENTIALS",
    roomIdLabel: "ROOM ID",
    passwordLabel: "PASSWORD",
    copyButtonText: "Copy Credentials",
    copiedButtonText: "Copied Keys successfully!",
    registerSlotButton: "Register Slot",
    startTimeLabel: "* Matches schedule starts strictly at ",
    playerProfileBadge: "PLAYER PROFILE DOSSIER",
    tierLabel: "TIER: ",
    favWeaponLabel: "FAV WEAPON: ",
    matchesPlayed: "MATCHES PLAYED",
    matchesWon: "MATCHES WON",
    battleStatusHeader: "Battle Status Notes:",
    battleStatusDesc: "Officially verified esports participant with competitive combat logs. Recommended partner for Squad Arena matches."
  },

  // Notifications, Dialogs, Snackbars, Errors and Success Messages
  notifications: {
    alreadyRegistered: "You are already registered for this tournament!",
    insufficientBalance: "Insufficient Balance in Main Wallet! Please deposit cash.",
    enterUpiRef: "Please enter UPI Transaction ID to claim deposit.",
    depositSubmitted: "Deposit request submitted! Admin will verify UPI ID within 5-10 minutes.",
    insufficientFundsWithdraw: "Insufficient funds in Main Wallet!",
    enterUpiWithdraw: "Please enter a valid UPI address.",
    withdrawSubmitted: "Withdrawal submitted! Funds locked. Admin will transfer directly.",
    invalidPromo: "Invalid code or voucher code expired.",
    promoAlreadyRedeemed: "You have already redeemed this promo code!",
    promoRedeemedSuccess: "Promo code successfully redeemed!",
    tournamentCreated: "New Tournament created successfully!",
    txnApproved: "Transaction APPROVED & wallet updated!",
    txnRejected: "Transaction rejected.",
    linkCopied: "Link copied successfully!",
    credentialsCopied: "Credentials copied to clipboard!"
  }
};

// Deep clone/merge helpers to avoid reference mutations
function deepMerge(target: any, source: any) {
  for (const key of Object.keys(source)) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
      if (!target[key]) target[key] = {};
      deepMerge(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}

export const appStrings = JSON.parse(JSON.stringify(DEFAULT_STRINGS));

// Load from localStorage if present
try {
  const saved = localStorage.getItem('AST_ARENA_STRINGS');
  if (saved) {
    const parsed = JSON.parse(saved);
    deepMerge(appStrings, parsed);
  }
} catch (e) {
  console.error("Failed to load saved strings:", e);
}

export function saveStrings(newStrings: any) {
  try {
    localStorage.setItem('AST_ARENA_STRINGS', JSON.stringify(newStrings));
    deepMerge(appStrings, newStrings);
  } catch (e) {
    console.error("Failed to save strings:", e);
  }
}

export function resetStrings() {
  try {
    localStorage.removeItem('AST_ARENA_STRINGS');
    // Clear current appStrings keys and restore defaults
    for (const key of Object.keys(appStrings)) {
      delete appStrings[key];
    }
    deepMerge(appStrings, JSON.parse(JSON.stringify(DEFAULT_STRINGS)));
  } catch (e) {
    console.error("Failed to reset strings:", e);
  }
}
