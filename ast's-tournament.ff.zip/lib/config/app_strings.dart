class AppStrings {
  // App General
  static const String appName = "AST'S ARENA";
  static const String logoText = "AST'S ARENA";

  // Splash Screen
  static const String splashBadge = "BOOYAH ARENA v2.1";
  static const String splashTitle = "AST'S ARENA";
  static const String splashSubtitle = "The premium tactical companion and automated custom tournament workspace for Free Fire professionals.";
  static const String splashFooter = "© 2026 Ast's Arena. All rights reserved.";

  // Login Screen
  static const String loginTitle = "ARENA ACCESS";
  static const String loginSubtitle = "Enter your registered credentials to access your tournament desk.";
  static const String phoneLabel = "Phone Number / Username";
  static const String phonePlaceholder = "+91 98765 43210";
  static const String passwordLabel = "Lobby Password";
  static const String passwordPlaceholder = "••••••••";
  static const String loginButton = "ACCESS ARENA";
  static const String memberHeader = "ARENA MEMBER ACCESS";
  static const String memberDesc = "Enter your active phone number and password to login directly to the tournament. No OTP authentication required for instant access.";
  static const String footerSecure = "🔐 SECURED BY AES-256 ENCRYPTION ENGINE";

  // Sidebar / Navigation
  static const String navExplore = "Explore Matches";
  static const String navMyRooms = "My Rooms";
  static const String navWallet = "Wallet Hub";
  static const String navProfile = "Gladiator Profile";
  static const String navAdmin = "Admin Suite";
  static const String navDevHub = "Developer Hub";
  static const String navTelegramHeader = "TELEGRAM CHAN";
  static const String navTelegramSub = "Daily Promo codes!";
  static const String navSignOut = "SIGN OUT";

  // Explore Tab / Banner
  static const String exploreBannerBadge = "🏆 CHAMPIONSHIP WEEK";
  static const String exploreBannerStatus = "● LIVE LOBBY UPDATING";
  static const String exploreBannerTitle = "FREE FIRE GLADIATOR CUP";
  static const String exploreBannerDesc = "Welcome to the arena! Participate in high-stakes room duels, secure your slots, win premium Booyah prize pools, and verify room login keys directly.";
  static const String exploreBannerSecure = "GUARANTEED SECURE PLAYOUTS";
  static const String exploreActiveMatches = "⚔️ ACTIVE CUSTOM MATCHES";
  static const String exploreCompetitive = "FREE FIRE COMPETITIVE";

  // Tournament Cards & Labels
  static const String cardLiveBadge = "● LIVE ENROLLING";
  static const String cardStartsIn = "Starts in: ";
  static const String cardDateTime = "DATE & TIME";
  static const String cardEntryCost = "ENTRY COST";
  static const String cardMain = "MAIN";
  static const String cardProgress = "REGISTRATION PROGRESS";
  static const String cardSlots = "Slots";
  static const String cardCapacity = "Room Capacity: ";
  static const String cardSlotsLeft = "SLOTS LEFT";
  static const String cardRegistered = "🎮 SLOT REGISTERED";
  static const String cardJoinButton = "JOIN TOURNAMENT";

  // My Rooms Screen
  static const String roomsTitle = "My Registered Lobbies";
  static const String roomsSubtitle = "Verify credentials, passwords, and custom room schedule guidelines for your active slots.";
  static const String roomsNoSlotsTitle = "NO SLOTS REGISTERED";
  static const String roomsNoSlotsDesc = "You haven't purchased slots in any active matches. Go to Explore tab and register in a tournament!";
  static const String roomsExploreButton = "EXPLORE LOBBIES";
  static const String roomsSlotAssigned = "SLOT ASSIGNED";
  static const String roomsPrizeLabel = "PRIZE";
  static const String roomsMapLabel = "MAP STATUS:";
  static const String roomsRoomIdLabel = "ROOM ID:";
  static const String roomsPasswordLabel = "PASSWORD:";
  static const String roomsCopyButton = "Copy Room Credentials";

  // Leaderboard
  static const String leaderboardTitle = "GLADIATOR STANDINGS";
  static const String leaderboardSeason = "SEASON 12";
  static const String leaderboardSimulate = "SIMULATE SOLO MATCH WIN (+1)";
  static const String leaderboardYou = "YOU";
  static const String leaderboardWins = "Wins";
  static const String leaderboardWinRate = "WR";
  static const String leaderboardTip = "💡 Tap any player card to view detailed bio & battle stats";

  // Profile Screen
  static const String profileLevel = "LEVEL ";
  static const String profileLevelPlatinum = "78 PLATINUM";
  static const String profileLevelElite = "52 ELITE";
  static const String profileBio = "Official Free Fire Esports Arena verified participant. Elite guild shooter specializing in mid-range combat and squad strategic layouts.";
  static const String profilePlayedHeader = "MATCHES PARTICIPATED";
  static const String profilePlayedSub = "Cumulative rooms joined";
  static const String profileWonHeader = "MATCHES VICTORIOUS";
  static const String profileWonSub = "Booyah victories claims";
  static const String profileWinRateHeader = "BOOYAH WIN RATIO";
  static const String profileWinRateSub = "Accuracy efficiency rate";
  static const String profileAchievements = "GLADIATOR ACHIEVEMENTS";
  static const String profileAch1Title = "SQUAD TERMINATOR";
  static const String profileAch1Desc = "Won squad tournament with 10+ collective headshots.";
  static const String profileAch2Title = "BOOYAH HIGHLANDER";
  static const String profileAch2Desc = "Completed 5 consecutive solo arena tournament wins.";
  static const String profileAch3Title = "PLATINUM SPONSOR";
  static const String profileAch3Desc = "Deposited cash pool and participated in custom matches.";
  
  static const String profileSummaryHeader = "TOURNAMENT ACCOUNT SUMMARY";
  static const String profileRankLabel = "GLADIATOR VERIFIED RANK";
  static const String profileSeasonLabel = "SEASON MATCHES JOINED";
  static const String profileVictoryLabel = "COMPETITIVE VICTORY POOL";
  static const String profileSecurityLabel = "VERIFICATION SECURITY SIGNATURE";
  static const String profileRankValue = "HEROIC PLATINUM";
  static const String profileSeasonValue = "14 STABLE ATTEMPTS";
  static const String profileVictoryValue = "8 BOOYAH DEEDS";
  static const String profileSecurityValue = "VERIFIED ESPORTS PRO";
  static const String profileAdminLobby = "ADMIN ACCESS LOBBY";
  static const String profileAuthorized = "AUTHORIZED";

  // Wallet Screen
  static const String walletMainHeader = "MAIN WALLET BALANCE";
  static const String walletMainSub = "* 100% redeemable and withdrawable immediately";
  static const String walletBonusHeader = "BONUS VOUCHER BALANCE";
  static const String walletBonusSub = "* Use this to pay up to 50% match entry fees";
  static const String walletDepositLabel = "ADD FUNDS (UPI)";
  static const String walletWithdrawLabel = "WITHDRAW CASH (UPI)";
  static const String walletDepositTitle = "Deposit Funds";
  static const String walletManualBadge = "MANUAL GATEWAY SYNC";
  static const String walletDepositAmount = "AMOUNT TO DEPOSIT (\$)";
  static const String walletDepositRef = "UPI TRANSACTION REF ID";
  static const String walletDepositPlaceholder = "e.g. UPI982348234";
  static const String walletDepositButton = "SUBMIT DEPOSIT CLAIM";
  static const String walletDepositTip = "💡 Transfer funds to UPI id: astarena@upi. Copy the reference ID and click submit above!";
  static const String walletWithdrawTitle = "Withdraw Funds";
  static const String walletWithdrawBadge = "ROOT TRANSFERS";
  static const String walletWithdrawAmount = "AMOUNT TO WITHDRAW (\$)";
  static const String walletWithdrawUpi = "YOUR PAYOUT UPI ID";
  static const String walletWithdrawPlaceholder = "e.g. username@upi";
  static const String walletWithdrawButton = "SUBMIT WITHDRAWAL REQUEST";
  static const String walletWithdrawTip = "💡 Withdrawals are approved by admins and transferred directly to your wallet within 10-15 minutes!";
  static const String walletRedeemTitle = "REDEEM PROMO CODE";
  static const String walletPromoPlaceholder = "ENTER PROMO CODE";
  static const String walletRedeemButton = "REDEEM";
  static const String walletRedeemTip = "* Enter voucher codes distributed daily on Ast's official Telegram Broadcast to claim instant balances!";
  static const String walletLedgerTitle = "TRANSACTION LEDGER HISTORY";
  static const String walletStatusApproved = "APPROVED";
  static const String walletStatusPending = "PENDING";
  static const String walletStatusRejected = "REJECTED";

  // Admin Panel
  static const String adminTitle = "ADMIN CONTROL PANEL";
  static const String adminSecuredBadge = "SYSTEM SECURED";
  static const String adminPlayersLabel = "TOTAL PLAYERS REGISTERED";
  static const String adminPlayersSub = "Active tournament participants";
  static const String adminPrizesLabel = "COMBINED CASH PRIZES";
  static const String adminPrizesSub = "Active combined prize pools";
  static const String adminFillLabel = "AVERAGE MATCH FILL RATE";
  static const String adminFillSub = "Average slot utilization metrics";
  static const String adminChart1Title = "REGISTRATION GROWTH DEMAND";
  static const String adminChart1Sub = "cumulative registered slots past 7 days";
  static const String adminChart2Title = "ROOM SLOTS OCCUPANCY RATES";
  static const String adminChart2Sub = "filled vs. empty capacity slot indicators";
  static const String adminFilledLabel = "FILLED";
  static const String adminVacantLabel = "VACANT";
  static const String adminPublishHeader = "Publish Custom Tournament Match";
  static const String adminMatchTitle = "TOURNAMENT MATCH TITLE";
  static const String adminEntryCost = "ENTRY COST (\$)";
  static const String adminPrizePool = "PRIZE MONEY POOL (\$)";
  static const String adminMaxSlots = "MAX SLOTS CAPACITY";
  static const String adminMapLabel = "BATTLE ARENA MAP";
  static const String adminFormatLabel = "MATCH FORMAT TYPE";
  static const String adminPublishButton = "PUBLISH LIVE TOURNAMENT LOBBY";
  static const String adminPendingDeposits = "PENDING UPI MANUAL DEPOSITS";
  static const String adminNoPending = "No pending deposit claims requiring authentication.";
  static const String adminRejectButton = "REJECT";
  static const String adminApproveButton = "APPROVE";
  static const String adminGrowthBadge = "GROW";
  static const String adminMatchPlaceholder = "e.g. ULTIMATE RUSH CUP";
  static const String adminDepositPrefix = "DEPOSIT REQUEST: \$";
  static const String adminTxnId = "TXN REF ID:";
  static const String adminStatus = "STATUS:";
  static const String adminVerificationReq = "VERIFICATION REQUIRED";

  // Dialogs / Overlays
  static const String modalDetailsBadge = "LOBBY DETAILS";
  static const String modalMap = "MAP ARENA";
  static const String modalFormat = "TEAM FORMAT";
  static const String modalEntryFee = "ENTRY FEE";
  static const String modalSlots = "SLOTS ASSIGNED";
  static const String modalCredentials = "SECURED CUSTOM ROOM CREDENTIALS";
  static const String modalRoomId = "ROOM ID";
  static const String modalPassword = "PASSWORD";
  static const String modalCopy = "Copy Credentials";
  static const String modalCopied = "Copied Keys successfully!";
  static const String modalRegister = "Register Slot";
  static const String modalStartTime = "* Matches schedule starts strictly at ";
  static const String modalProfileBadge = "PLAYER PROFILE DOSSIER";
  static const String modalTier = "TIER: ";
  static const String modalWeapon = "FAV WEAPON: ";
  static const String modalPlayed = "MATCHES PLAYED";
  static const String modalWon = "MATCHES WON";
  static const String modalBattleNotes = "Battle Status Notes:";
  static const String modalBattleDesc = "Officially verified esports participant with competitive combat logs. Recommended partner for Squad Arena matches.";

  // Announcements & Callouts
  static const String calloutTelegramTitle = "Join our Telegram for Live Updates!";
  static const String calloutTelegramBadge = "Join to get promo code and redeem code";
  static const String calloutTelegramDesc = "Claim daily room schedules, get direct coupon updates, custom game room credentials, and priority dispute support directly.";
  static const String calloutTelegramButton = "JOIN TELEGRAM NOW";

  // Error & Success & Notifications
  static const String notifyAlreadyRegistered = "You are already registered for this tournament!";
  static const String notifyInsufficientBalance = "Insufficient Balance in Main Wallet! Please deposit cash.";
  static const String notifyEnterUpiRef = "Please enter UPI Transaction ID to claim deposit.";
  static const String notifyDepositSubmitted = "Deposit request submitted! Admin will verify UPI ID within 5-10 minutes.";
  static const String notifyInsufficientFundsWithdraw = "Insufficient funds in Main Wallet!";
  static const String notifyEnterUpiWithdraw = "Please enter a valid UPI address.";
  static const String notifyWithdrawSubmitted = "Withdrawal submitted! Funds locked. Admin will transfer directly.";
  static const String notifyInvalidPromo = "Invalid code or voucher code expired.";
  static const String notifyPromoAlreadyRedeemed = "You have already redeemed this promo code!";
  static const String notifyPromoRedeemedSuccess = "Promo code successfully redeemed!";
  static const String notifyTournamentCreated = "New Tournament created successfully!";
  static const String notifyTxnApproved = "Transaction APPROVED & wallet updated!";
  static const String notifyTxnRejected = "Transaction rejected.";
}
