import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_fonts/google_fonts.dart';
import 'firebase_options.dart';
import 'services/firebase_service.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    print("Firebase initialization failed: $e");
  }
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FirebaseService()),
      ],
      child: const AstsTournamentApp(),
    ),
  );
}

class AstsTournamentApp extends StatelessWidget {
  const AstsTournamentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ast\'s Tournament',
      debugShowCheckedModeBanner: false,
      
      // High-Fidelity Esports Dark Theme Configuration
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        primaryColor: const Color(0xFFFACC15), // Gold #FACC15
        scaffoldBackgroundColor: const Color(0xFF0F172A), // Dark navy #0F172A
        
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFACC15), // Gold
          secondary: Color(0xFF3B82F6), // Electric Blue
          surface: Color(0xFF1E293B), // slate-800
          onPrimary: Colors.black,
          onSecondary: Colors.white,
        ),
        
        // Customized Typography using Google Fonts Poppins
        textTheme: GoogleFonts.poppinsTextTheme(
          const TextTheme(
            displayLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white),
            titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
            bodyLarge: TextStyle(fontSize: 16, color: Colors.white),
            bodyMedium: TextStyle(fontSize: 14, color: Colors.white70),
          ),
        ),
        
        // Custom Styled Buttons
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFACC15), // Gold
            foregroundColor: Colors.black,
            textStyle: GoogleFonts.poppins(fontWeight: FontWeight.bold),
            elevation: 2,
          ),
        ),
        
        // Visual custom slider / progress colors
        progressIndicatorTheme: const ProgressIndicatorThemeData(
          color: Color(0xFFFACC15), // Gold
          refreshIndicatorColor: Color(0xFFFACC15),
        ),
      ),
      
      home: const SplashScreen(),
    );
  }
}
