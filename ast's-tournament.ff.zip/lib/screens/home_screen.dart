import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/firebase_service.dart';
import 'tabs/home_tab.dart';
import 'tabs/tournaments_tab.dart';
import 'tabs/matches_tab.dart';
import 'tabs/wallet_tab.dart';
import 'tabs/earn_tab.dart';
import 'tabs/profile_tab.dart';
import 'notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  Widget _buildNavItem(int index, IconData outlineIcon, IconData filledIcon, String label) {
    final isSelected = _currentIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          _currentIndex = index;
        });
      },
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: isSelected ? const Color(0xFFFACC15).withOpacity(0.12) : Colors.transparent,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? const Color(0xFFFACC15).withOpacity(0.2) : Colors.transparent,
              ),
            ),
            child: Icon(
              isSelected ? filledIcon : outlineIcon,
              color: isSelected ? const Color(0xFFFACC15) : Colors.grey[500],
              size: 20,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: GoogleFonts.poppins(
              color: isSelected ? const Color(0xFFFACC15) : Colors.grey[500],
              fontWeight: isSelected ? FontWeight.w900 : FontWeight.w500,
              fontSize: 8,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final fbService = Provider.of<FirebaseService>(context);
    final profile = fbService.currentUserProfile;

    if (profile != null && profile.isBanned) {
      return Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.gavel_rounded, color: Colors.redAccent, size: 80),
                const SizedBox(height: 24),
                Text(
                  'ACCESS RESTRICTED',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Your gamer account "${profile.name}" has been permanently suspended by the administrators for violating fair-play rules.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 13, height: 1.6),
                ),
                const SizedBox(height: 32),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B).withOpacity(0.45),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
                  ),
                  child: Text(
                    'Reason: Suspected emulator use or team collusion detected.',
                    style: GoogleFonts.poppins(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 48),
                Container(
                  height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1E293B),
                      foregroundColor: Colors.white,
                      shadowColor: Colors.transparent,
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      fbService.logout();
                    },
                    icon: const Icon(Icons.logout, size: 16),
                    label: Text('Logout Session', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Dynamic Title mapping
    final titles = [
      'AST ARENA',
      'ESPORTS MATCHES',
      'REGISTERED ROOMS',
      'GAMER WALLET',
      'EARN ZONE',
      'PLAYER PROFILE'
    ];

    final List<Widget> tabs = [
      HomeTab(onTabChange: (index) {
        setState(() {
          _currentIndex = index;
        });
      }),
      const TournamentsTab(),
      const MatchesTab(),
      const WalletTab(),
      const EarnTab(),
      const ProfileTab(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), // Premium Dark Navy background
      extendBody: true, // Allows our floating bottom navigation to hover seamlessly
      appBar: AppBar(
        title: Text(
          titles[_currentIndex],
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontSize: 16,
            letterSpacing: 1.2,
          ),
        ),
        backgroundColor: const Color(0xFF0F172A),
        elevation: 0,
        actions: [
          // Push Notifications Bell Icon
          Stack(
            alignment: Alignment.topRight,
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_none, color: Colors.white, size: 22),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const NotificationsScreen()),
                  );
                },
              ),
              if (fbService.notifications.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.redAccent,
                      shape: BoxShape.circle,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 14,
                      minHeight: 14,
                    ),
                    child: Text(
                      '${fbService.notifications.length}',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        bottom: false, // Don't clip bottom area behind floating bar
        child: Column(
          children: [
            if (!fbService.isOnline)
              Container(
                color: Colors.redAccent.withOpacity(0.95),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.cloud_off, color: Colors.white, size: 16),
                        const SizedBox(width: 10),
                        Text(
                          'Offline Mode (using cached data)',
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.redAccent,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        minimumSize: Size.zero,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                      onPressed: () async {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Checking network availability...', style: GoogleFonts.poppins()),
                            duration: const Duration(seconds: 1),
                          ),
                        );
                        await fbService.checkConnectivity();
                      },
                      child: Text(
                        'RETRY',
                        style: GoogleFonts.poppins(fontSize: 9, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            Expanded(child: tabs[_currentIndex]),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        height: 68,
        decoration: BoxDecoration(
          color: const Color(0xFF1E293B).withOpacity(0.85),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 25,
              offset: const Offset(0, 12),
            )
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildNavItem(0, Icons.home_outlined, Icons.home, 'HOME'),
                  _buildNavItem(1, Icons.sports_esports_outlined, Icons.sports_esports, 'LOBBY'),
                  _buildNavItem(2, Icons.leaderboard_outlined, Icons.leaderboard, 'REGISTERED'),
                  _buildNavItem(3, Icons.account_balance_wallet_outlined, Icons.account_balance_wallet, 'WALLET'),
                  _buildNavItem(5, Icons.person_outline, Icons.person, 'PROFILE'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
