import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/firebase_service.dart';
import '../../models/offer_app.dart';

class EarnTab extends StatefulWidget {
  const EarnTab({super.key});

  @override
  State<EarnTab> createState() => _EarnTabState();
}

class _EarnTabState extends State<EarnTab> {
  bool _isChecking = false;

  void _handleClaimReward(BuildContext context, FirebaseService fb, OfferApp app) async {
    setState(() => _isChecking = true);
    
    // এখানে আমরা সিমুলেট করছি যে অ্যাপটি ইন্সটল হয়েছে। 
    // পিসিতে যখন গিটহাব বা এন্ড্রয়েড স্টুডিওতে যাবেন, তখন এখানে device_apps প্যাকেজ দিয়ে রিয়েল চেক বসবে।
    final error = await fb.completeAppDownloadOffer(app.id);
    
    setState(() => _isChecking = false);

    if (error == null) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Icon(Icons.check_circle, color: Colors.green, size: 48),
          content: Text(
            'Task Verified!  ${app.rewardAmount.toStringAsFixed(0)} successfully added to your Main Wallet cash!',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(color: Colors.white),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Awesome', style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontWeight: FontWeight.bold)),
            )
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final fbService = Provider.of<FirebaseService>(context);
    final offerList = fbService.offers;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        title: Text(
          'SPONSOR OFFERS & TASKS',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontSize: 14,
            letterSpacing: 1.2,
          ),
        ),
        backgroundColor: const Color(0xFF0F172A),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: offerList.length,
        itemBuilder: (context, index) {
          final app = offerList[index];
          return Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B).withOpacity(0.45),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.network(app.logoUrl, width: 50, height: 50, fit: BoxFit.cover),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(app.appName, style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                      const SizedBox(height: 2),
                      Text('Task: Install & Open app', style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 11)),
                      const SizedBox(height: 6),
                      Text('+  ${app.rewardAmount.toStringAsFixed(0)} Cash', style: GoogleFonts.poppins(color: const Color(0xFF10B981), fontWeight: FontWeight.w900, fontSize: 13)),
                    ],
                  ),
                ),
                Column(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFACC15),
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      ),
                      onPressed: () {
                        // ইউজারকে প্লে স্টোর বা ডাউনলোড লিঙ্কে নিয়ে যাবে
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Redirecting to download ${app.appName}...')),
                        );
                      },
                      child: Text('DOWNLOAD', style: GoogleFonts.poppins(fontSize: 10, fontWeight: FontWeight.w900)),
                    ),
                    const SizedBox(height: 6),
                    TextButton(
                      onPressed: _isChecking ? null : () => _handleClaimReward(context, fbService, app),
                      child: Text('Verify Task', style: GoogleFonts.poppins(color: Colors.blueAccent, fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ],
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
