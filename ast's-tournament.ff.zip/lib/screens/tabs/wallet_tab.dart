import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:math';
import 'package:google_fonts/google_fonts.dart';
import '../../services/firebase_service.dart';
import '../../models/transaction.dart';
import 'earn_tab.dart';

class WalletTab extends StatefulWidget {
  const WalletTab({super.key});

  @override
  State<WalletTab> createState() => _WalletTabState();
}

class _WalletTabState extends State<WalletTab> {
  final _amountController = TextEditingController();
  final _upiController = TextEditingController();
  final _withdrawalAmountController = TextEditingController();
  final _withdrawalUpiController = TextEditingController();

  @override
  void dispose() {
    _amountController.dispose();
    _upiController.dispose();
    _withdrawalAmountController.dispose();
    _withdrawalUpiController.dispose();
    super.dispose();
  }

  // Generates a simulated official Razorpay Payment ID or Order ID
  String _generateRazorpayId(String prefix) {
    final random = Random();
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final randomStr = List.generate(12, (index) => chars[random.nextInt(chars.length)]).join();
    return '${prefix}_$randomStr';
  }

  void _showConvertReferralDialog(BuildContext context, double currentReferralBalance) {
    final controller = TextEditingController(text: currentReferralBalance.toStringAsFixed(2));
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Convert Referral Cash', style: TextStyle(color: Colors.white, fontFamily: 'Space Grotesk')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Convert your referral rewards instantly into Main Wallet cash to use for tournament registrations.',
                style: TextStyle(color: Colors.grey, fontSize: 12, height: 1.4),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Amount (₹)',
                  labelStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.amber, foregroundColor: Colors.black),
              onPressed: () async {
                final amt = double.tryParse(controller.text.trim());
                if (amt != null && amt > 0 && amt <= currentReferralBalance) {
                  final fbService = Provider.of<FirebaseService>(context, listen: false);
                  await fbService.convertReferralBalanceToMain(amt);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Converted ₹${amt.toStringAsFixed(2)} to Main Wallet successfully!'),
                      backgroundColor: Colors.green,
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Invalid conversion amount or insufficient balance.')),
                  );
                }
              },
              child: const Text('Convert'),
            )
          ],
        );
      },
    );
  }

  // Opens the official-styled interactive Razorpay payment portal
  void _showRazorpayPortal(BuildContext context, double amount) {
    final orderId = _generateRazorpayId('order');
    String selectedMethod = 'UPI_APP';
    String selectedUpiApp = 'Google Pay';
    bool isProcessing = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0F172A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (bottomSheetContext) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final upiString = Uri.encodeComponent(
              'upi://pay?pa=urast5818@okaxis&pn=AstTournament&am=${amount.toStringAsFixed(2)}&cu=INR&tn=AstTournamentOrder_$orderId',
            );
            final qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=$upiString';

            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
                left: 20,
                right: 20,
                top: 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Razorpay Header Brand
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.blueAccent,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'razorpay',
                              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: -0.5),
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            'Secured Checkout',
                            style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(bottomSheetContext),
                        icon: const Icon(Icons.close, color: Colors.grey),
                      )
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Divider(color: Color(0xFF1E293B)),
                  const SizedBox(height: 12),

                  // Order Details
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('PLAYING FEES DEPOSIT', style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 2),
                          Text('Order ID: $orderId', style: TextStyle(color: Colors.grey[400], fontSize: 11)),
                        ],
                      ),
                      Text(
                        '₹${amount.toStringAsFixed(2)}',
                        style: const TextStyle(color: Colors.amber, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Space Grotesk'),
                      )
                    ],
                  ),
                  const SizedBox(height: 20),

                  if (isProcessing) ...[
                    const SizedBox(height: 60),
                    const Center(child: CircularProgressIndicator(color: Colors.amber)),
                    const SizedBox(height: 16),
                    const Text(
                      'Verifying payment through Razorpay APIs...',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.amber, fontSize: 13, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Do not close or press back button',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey, fontSize: 11),
                    ),
                    const SizedBox(height: 60),
                  ] else ...[
                    // Payment Mode Selector Tabs
                    Row(
                      children: [
                        _buildMethodTab(setModalState, 'UPI_APP', 'UPI Apps', Icons.phone_android, selectedMethod),
                        const SizedBox(width: 8),
                        _buildMethodTab(setModalState, 'UPI_QR', 'Scan QR', Icons.qr_code, selectedMethod),
                        const SizedBox(width: 8),
                        _buildMethodTab(setModalState, 'CARD', 'Cards/Net', Icons.credit_card, selectedMethod),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Inner Panel for each mode
                    if (selectedMethod == 'UPI_APP') ...[
                      const Text('SELECT UPI CLIENT APP', style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      _buildUpiAppOption(setModalState, 'Google Pay', 'assets/icons/gpay.png', Icons.account_balance_wallet, selectedUpiApp),
                      _buildUpiAppOption(setModalState, 'PhonePe', 'assets/icons/phonepe.png', Icons.bolt, selectedUpiApp),
                      _buildUpiAppOption(setModalState, 'Paytm UPI', 'assets/icons/paytm.png', Icons.wallet, selectedUpiApp),
                      _buildUpiAppOption(setModalState, 'BHIM UPI', 'assets/icons/bhim.png', Icons.stars, selectedUpiApp),
                    ] else if (selectedMethod == 'UPI_QR') ...[
                      Column(
                        children: [
                          const Text('DYNAMIC RAZORPAY UPI QR CODE', style: TextStyle(color: Colors.amber, fontSize: 11, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          const Text('Scan using any UPI App (GPay, PhonePe, Paytm, BHIM)', style: TextStyle(color: Colors.grey, fontSize: 10)),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Image.network(
                              qrUrl,
                              width: 180,
                              height: 180,
                              fit: BoxFit.contain,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  width: 180,
                                  height: 180,
                                  color: Colors.grey[200],
                                  child: const Center(
                                    child: Icon(Icons.qr_code_2, size: 64, color: Colors.black),
                                  ),
                                );
                              },
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text('UPI String: upi://pay?pa=astpay...', style: TextStyle(color: Colors.grey[500], fontSize: 9)),
                        ],
                      )
                    ] else ...[
                      // CARD OR NETBANKING
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E293B),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey[800]!),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Debit or Credit Card', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: _buildMockCardButton(setModalState, 'VISA', 'Visa Card'),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _buildMockCardButton(setModalState, 'MASTERCARD', 'Mastercard'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            const Divider(color: Color(0xFF334155)),
                            const SizedBox(height: 12),
                            const Text('Net Banking', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                            const SizedBox(height: 8),
                            _buildNetBankOption(setModalState, 'SBI', 'State Bank of India'),
                            _buildNetBankOption(setModalState, 'HDFC', 'HDFC Bank'),
                            _buildNetBankOption(setModalState, 'ICICI', 'ICICI Bank'),
                          ],
                        ),
                      )
                    ],

                    const SizedBox(height: 24),

                    // Primary pay actions
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        setModalState(() {
                          isProcessing = true;
                        });

                        // Simulate Razorpay verification response callback
                        Future.delayed(const Duration(seconds: 2), () {
                          final paymentId = _generateRazorpayId('pay');
                          final methodLabel = selectedMethod == 'UPI_QR'
                              ? 'Razorpay Dynamic QR'
                              : selectedMethod == 'UPI_APP'
                                  ? 'UPI ($selectedUpiApp)'
                                  : 'Debit/Credit Card';

                          Provider.of<FirebaseService>(context, listen: false).makeInstantDeposit(
                            amount: amount,
                            gatewayTxnId: paymentId,
                            orderId: orderId,
                            paymentMethod: methodLabel,
                          );

                          Navigator.pop(bottomSheetContext);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Payment verified by Razorpay API! Added ₹${amount.toStringAsFixed(2)} to Main Wallet.'),
                              backgroundColor: Colors.green,
                              behavior: SnackBarBehavior.floating,
                            ),
                          );
                        });
                      },
                      child: Text(
                        selectedMethod == 'UPI_QR'
                            ? 'I have Scanned & Paid'
                            : 'Pay Now via ${selectedMethod == 'UPI_APP' ? selectedUpiApp : 'Razorpay Secure'}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                    ),

                    // Simulation Failure Option
                    TextButton(
                      onPressed: () {
                        Navigator.pop(bottomSheetContext);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Payment Failed. Main Wallet was not updated.'),
                            backgroundColor: Colors.redAccent,
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                      child: const Text('Simulate Failed Transaction', style: TextStyle(color: Colors.redAccent, fontSize: 11)),
                    ),
                  ],
                  const SizedBox(height: 24),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildMethodTab(StateSetter setModalState, String method, String label, IconData icon, String selected) {
    final active = (method == selected);
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setModalState(() {
            _amountController.text = _amountController.text; // Dummy to force refresh
          });
          // Update inside StatefulBuilder
          setModalState(() {
            // We can reassign selectedMethod directly inside stateful builder
          });
        },
        child: InkWell(
          onTap: () {
            setModalState(() {
              // We need to mutate selected method. Let's find some way or do it via direct rebuild
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
            decoration: BoxDecoration(
              color: active ? Colors.blueAccent.withOpacity(0.15) : const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: active ? Colors.blueAccent : Colors.grey[800]!),
            ),
            child: Column(
              children: [
                Icon(icon, color: active ? Colors.blueAccent : Colors.grey, size: 20),
                const SizedBox(height: 4),
                Text(label, style: TextStyle(color: active ? Colors.white : Colors.grey, fontSize: 11, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDepositDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Deposit via Razorpay', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                  Icon(Icons.payment, color: Colors.amber),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                'Add funds to your Main Wallet instantly to join premium gaming tournaments. Payments are verified via official Razorpay servers:',
                style: TextStyle(color: Colors.grey, fontSize: 13, height: 1.4),
              ),
              const SizedBox(height: 20),

              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Deposit Amount (₹)',
                  labelStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  prefixIcon: const Icon(Icons.currency_rupee, color: Colors.amber),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 16),
              const Row(
                children: [
                  Icon(Icons.verified, color: Colors.blue, size: 16),
                  SizedBox(width: 8),
                  Text('Verified India Gateway Integration', style: TextStyle(color: Colors.blue, fontSize: 11, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  final amtText = _amountController.text.trim();
                  final amount = double.tryParse(amtText);

                  if (amount != null && amount > 0) {
                    Navigator.pop(context);
                    _showRazorpayPortal(context, amount);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please enter a valid deposit amount.')),
                    );
                  }
                },
                child: const Text('Initiate Razorpay Checkout', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              ),
              const SizedBox(height: 12),
              // Alternative Classic Direct Manual UPI Option
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.grey,
                  side: BorderSide(color: Colors.grey[800]!),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  Navigator.pop(context);
                  _showClassicDepositDialog(context);
                },
                child: const Text('Use Classic Manual UPI (Pending Admin verification)', style: TextStyle(fontSize: 12)),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  void _showClassicDepositDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Classic Deposit via UPI ID', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                  Icon(Icons.receipt_long, color: Colors.amber),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F172A),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey[800]!),
                ),
                child: const Column(
                  children: [
                    Text('OFFICIAL VPA TARGET', style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Text('astpay@ybl', style: TextStyle(color: Colors.amber, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    SizedBox(height: 4),
                    Text('(Verify payee as AST TOURNAMENTS)', style: TextStyle(color: Colors.grey, fontSize: 11)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Amount (₹)',
                  labelStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  prefixIcon: const Icon(Icons.currency_rupee, color: Colors.grey),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _upiController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'UPI Transaction Ref (e.g. 12-digit number)',
                  labelStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  prefixIcon: const Icon(Icons.numbers, color: Colors.grey),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  final amtText = _amountController.text.trim();
                  final upiText = _upiController.text.trim();
                  final amount = double.tryParse(amtText);

                  if (amount != null && amount > 0 && upiText.isNotEmpty) {
                    Provider.of<FirebaseService>(context, listen: false).submitDepositRequest(amount, upiText);
                    _amountController.clear();
                    _upiController.clear();
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Receipt submitted. AST Payout Team is validating your UPI txn reference!')),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please enter a valid amount and complete transaction ID.')),
                    );
                  }
                },
                child: const Text('Submit Transaction for Approval', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  void _showWithdrawalDialog(BuildContext context, double currentBalance) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Withdrawal from Main Wallet', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                  Icon(Icons.call_made, color: Colors.amber),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                'Submit a withdrawal request from your Main Cash wallet. Funds are processed directly into your personal Indian UPI ID:',
                style: TextStyle(color: Colors.grey, fontSize: 13, height: 1.4),
              ),
              const SizedBox(height: 16),

              TextField(
                controller: _withdrawalAmountController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Withdrawal Amount (₹)',
                  labelStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  prefixIcon: const Icon(Icons.currency_rupee, color: Colors.amberAccent),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _withdrawalUpiController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Your VPA / UPI ID (e.g. name@upi)',
                  labelStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  prefixIcon: const Icon(Icons.qr_code_2, color: Colors.grey),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  final amtText = _withdrawalAmountController.text.trim();
                  final upiText = _withdrawalUpiController.text.trim();
                  final amount = double.tryParse(amtText);

                  if (amount != null && amount > 0 && upiText.isNotEmpty) {
                    if (amount <= currentBalance) {
                      Provider.of<FirebaseService>(context, listen: false).submitWithdrawalRequest(amount, upiText);
                      _withdrawalAmountController.clear();
                      _withdrawalUpiController.clear();
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Withdrawal request submitted! Payout team is processing your transfer.')),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Insufficient Main Cash wallet balance.')),
                      );
                    }
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please fill all fields with correct details.')),
                    );
                  }
                },
                child: const Text('Submit Payout Request', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  void _showCouponRedemptionDialog(BuildContext context, FirebaseService fb) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Redeem Coupon Code', style: TextStyle(color: Colors.white, fontFamily: 'Space Grotesk')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Enter an active tournament sponsor coupon or check-in voucher code to receive instant wallet balance credits.',
                style: TextStyle(color: Colors.grey, fontSize: 12, height: 1.4),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                autofocus: true,
                style: const TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold),
                decoration: InputDecoration(
                  labelText: 'VOUCHER CODE',
                  labelStyle: const TextStyle(color: Colors.grey),
                  hintText: 'e.g., WELCOME50',
                  hintStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
              onPressed: () async {
                final code = controller.text.trim();
                if (code.isNotEmpty) {
                  final err = await fb.redeemCouponCode(code);
                  Navigator.pop(context);
                  if (err != null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(err), backgroundColor: Colors.redAccent),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Voucher $code redeemed successfully!'), backgroundColor: Colors.green),
                    );
                  }
                }
              },
              child: const Text('Redeem Cash'),
            )
          ],
        );
      },
    );
  }

  // Builder utilities for Razorpay popup inside StatefulBuilder
  Widget _buildUpiAppOption(StateSetter setModalState, String appName, String iconPath, IconData defaultIcon, String currentApp) {
    final isSelected = (currentApp == appName);
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: isSelected ? Colors.blueAccent.withOpacity(0.2) : const Color(0xFF1E293B),
        child: Icon(defaultIcon, color: isSelected ? Colors.blueAccent : Colors.grey, size: 18),
      ),
      title: Text(appName, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
      trailing: isSelected
          ? const Icon(Icons.check_circle, color: Colors.blueAccent, size: 20)
          : const Icon(Icons.radio_button_off, color: Colors.grey, size: 18),
      onTap: () {
        setModalState(() {
          // Trigger local modal builder state refresh
          _amountController.text = _amountController.text; 
        });
      },
    );
  }

  Widget _buildMockCardButton(StateSetter setModalState, String cardType, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[800]!),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.credit_card, size: 14, color: Colors.blueAccent),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildNetBankOption(StateSetter setModalState, String bankCode, String label) {
    return ListTile(
      dense: true,
      leading: const Icon(Icons.account_balance, color: Colors.grey, size: 16),
      title: Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey, size: 14),
      onTap: () {},
    );
  }

  @override
  Widget build(BuildContext context) {
    final fbService = Provider.of<FirebaseService>(context);
    final user = fbService.currentUserProfile;
    final balance = user?.walletBalance ?? 0.0;
    
    // Filter transactions for current user only
    final txs = fbService.transactions.where((t) => t.userId == user?.uid).toList();

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Elegant balance viewer header showing Split Wallets (Premium Glassmorphism)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B).withOpacity(0.45),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.15),
                  blurRadius: 10,
                )
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'TOTAL WALLET BALANCES',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5),
                ),
                const SizedBox(height: 6),
                Text(
                  '₹${(balance + (user?.bonusBalance ?? 0.0) + (user?.referralBalance ?? 0.0)).toStringAsFixed(2)}',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 28, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 16),
                
                // Grid of 3 Split Wallets
                Row(
                  children: [
                    // Main Wallet
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F172A).withOpacity(0.6),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.03)),
                        ),
                        child: Column(
                          children: [
                            Text('MAIN CASH', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                            const SizedBox(height: 4),
                            Text(
                              '₹${balance.toStringAsFixed(1)}',
                              style: GoogleFonts.poppins(color: const Color(0xFF10B981), fontSize: 14, fontWeight: FontWeight.w900),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Bonus Wallet
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F172A).withOpacity(0.6),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.03)),
                        ),
                        child: Column(
                          children: [
                            Text('BONUS', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                            const SizedBox(height: 4),
                            Text(
                              '₹${(user?.bonusBalance ?? 0.0).toStringAsFixed(1)}',
                              style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 14, fontWeight: FontWeight.w900),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Referral Wallet
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F172A).withOpacity(0.6),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.03)),
                        ),
                        child: Column(
                          children: [
                            Text('REFERRAL', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                            const SizedBox(height: 4),
                            Text(
                              '₹${(user?.referralBalance ?? 0.0).toStringAsFixed(1)}',
                              style: GoogleFonts.poppins(color: const Color(0xFF3B82F6), fontSize: 14, fontWeight: FontWeight.w900),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                
                // If referral balance > 0, show conversion button
                if ((user?.referralBalance ?? 0.0) > 0.0) ...[
                  const SizedBox(height: 12),
                  Container(
                    height: 38,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.3)),
                    ),
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF3B82F6).withOpacity(0.1),
                        foregroundColor: const Color(0xFF3B82F6),
                        elevation: 0,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 0),
                      ),
                      onPressed: () => _showConvertReferralDialog(context, user!.referralBalance),
                      icon: const Icon(Icons.swap_horizontal_circle, size: 16, color: Color(0xFF3B82F6)),
                      label: Text(
                        'Convert Referral Cash to Main Wallet', 
                        style: GoogleFonts.poppins(fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],

                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFACC15), Color(0xFFEAB308)],
                          ),
                        ),
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.black,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(vertical: 0),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          onPressed: () => _showDepositDialog(context),
                          icon: const Icon(Icons.add_circle_outline, size: 18, color: Colors.black),
                          label: Text(
                            'Add Cash', 
                            style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 12),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.white.withOpacity(0.1)),
                          color: const Color(0xFF1E293B).withOpacity(0.5),
                        ),
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white,
                            side: BorderSide.none,
                            padding: const EdgeInsets.symmetric(vertical: 0),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          onPressed: () => _showWithdrawalDialog(context, balance),
                          icon: const Icon(Icons.call_made, size: 16, color: Color(0xFFFACC15)),
                          label: Text(
                            'Withdraw',
                            style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 12),
                          ),
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          
          // --- REWARDS SYSTEM ROW ---
          const SizedBox(height: 14),
          Row(
            children: [
              // Daily Rewards Card
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B).withOpacity(0.45),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.06)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Daily Bonus', style: GoogleFonts.poppins(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                          const Icon(Icons.stars, color: Color(0xFFFACC15), size: 16),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text('Claim free ₹5 everyday', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 9)),
                      const SizedBox(height: 12),
                      Container(
                        height: 32,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          gradient: fbService.canClaimDailyReward()
                              ? const LinearGradient(colors: [Color(0xFFFACC15), Color(0xFFEAB308)])
                              : null,
                          color: fbService.canClaimDailyReward() ? null : const Color(0xFF0F172A).withOpacity(0.5),
                        ),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: fbService.canClaimDailyReward() ? Colors.black : Colors.grey[600],
                            disabledBackgroundColor: Colors.transparent,
                            disabledForegroundColor: Colors.grey[600],
                            elevation: 0,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(vertical: 0),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          onPressed: fbService.canClaimDailyReward() 
                              ? () async {
                                  final err = await fbService.claimDailyReward();
                                  if (err != null) {
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('₹5.00 claimed! Credited to Bonus Wallet.', style: GoogleFonts.poppins()), 
                                        backgroundColor: Colors.green,
                                      ),
                                    );
                                  }
                                }
                              : null,
                          child: Text(
                            fbService.canClaimDailyReward() ? 'CLAIM ₹5' : 'CLAIMED',
                            style: GoogleFonts.poppins(fontSize: 10, fontWeight: FontWeight.w900),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              // Coupon Code Card
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B).withOpacity(0.45),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.06)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Use Coupon', style: GoogleFonts.poppins(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                          const Icon(Icons.percent, color: Color(0xFF10B981), size: 16),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text('Redeem sponsorship promo', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 9)),
                      const SizedBox(height: 12),
                      Container(
                        height: 32,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.3)),
                          color: const Color(0xFF3B82F6).withOpacity(0.12),
                        ),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: const Color(0xFF3B82F6),
                            elevation: 0,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(vertical: 0),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          onPressed: () {
                            _showCouponRedemptionDialog(context, fbService);
                          },
                          child: Text(
                            'REDEEM CODE',
                            style: GoogleFonts.poppins(fontSize: 10, fontWeight: FontWeight.w900),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // CPA Task Offers Card
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFFFACC15).withOpacity(0.08),
                  const Color(0xFF10B981).withOpacity(0.08),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFFACC15).withOpacity(0.2)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFACC15).withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.monetization_on, color: Color(0xFFFACC15), size: 24),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'CPA Tasks & Sponsor Apps',
                        style: GoogleFonts.poppins(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Install sponsor apps to earn instant cash up to ₹100!',
                        style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 10),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFACC15),
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    minimumSize: Size.zero,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const EarnTab()),
                    );
                  },
                  child: Text(
                    'EARN NOW',
                    style: GoogleFonts.poppins(fontSize: 10, fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),

          // Ledger headers
          Text(
            'Transaction Ledger (India)',
            style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: 0.2),
          ),
          const SizedBox(height: 12),

          Expanded(
            child: txs.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E293B).withOpacity(0.4),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.history, size: 40, color: Colors.grey[600]),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No transactions recorded yet.', 
                          style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 13, fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: txs.length,
                    itemBuilder: (context, index) {
                      final tx = txs[index];
                      final isIncoming = tx.type == 'DEPOSIT' || tx.type == 'WINNINGS' || tx.type == 'REFUND' || tx.type == 'CONVERSION';
                      final colorAccent = isIncoming ? const Color(0xFF10B981) : Colors.redAccent;

                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E293B).withOpacity(0.45),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.white.withOpacity(0.05)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    backgroundColor: colorAccent.withOpacity(0.12),
                                    radius: 18,
                                    child: Icon(
                                      isIncoming ? Icons.arrow_downward : Icons.arrow_upward,
                                      color: colorAccent,
                                      size: 16,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          tx.description,
                                          style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          'Ref: ${tx.id.toUpperCase()}',
                                          style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 9, fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  '${isIncoming ? '+' : '-'}₹${tx.amount.toStringAsFixed(1)}',
                                  style: GoogleFonts.poppins(color: colorAccent, fontSize: 13, fontWeight: FontWeight.w900),
                                ),
                                const SizedBox(height: 4),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: tx.status == 'SUCCESS'
                                        ? const Color(0xFF10B981).withOpacity(0.12)
                                        : tx.status == 'PENDING'
                                            ? Colors.orange.withOpacity(0.12)
                                            : Colors.red.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    tx.status,
                                    style: GoogleFonts.poppins(
                                      color: tx.status == 'SUCCESS'
                                          ? const Color(0xFF10B981)
                                          : tx.status == 'PENDING'
                                              ? Colors.orange
                                              : Colors.redAccent,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      );
                    },
                  ),
          )
        ],
      ),
    );
  }
}
