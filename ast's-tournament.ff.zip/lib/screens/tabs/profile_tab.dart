import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/firebase_service.dart';
import '../admin_panel_screen.dart';
import '../login_screen.dart';

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final _nameController = TextEditingController();
  final _referralInputController = TextEditingController();
  bool _isDarkMode = true; // Default dark mode is true as per requirement

  @override
  void dispose() {
    _nameController.dispose();
    _referralInputController.dispose();
    super.dispose();
  }

  void _showEditProfileDialog(BuildContext context, String currentName) {
    _nameController.text = currentName;
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text(
            'Edit Gamer Nickname', 
            style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
          ),
          content: TextField(
            controller: _nameController,
            style: GoogleFonts.poppins(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Enter new gamer tag',
              hintStyle: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 13),
              filled: true,
              fillColor: const Color(0xFF0F172A),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: GoogleFonts.poppins(color: Colors.grey[500], fontWeight: FontWeight.bold)),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: const LinearGradient(colors: [Color(0xFFFACC15), Color(0xFFEAB308)]),
              ),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent, 
                  foregroundColor: Colors.black,
                  shadowColor: Colors.transparent,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                ),
                onPressed: () {
                  final text = _nameController.text.trim();
                  if (text.isNotEmpty) {
                    Provider.of<FirebaseService>(context, listen: false).updateProfileName(text);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Gamer handle updated successfully!', style: GoogleFonts.poppins()),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                },
                child: Text('Save', style: GoogleFonts.poppins(fontWeight: FontWeight.w900)),
              ),
            )
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final fbService = Provider.of<FirebaseService>(context);
    final user = fbService.currentUserProfile;

    if (user == null) {
      return Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(const Color(0xFFFACC15)),
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Centered profile avatar placeholder
          Center(
            child: Column(
              children: [
                Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFACC15), Color(0xFF3B82F6)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: CircleAvatar(
                        radius: 46,
                        backgroundColor: const Color(0xFF0F172A),
                        child: Text(
                          user.name.substring(0, 1).toUpperCase(),
                          style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 32, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => _showEditProfileDialog(context, user.name),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xFF3B82F6),
                        ),
                        child: const Icon(Icons.edit, color: Colors.white, size: 14),
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  user.name,
                  style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 0.2),
                ),
                const SizedBox(height: 2),
                Text(
                  user.email.isNotEmpty ? user.email : user.phone,
                  style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 11, fontWeight: FontWeight.w500),
                ),
                if (user.isAdmin) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFACC15).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFFACC15).withOpacity(0.4)),
                    ),
                    child: Text(
                      '🏆 ADMINISTRATOR',
                      style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 0.8),
                    ),
                  )
                ]
              ],
            ),
          ),
          const SizedBox(height: 24),

          // User Stats Row
          Row(
            children: [
              _buildStatCard('Matches', user.joinedCount.toString(), Icons.sports_esports),
              const SizedBox(width: 12),
              _buildStatCard('Conquered', user.wonCount.toString(), Icons.military_tech),
              const SizedBox(width: 12),
              _buildStatCard('Earnings', '₹${user.totalEarnings.toStringAsFixed(0)}', Icons.emoji_events),
            ],
          ),
          const SizedBox(height: 20),

          // Referral Program Widget
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF3B82F6).withOpacity(0.12),
                  const Color(0xFF1E293B).withOpacity(0.45)
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.25), width: 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF3B82F6).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.share, color: Color(0xFF3B82F6), size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'REFERRAL CAMPAIGN',
                            style: GoogleFonts.poppins(
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              color: const Color(0xFF3B82F6),
                              letterSpacing: 1.2,
                            ),
                          ),
                          Text(
                            'Earn ₹5 per active friend!',
                            style: GoogleFonts.poppins(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Share your unique code with friends. When they register for their first paid match, you instantly receive ₹5 into your Referral Wallet!',
                  style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 10, height: 1.4),
                ),
                const SizedBox(height: 16),
                // Unique copyable code box
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F172A).withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white.withOpacity(0.04)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('YOUR REFERRAL CODE', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 8, letterSpacing: 0.5)),
                          const SizedBox(height: 2),
                          Text(
                            user.referralCode,
                            style: GoogleFonts.poppins(
                              color: const Color(0xFFFACC15),
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.1,
                            ),
                          ),
                        ],
                      ),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFACC15).withOpacity(0.12),
                          foregroundColor: const Color(0xFFFACC15),
                          elevation: 0,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                            side: const BorderSide(color: Color(0xFFFACC15), width: 0.8),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                        ),
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: user.referralCode));
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Referral code copied to clipboard!', style: GoogleFonts.poppins()),
                              backgroundColor: const Color(0xFFFACC15),
                              behavior: SnackBarBehavior.floating,
                            ),
                          );
                        },
                        icon: const Icon(Icons.copy, size: 12),
                        label: Text('Copy', style: GoogleFonts.poppins(fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Claim a code from a referrer
                if (user.referredBy.isEmpty) ...[
                  const Divider(color: Color(0xFF334155), height: 1),
                  const SizedBox(height: 16),
                  Text(
                    'REFERRED BY A FRIEND?',
                    style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 9, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 38,
                          child: TextField(
                            controller: _referralInputController,
                            style: GoogleFonts.poppins(color: Colors.white, fontSize: 12),
                            decoration: InputDecoration(
                              hintText: "Enter friend's referral code",
                              hintStyle: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: Colors.white.withOpacity(0.04)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: Colors.white.withOpacity(0.04)),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(color: Color(0xFFFACC15), width: 0.8),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        height: 38,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: const LinearGradient(colors: [Color(0xFFFACC15), Color(0xFFEAB308)]),
                        ),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            foregroundColor: Colors.black,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                          ),
                          onPressed: () async {
                            final code = _referralInputController.text.trim();
                            if (code.isEmpty) return;
                            final err = await fbService.applyReferralCode(code);
                            if (err != null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(err, style: GoogleFonts.poppins()), 
                                  backgroundColor: Colors.redAccent,
                                ),
                              );
                            } else {
                              _referralInputController.clear();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Referral code successfully applied!', style: GoogleFonts.poppins()), 
                                  backgroundColor: Colors.green,
                                ),
                              );
                            }
                          },
                          child: Text('Apply', style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 11)),
                        ),
                      ),
                    ],
                  ),
                ] else ...[
                  const Divider(color: Color(0xFF334155), height: 1),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Icon(Icons.check_circle, color: Color(0xFF10B981), size: 14),
                      const SizedBox(width: 8),
                      Text(
                        'Referral code active! Welcome Bonus Claimed.',
                        style: GoogleFonts.poppins(color: const Color(0xFF10B981), fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),

          Text(
            'Settings & Actions',
            style: GoogleFonts.poppins(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),

          // Action Menu Cards
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B).withOpacity(0.45),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.05)),
            ),
            child: Column(
              children: [
                // Dark Mode Toggle
                ListTile(
                  leading: const Icon(Icons.dark_mode, color: Color(0xFFFACC15), size: 18),
                  title: Text('AMOLED Dark Theme', style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500)),
                  trailing: Switch(
                    value: _isDarkMode,
                    activeColor: const Color(0xFFFACC15),
                    onChanged: (val) {
                      setState(() {
                        _isDarkMode = val;
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            val ? 'Dark mode activated.' : 'Light mode activated (Preview default stays AMOLED).',
                            style: GoogleFonts.poppins(),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Divider(color: Colors.white.withOpacity(0.04), height: 1),

                // Edit Profile Trigger
                ListTile(
                  leading: const Icon(Icons.person, color: Color(0xFFFACC15), size: 18),
                  title: Text('Edit Account Handle', style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500)),
                  trailing: const Icon(Icons.chevron_right, color: Colors.grey, size: 18),
                  onTap: () => _showEditProfileDialog(context, user.name),
                ),
                Divider(color: Colors.white.withOpacity(0.04), height: 1),

                // Admin Panel Access
                if (user.isAdmin) ...[
                  ListTile(
                    leading: const Icon(Icons.admin_panel_settings, color: Color(0xFFFACC15), size: 18),
                    title: Text(
                      'Admin Panel Settings', 
                      style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Manage games, payments, & results', 
                      style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 10),
                    ),
                    trailing: const Icon(Icons.chevron_right, color: Color(0xFFFACC15), size: 18),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const AdminPanelScreen()),
                      );
                    },
                  ),
                  Divider(color: Colors.white.withOpacity(0.04), height: 1),
                ],

                // Support / Legal terms
                ListTile(
                  leading: const Icon(Icons.help_center, color: Color(0xFFFACC15), size: 18),
                  title: Text('Customer Care Helpline', style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500)),
                  trailing: const Icon(Icons.chevron_right, color: Colors.grey, size: 18),
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        backgroundColor: const Color(0xFF1E293B),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        title: Text('UPI Support Care', style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                        content: Text(
                          'For any payment deposit delay, please write to us at support@asttournament.com with your transaction reference ID.',
                          style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12, height: 1.4),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('Close', style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontWeight: FontWeight.bold)),
                          )
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Logout Button
          Container(
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.redAccent.withOpacity(0.35)),
            ),
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent.withOpacity(0.08),
                foregroundColor: Colors.redAccent,
                elevation: 0,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {
                fbService.logout();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                  (route) => false,
                );
              },
              icon: const Icon(Icons.logout, size: 16),
              label: Text('Logout Session', style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 12)),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, String count, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF1E293B).withOpacity(0.45),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFF3B82F6), size: 20),
            const SizedBox(height: 6),
            Text(
              count,
              style: GoogleFonts.poppins(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 1),
            Text(
              label,
              style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 10, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
