import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/firebase_service.dart';
import '../../models/tournament.dart';

class MatchesTab extends StatelessWidget {
  const MatchesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final firebaseService = Provider.of<FirebaseService>(context);
    final user = firebaseService.currentUserProfile;
    final allTournaments = firebaseService.tournaments;

    if (user == null) {
      return Center(
        child: Text(
          'Please login to view matches.', 
          style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      );
    }

    // Filter tournaments where the user is a participant
    final userTournaments = allTournaments.where((t) => t.participants.contains(user.uid)).toList();

    final activeMatches = userTournaments.where((t) => t.status != 'completed').toList();
    final completedMatches = userTournaments.where((t) => t.status == 'completed').toList();

    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          TabBar(
            tabs: const [
              Tab(text: 'Active / Upcoming'),
              Tab(text: 'Completed Results'),
            ],
            labelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 0.5),
            unselectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 13),
            labelColor: const Color(0xFFFACC15),
            unselectedLabelColor: Colors.grey[500],
            indicatorColor: const Color(0xFFFACC15),
            indicatorWeight: 3,
            indicatorSize: TabBarIndicatorSize.tab,
          ),
          Expanded(
            child: TabBarView(
              children: [
                _buildActiveTab(context, activeMatches),
                _buildCompletedTab(context, completedMatches),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildActiveTab(BuildContext context, List<Tournament> matches) {
    if (matches.isEmpty) {
      return _buildEmptyState('No registered matches.', 'Explore the Tournaments tab to join your first match!');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: matches.length,
      itemBuilder: (context, index) {
        final match = matches[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            color: const Color(0xFF1E293B).withOpacity(0.45),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(0.06)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 10,
              )
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFACC15).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        match.gameName.toUpperCase(),
                        style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                      ),
                    ),
                    Text(
                      match.dateTime,
                      style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 11, fontWeight: FontWeight.w500),
                    )
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  match.title,
                  style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15),
                ),
                const SizedBox(height: 6),
                Text(
                  'Map: ${match.map.toUpperCase()}  |  Mode: ${match.gameMode.toUpperCase()}',
                  style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.3),
                ),
                Divider(height: 24, color: Colors.white.withOpacity(0.06)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('YOUR STATUS', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: Color(0xFF10B981),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'Registered',
                              style: GoogleFonts.poppins(color: const Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                          ],
                        )
                      ],
                    ),
                    Container(
                      height: 34,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)],
                        ),
                      ),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          foregroundColor: Colors.white,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                        ),
                        onPressed: () => _showLobbyDetails(context, match),
                        child: Text(
                          'ROOM DETAILS', 
                          style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: 0.5),
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCompletedTab(BuildContext context, List<Tournament> matches) {
    if (matches.isEmpty) {
      return _buildEmptyState('No completed matches yet.', 'Finished matches showing final leaderboards and payout listings will appear here.');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: matches.length,
      itemBuilder: (context, index) {
        final match = matches[index];
        final wonPrize = match.winnerName == 'AlphaGamer'; // Demo winner check

        return Container(
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            color: const Color(0xFF1E293B).withOpacity(0.45),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(0.06)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 10,
              )
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        match.gameName.toUpperCase(),
                        style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                      ),
                    ),
                    Row(
                      children: [
                        const Icon(Icons.check_circle_outline, color: Color(0xFF10B981), size: 14),
                        const SizedBox(width: 4),
                        Text(
                          'COMPLETED',
                          style: GoogleFonts.poppins(color: const Color(0xFF10B981), fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 0.5),
                        ),
                      ],
                    )
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  match.title,
                  style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15),
                ),
                const SizedBox(height: 6),
                Text(
                  'Map: ${match.map.toUpperCase()}  |  Prize Pool: ₹${match.prizePool.toStringAsFixed(0)}',
                  style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.3),
                ),
                Divider(height: 24, color: Colors.white.withOpacity(0.06)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('OFFICIAL WINNER', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                        const SizedBox(height: 4),
                        Text(
                          match.winnerName ?? 'Disclosed soon',
                          style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontWeight: FontWeight.w900, fontSize: 13),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: wonPrize ? const Color(0xFF10B981).withOpacity(0.12) : Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        wonPrize ? 'Winnings: +₹${(match.prizePool * 0.1).toStringAsFixed(0)}' : 'No Payout',
                        style: GoogleFonts.poppins(
                          color: wonPrize ? const Color(0xFF10B981) : Colors.redAccent,
                          fontWeight: FontWeight.bold,
                          fontSize: 11,
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState(String title, String subtitle) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B).withOpacity(0.4),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withOpacity(0.05)),
              ),
              child: const Icon(Icons.emoji_events, size: 48, color: Color(0xFFFACC15)),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              style: GoogleFonts.poppins(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showLobbyDetails(BuildContext context, Tournament match) {
    final firebaseService = Provider.of<FirebaseService>(context, listen: false);
    final user = firebaseService.currentUserProfile;
    final isApproved = user != null && match.approvedPlayers.contains(user.uid);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: [
              const Icon(Icons.vpn_key, color: Color(0xFFFACC15)),
              const SizedBox(width: 10),
              Text(
                'Lobby Credentials',
                style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
              )
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (isApproved) ...[
                Text(
                  'Room credentials will be used to join custom private games inside the official game client:',
                  style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12, height: 1.4),
                ),
                const SizedBox(height: 16),
                _buildCredentialRow('ROOM ID', match.roomId),
                const SizedBox(height: 12),
                _buildCredentialRow('PASSWORD', match.roomPassword),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFACC15).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFFFACC15).withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info, color: Color(0xFFFACC15), size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Copy the ID & Password and enter the game room 15 minutes before schedule.',
                          style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 10, fontWeight: FontWeight.w600),
                        ),
                      )
                    ],
                  ),
                ),
              ] else ...[
                const Center(
                  child: Icon(Icons.lock_clock, color: Colors.orange, size: 48),
                ),
                const SizedBox(height: 12),
                Text(
                  'LOBBY LOCKED',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 0.5),
                ),
                const SizedBox(height: 8),
                Text(
                  'Your registration is currently under review. Your private room credentials will unlock as soon as the tournament admin approves your entry.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12, height: 1.5),
                ),
              ]
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Dismiss', 
                style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontWeight: FontWeight.bold),
              ),
            )
          ],
        );
      },
    );
  }

  Widget _buildCredentialRow(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withOpacity(0.04)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
          Text(value, style: GoogleFonts.poppins(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        ],
      ),
    );
  }
}
