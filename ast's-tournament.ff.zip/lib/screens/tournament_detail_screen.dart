import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/firebase_service.dart';
import '../models/tournament.dart';

class TournamentDetailScreen extends StatefulWidget {
  final String tournamentId;

  const TournamentDetailScreen({super.key, required this.tournamentId});

  @override
  State<TournamentDetailScreen> createState() => _TournamentDetailScreenState();
}

class _TournamentDetailScreenState extends State<TournamentDetailScreen> {
  bool _isProcessing = false;

  void _showReportIssueDialog(BuildContext context, Tournament tournament) {
    final reportController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text(
            'Report Match Issue', 
            style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Describe the issue you encountered during this match. Our admins will investigate and resolve it.',
                style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12, height: 1.4),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: reportController,
                maxLines: 4,
                style: GoogleFonts.poppins(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Enter details (e.g. Opponent did not join, hack use with video proof link, etc.)...',
                  hintStyle: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 12),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14), 
                    borderSide: BorderSide(color: Colors.white.withOpacity(0.05)),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: GoogleFonts.poppins(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
              onPressed: () {
                final text = reportController.text.trim();
                if (text.isNotEmpty) {
                  Provider.of<FirebaseService>(context, listen: false).reportMatchIssue(tournament.id, text);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Issue reported successfully. Admins have been notified.', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                    ),
                  );
                }
              },
              child: Text('Submit Report', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _handleRegister(Tournament tournament) async {
    setState(() {
      _isProcessing = true;
    });

    final fbService = Provider.of<FirebaseService>(context, listen: false);
    final error = await fbService.joinTournament(tournament.id);

    if (!mounted) return;
    setState(() {
      _isProcessing = false;
    });

    if (error != null) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            backgroundColor: const Color(0xFF1E293B),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Text('Registration Failed', style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold)),
            content: Text(error, style: GoogleFonts.poppins(color: Colors.grey[400])),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Dismiss', style: GoogleFonts.poppins(color: const Color(0xFFFACC15))),
              )
            ],
          );
        },
      );
    } else {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            backgroundColor: const Color(0xFF1E293B),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Text('Registration Success!', style: GoogleFonts.poppins(color: Colors.green, fontWeight: FontWeight.bold)),
            content: Text(
              'You have successfully joined "${tournament.title}". Room ID & Password credentials will appear in the Notifications page 15 minutes before the match start.',
              style: GoogleFonts.poppins(color: Colors.grey[400]),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context); // Close dialog
                  Navigator.pop(context); // Return to list
                },
                child: Text('Awesome', style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontWeight: FontWeight.bold)),
              )
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final fbService = Provider.of<FirebaseService>(context);
    final user = fbService.currentUserProfile;
    final index = fbService.tournaments.indexWhere((t) => t.id == widget.tournamentId);

    if (index == -1) {
      return Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        appBar: AppBar(backgroundColor: const Color(0xFF1E293B)),
        body: Center(child: Text('Tournament not found', style: GoogleFonts.poppins(color: Colors.white))),
      );
    }

    final tournament = fbService.tournaments[index];
    final isAlreadyJoined = user != null && tournament.participants.contains(user.uid);
    final isFull = tournament.joinedCount >= tournament.totalSlots;
    final isCompleted = tournament.status == 'completed';

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        title: Text(
          'MATCH DETAILS', 
          style: GoogleFonts.poppins(fontWeight: FontWeight.w900, color: Colors.white, fontSize: 16, letterSpacing: 1.5),
        ),
        backgroundColor: const Color(0xFF0F172A),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F172A), Color(0xFF1E1B4B)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Title & Meta card (Premium glassmorphic)
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B).withOpacity(0.45),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white.withOpacity(0.08)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            blurRadius: 15,
                          )
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF3B82F6).withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  tournament.gameName.toUpperCase(),
                                  style: GoogleFonts.poppins(color: const Color(0xFF3B82F6), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: isCompleted 
                                      ? Colors.red.withOpacity(0.12) 
                                      : Colors.green.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  tournament.status.toUpperCase(),
                                  style: GoogleFonts.poppins(
                                    color: isCompleted ? Colors.redAccent : Colors.green, 
                                    fontSize: 9, 
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            tournament.title,
                            style: GoogleFonts.poppins(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 0.3),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              const Icon(Icons.map, size: 16, color: Color(0xFF3B82F6)),
                              const SizedBox(width: 6),
                              Text(
                                'MAP: ${tournament.map.toUpperCase()}', 
                                style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                              ),
                              const SizedBox(width: 20),
                              const Icon(Icons.people, size: 16, color: Color(0xFF3B82F6)),
                              const SizedBox(width: 6),
                              Text(
                                'MODE: ${tournament.gameMode.toUpperCase()}', 
                                style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Prize and Schedule highlights (Sleek rows)
                    Row(
                      children: [
                        Expanded(
                          child: _buildGridHighlight('PRIZE POOL', '₹${tournament.prizePool.toStringAsFixed(0)}', Icons.emoji_events, const Color(0xFFFACC15)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildGridHighlight('ENTRY FEE', tournament.entryFee == 0 ? 'FREE' : '₹${tournament.entryFee.toStringAsFixed(0)}', Icons.payments, const Color(0xFF3B82F6)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildGridHighlight('SCHEDULE TIME', tournament.dateTime, Icons.schedule, const Color(0xFF10B981)),
                    const SizedBox(height: 20),

                    // Prize Distribution Structure Card
                    Text(
                      'PRIZE BREAKUP',
                      style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.5),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B).withOpacity(0.4),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: Colors.white.withOpacity(0.06)),
                      ),
                      child: Column(
                        children: [
                          _buildPrizeRow('1st Position (Winner)', '60% (₹${(tournament.prizePool * 0.6).toStringAsFixed(0)})', const Color(0xFFFACC15)),
                          const Divider(color: Color(0xFF334155), height: 24),
                          _buildPrizeRow('2nd Position', '25% (₹${(tournament.prizePool * 0.25).toStringAsFixed(0)})', Colors.white70),
                          const Divider(color: Color(0xFF334155), height: 24),
                          _buildPrizeRow('3rd Position', '15% (₹${(tournament.prizePool * 0.15).toStringAsFixed(0)})', const Color(0xFFF97316)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    if (isAlreadyJoined) ...[
                      Text(
                        'MATCH ROOM CREDENTIALS',
                        style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.5),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E293B).withOpacity(0.45),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: tournament.approvedPlayers.contains(user?.uid) 
                                ? Colors.green.withOpacity(0.4) 
                                : Colors.orange.withOpacity(0.4),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  tournament.approvedPlayers.contains(user?.uid) 
                                      ? Icons.verified_user_rounded 
                                      : Icons.hourglass_top_rounded,
                                  color: tournament.approvedPlayers.contains(user?.uid) ? Colors.green : Colors.orange,
                                  size: 20,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  tournament.approvedPlayers.contains(user?.uid) 
                                      ? 'REGISTRATION APPROVED' 
                                      : 'PENDING ADMIN APPROVAL',
                                  style: GoogleFonts.poppins(
                                    color: tournament.approvedPlayers.contains(user?.uid) ? Colors.green : Colors.orange,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            if (tournament.approvedPlayers.contains(user?.uid)) ...[
                              Text(
                                'Room credentials are live. Do not leak these credentials under any circumstances.',
                                style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 11),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF0F172A),
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: Colors.white.withOpacity(0.04)),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text('ROOM ID', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                                          const SizedBox(height: 4),
                                          Text(
                                            tournament.roomId,
                                            style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 0.5),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF0F172A),
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: Colors.white.withOpacity(0.04)),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text('PASSWORD', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                                          const SizedBox(height: 4),
                                          Text(
                                            tournament.roomPassword,
                                            style: GoogleFonts.poppins(color: const Color(0xFF3B82F6), fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 0.5),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ] else ...[
                              Text(
                                'Your registration is currently under review by our esports coordinators. Match credentials will unlock instantly upon coordinator approval.',
                                style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12, height: 1.5),
                              ),
                            ],
                            const Divider(height: 24, color: Color(0xFF334155)),
                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.redAccent.withOpacity(0.12),
                                foregroundColor: Colors.redAccent,
                                side: BorderSide(color: Colors.redAccent.withOpacity(0.35)),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                              onPressed: () => _showReportIssueDialog(context, tournament),
                              icon: const Icon(Icons.bug_report, size: 16),
                              label: Text('Report Match Dispute', style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 12)),
                            )
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],

                    // Rules card
                    Text(
                      'TOURNAMENT RULES & REGULATIONS',
                      style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.5),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B).withOpacity(0.4),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: Colors.white.withOpacity(0.06)),
                      ),
                      child: Text(
                        tournament.rules.isNotEmpty
                            ? tournament.rules
                            : '1. Be online in the game lobby 15 minutes before the start time.\n2. Keeping visual screen recording active is highly recommended for raising disputes.\n3. Dynamic teaming or usage of emulator/hacks will result in immediate ban.',
                        style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12, height: 1.6),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Leaderboard / Match Standings for Completed matches
                    if (isCompleted || tournament.killStats.isNotEmpty) ...[
                      Row(
                        children: [
                          const Icon(Icons.leaderboard, color: Color(0xFFFACC15), size: 20),
                          const SizedBox(width: 8),
                          Text(
                            'LEADERBOARD & STANDINGS',
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E293B).withOpacity(0.45),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0xFFFACC15).withOpacity(0.25)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('RANK / PLAYER', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                                Row(
                                  children: [
                                    Text('KILLS', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                                    const SizedBox(width: 24),
                                    Text('EARNINGS', style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                                  ],
                                ),
                              ],
                            ),
                            const Divider(color: Color(0xFF334155), height: 20),
                            ...(() {
                              final List<Map<String, dynamic>> standings = [];
                              final participantsList = tournament.participants;

                              for (final uid in participantsList) {
                                final kills = tournament.killStats[uid] ?? 0;
                                double prize = kills * tournament.killReward;
                                int rank = 4;

                                if (uid == tournament.firstPlaceUid) {
                                  rank = 1;
                                  prize += tournament.prizePool * 0.60;
                                } else if (uid == tournament.secondPlaceUid) {
                                  rank = 2;
                                  prize += tournament.prizePool * 0.25;
                                } else if (uid == tournament.thirdPlaceUid) {
                                  rank = 3;
                                  prize += tournament.prizePool * 0.15;
                                }

                                standings.add({
                                  'uid': uid,
                                  'name': fbService.getUserNameByUid(uid),
                                  'rank': rank,
                                  'kills': kills,
                                  'prize': prize,
                                });
                              }

                              standings.sort((a, b) {
                                final rComp = (a['rank'] as int).compareTo(b['rank'] as int);
                                if (rComp != 0) return rComp;
                                return (b['kills'] as int).compareTo(a['kills'] as int);
                              });

                              if (standings.isEmpty) {
                                return [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                    child: Center(
                                      child: Text(
                                        'No match results published yet.',
                                        style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 12, fontStyle: FontStyle.italic),
                                      ),
                                    ),
                                  )
                                ];
                              }

                              return standings.map((item) {
                                final rank = item['rank'] as int;
                                final name = item['name'] as String;
                                final kills = item['kills'] as int;
                                final prize = item['prize'] as double;
                                final isCurrentUser = user?.uid == item['uid'];

                                Widget rankBadge = Text('#$rank', style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.grey));
                                if (rank == 1) {
                                  rankBadge = const Icon(Icons.emoji_events, color: Color(0xFFFACC15), size: 18);
                                } else if (rank == 2) {
                                  rankBadge = const Icon(Icons.emoji_events, color: Colors.grey, size: 18);
                                } else if (rank == 3) {
                                  rankBadge = const Icon(Icons.emoji_events, color: Color(0xFFF97316), size: 18);
                                }

                                return Container(
                                  margin: const EdgeInsets.symmetric(vertical: 4),
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: isCurrentUser ? const Color(0xFFFACC15).withOpacity(0.08) : Colors.transparent,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          SizedBox(width: 24, child: Center(child: rankBadge)),
                                          const SizedBox(width: 12),
                                          Text(
                                            name,
                                            style: GoogleFonts.poppins(
                                              color: isCurrentUser ? const Color(0xFFFACC15) : Colors.white,
                                              fontWeight: isCurrentUser ? FontWeight.w800 : FontWeight.normal,
                                              fontSize: 13,
                                            ),
                                          ),
                                          if (isCurrentUser) ...[
                                            const SizedBox(width: 6),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                                              decoration: BoxDecoration(color: const Color(0xFFFACC15), borderRadius: BorderRadius.circular(4)),
                                              child: Text('YOU', style: GoogleFonts.poppins(color: Colors.black, fontSize: 8, fontWeight: FontWeight.bold)),
                                            )
                                          ],
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Text(
                                            '$kills kills',
                                            style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12),
                                          ),
                                          const SizedBox(width: 32),
                                          Text(
                                            '₹${prize.toStringAsFixed(0)}',
                                            style: GoogleFonts.poppins(color: const Color(0xFF10B981), fontWeight: FontWeight.bold, fontSize: 13),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                );
                              }).toList();
                            })(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ],
                ),
              ),
            ),

            // Bottom registration bar (Esports premium panel)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B).withOpacity(0.95),
                border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08))),
              ),
              child: SafeArea(
                top: false,
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'SLOTS: ${tournament.joinedCount}/${tournament.totalSlots} JOINED',
                            style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 0.5),
                          ),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: SizedBox(
                              width: 140,
                              child: LinearProgressIndicator(
                                value: tournament.joinedCount / tournament.totalSlots,
                                minHeight: 5,
                                backgroundColor: const Color(0xFF0F172A),
                                valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF3B82F6)),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    _buildActionButton(context, tournament, isAlreadyJoined, isFull, isCompleted),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildGridHighlight(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B).withOpacity(0.4),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                const SizedBox(height: 2),
                Text(
                  value, 
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildPrizeRow(String label, String payout, Color accent) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(Icons.stars, color: accent, size: 16),
            const SizedBox(width: 8),
            Text(label, style: GoogleFonts.poppins(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        Text(payout, style: GoogleFonts.poppins(color: const Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.w900)),
      ],
    );
  }

  Widget _buildActionButton(BuildContext context, Tournament tournament, bool isJoined, bool isFull, bool isCompleted) {
    if (isCompleted) {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF334155), 
          foregroundColor: Colors.grey,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        onPressed: null,
        child: Text('COMPLETED', style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13)),
      );
    }
    if (isJoined) {
      return ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF334155),
          foregroundColor: const Color(0xFF10B981),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        onPressed: null,
        icon: const Icon(Icons.check_circle, size: 18),
        label: Text('REGISTERED', style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13)),
      );
    }
    if (isFull) {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF334155), 
          foregroundColor: Colors.grey,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        onPressed: null,
        child: Text('SLOTS FULL', style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13)),
      );
    }

    final label = tournament.entryFee == 0.0 ? 'Join Free' : 'Pay & Join (₹${tournament.entryFee.toStringAsFixed(0)})';

    return Container(
      height: 46,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: const LinearGradient(
          colors: [Color(0xFFFACC15), Color(0xFFEAB308)],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFACC15).withOpacity(0.15),
            blurRadius: 10,
          )
        ],
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.black,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
        ),
        onPressed: _isProcessing ? null : () => _handleRegister(tournament),
        child: _isProcessing
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
            : Text(label, style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 13)),
      ),
    );
  }
}
