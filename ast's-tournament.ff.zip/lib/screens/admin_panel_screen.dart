import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../models/tournament.dart';
import '../models/user_profile.dart';
import '../models/transaction.dart';
import '../models/offer_app.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  // Create Tournament Fields
  final _titleController = TextEditingController();
  final _gameController = TextEditingController();
  final _feeController = TextEditingController();
  final _prizeController = TextEditingController();
  final _slotsController = TextEditingController();
  final _dateTimeController = TextEditingController();
  final _mapController = TextEditingController();
  final _rulesController = TextEditingController();
  final _startTimeController = TextEditingController();
  final _endTimeController = TextEditingController();
  final _regCloseTimeController = TextEditingController();
  final _killRewardController = TextEditingController();
  final _bonusEventsController = TextEditingController();
  String _selectedMode = 'Solo';

  @override
  void dispose() {
    _titleController.dispose();
    _gameController.dispose();
    _feeController.dispose();
    _prizeController.dispose();
    _slotsController.dispose();
    _dateTimeController.dispose();
    _mapController.dispose();
    _rulesController.dispose();
    _startTimeController.dispose();
    _endTimeController.dispose();
    _regCloseTimeController.dispose();
    _killRewardController.dispose();
    _bonusEventsController.dispose();
    super.dispose();
  }

  void _showCreateTournamentSheet() {
    // Pre-populate with realistic dates for easy admin simulation testing
    final now = DateTime.now();
    _dateTimeController.text = '${now.year}-${now.month.toString().padLeft(2, '0')}-${(now.day + 1).toString().padLeft(2, '0')} 18:00';
    _startTimeController.text = '${now.year}-${now.month.toString().padLeft(2, '0')}-${(now.day + 1).toString().padLeft(2, '0')} 18:00';
    _endTimeController.text = '${now.year}-${now.month.toString().padLeft(2, '0')}-${(now.day + 1).toString().padLeft(2, '0')} 21:00';
    _regCloseTimeController.text = '${now.year}-${now.month.toString().padLeft(2, '0')}-${(now.day + 1).toString().padLeft(2, '0')} 17:45';
    _killRewardController.text = '5.0';
    _bonusEventsController.text = 'MVP: ₹250, Most Kills: ₹150';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: StatefulBuilder(
            builder: (context, setSheetState) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Launch Game Lobby',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white, fontFamily: 'Space Grotesk'),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.grey),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _titleController,
                      style: const TextStyle(color: Colors.white),
                      decoration: _buildInputDeco('Tournament Title (e.g. Squad Showdown)'),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _gameController,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Game (e.g. BGMI, Free Fire)'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF0F172A),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: _selectedMode,
                                dropdownColor: const Color(0xFF1E293B),
                                style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold),
                                items: ['Solo', 'Duo', 'Squad', 'Clash Squad', 'Lone Wolf'].map((String val) {
                                  return DropdownMenuItem<String>(
                                    value: val,
                                    child: Text(val),
                                  );
                                }).toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setSheetState(() {
                                      _selectedMode = val;
                                    });
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _feeController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Entry Fee (₹)'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _prizeController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Prize Pool (₹)'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _slotsController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Total Slots'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _mapController,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Map Name (e.g. Erangel)'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _startTimeController,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Start Time (YYYY-MM-DD HH:MM)'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _endTimeController,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('End Time (YYYY-MM-DD HH:MM)'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _regCloseTimeController,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Registration Closes (HH:MM)'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _killRewardController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: _buildInputDeco('Kill Reward (₹/Kill)'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _bonusEventsController,
                      style: const TextStyle(color: Colors.white),
                      decoration: _buildInputDeco('Bonus Events Description (e.g. MVP, Headshots)'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _rulesController,
                      style: const TextStyle(color: Colors.white),
                      maxLines: 2,
                      decoration: _buildInputDeco('Custom match rules...'),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        final title = _titleController.text.trim();
                        final game = _gameController.text.trim();
                        final fee = double.tryParse(_feeController.text.trim()) ?? 0.0;
                        final prize = double.tryParse(_prizeController.text.trim()) ?? 0.0;
                        final slots = int.tryParse(_slotsController.text.trim()) ?? 100;
                        final startTimeStr = _startTimeController.text.trim();
                        final endTimeStr = _endTimeController.text.trim();
                        final regCloseStr = _regCloseTimeController.text.trim();
                        final killRewardVal = double.tryParse(_killRewardController.text.trim()) ?? 0.0;
                        final bonusEventsVal = _bonusEventsController.text.trim();
                        final map = _mapController.text.trim();
                        final rules = _rulesController.text.trim();

                        if (title.isNotEmpty && game.isNotEmpty && startTimeStr.isNotEmpty) {
                          final newTournament = Tournament(
                            id: 'custom_${DateTime.now().millisecondsSinceEpoch}',
                            title: title,
                            gameName: game,
                            gameMode: _selectedMode,
                            entryFee: fee,
                            prizePool: prize,
                            totalSlots: slots,
                            joinedCount: 0,
                            dateTime: startTimeStr,
                            rules: rules,
                            participants: [],
                            status: 'upcoming',
                            map: map.isEmpty ? 'Classic' : map,
                            startTime: startTimeStr,
                            endTime: endTimeStr,
                            registrationCloseTime: regCloseStr,
                            killReward: killRewardVal,
                            bonusEvents: bonusEventsVal,
                            approvedPlayers: [],
                            reportedIssues: [],
                            killStats: {},
                          );
                          Provider.of<FirebaseService>(context, listen: false).createTournament(newTournament);
                          
                          // Clear controllers
                          _titleController.clear();
                          _gameController.clear();
                          _feeController.clear();
                          _prizeController.clear();
                          _slotsController.clear();
                          _dateTimeController.clear();
                          _mapController.clear();
                          _rulesController.clear();
                          _startTimeController.clear();
                          _endTimeController.clear();
                          _regCloseTimeController.clear();
                          _killRewardController.clear();
                          _bonusEventsController.clear();

                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Tournament lobby launched! Players notified.')),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Please fill all mandatory titles, games & start times.')),
                          );
                        }
                      },
                      child: const Text('Publish Game Lobby', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  InputDecoration _buildInputDeco(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.grey, fontSize: 12),
      filled: true,
      fillColor: const Color(0xFF0F172A),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 8,
      child: Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        appBar: AppBar(
          title: const Text(
            'Admin Suite',
            style: TextStyle(fontFamily: 'Space Grotesk', fontWeight: FontWeight.bold, color: Colors.white),
          ),
          backgroundColor: const Color(0xFF1E293B),
          iconTheme: const IconThemeData(color: Colors.white),
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              Tab(icon: Icon(Icons.dashboard_outlined), text: 'Dashboard'),
              Tab(icon: Icon(Icons.sports_esports_outlined), text: 'Matches & Lobbies'),
              Tab(icon: Icon(Icons.people_alt_outlined), text: 'User Registry'),
              Tab(icon: Icon(Icons.account_balance_wallet_outlined), text: 'UPI Payments'),
              Tab(icon: Icon(Icons.bug_report_outlined), text: 'Complaints'),
              Tab(icon: Icon(Icons.campaign_outlined), text: 'Broadcast Alerts'),
              Tab(icon: Icon(Icons.discount_outlined), text: 'Coupons'),
              Tab(icon: Icon(Icons.monetization_on_outlined), text: 'Manage App Offers'),
            ],
            labelColor: Colors.amber,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.amber,
          ),
        ),
        body: const TabBarView(
          children: [
            AdminDashboardPane(),
            AdminMatchesManagerPane(),
            AdminUsersPane(),
            AdminPaymentsPane(),
            AdminComplaintsPane(),
            AdminBroadcasterPane(),
            AdminCouponsPane(),
            AdminOffersPane(),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: Colors.amber,
          foregroundColor: Colors.black,
          onPressed: _showCreateTournamentSheet,
          icon: const Icon(Icons.add),
          label: const Text('Launch Game', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }
}

// --- SUB PANEL 1: DASHBOARD ANALYTICS ---
class AdminDashboardPane extends StatelessWidget {
  const AdminDashboardPane({super.key});

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'SYSTEM METRICS OVERVIEW',
            style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.25,
            children: [
              _buildMetricCard(
                'Total Users',
                '${fb.totalUsersCount}',
                'Online now: ${fb.onlineUsersCount}',
                Icons.people,
                Colors.blue,
              ),
              _buildMetricCard(
                'Total Tournaments',
                '${fb.totalTournamentsCount}',
                'Lobbies in directory',
                Icons.emoji_events,
                Colors.amber,
              ),
              _buildMetricCard(
                'Live Matches',
                '${fb.liveMatchesCount}',
                'Underway right now',
                Icons.play_circle_fill,
                Colors.redAccent,
              ),
              _buildMetricCard(
                'Wallet Balance',
                '₹${fb.totalWalletBalance.toStringAsFixed(0)}',
                'User balances combined',
                Icons.account_balance_wallet,
                Colors.cyanAccent,
              ),
              _buildMetricCard(
                'Deposits',
                '₹${fb.totalDeposits.toStringAsFixed(0)}',
                'Approved inputs',
                Icons.arrow_downward,
                Colors.green,
              ),
              _buildMetricCard(
                'Withdrawals',
                '₹${fb.totalWithdrawals.toStringAsFixed(0)}',
                'Approved transfers',
                Icons.arrow_upward,
                Colors.pinkAccent,
              ),
              _buildMetricCard(
                'Revenue',
                '₹${fb.totalRevenue.toStringAsFixed(0)}',
                'Entry fee margins',
                Icons.monetization_on,
                Colors.emeraldAccent,
              ),
              _buildMetricCard(
                'Match Statistics',
                'U: ${fb.upcomingMatchesCount} | C: ${fb.completedMatchesCount}',
                'Cancelled: ${fb.cancelledMatchesCount}',
                Icons.query_stats,
                Colors.purpleAccent,
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Text(
            'QUICK SHORTCUTS',
            style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Simulation Control Console',
                  style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Quickly adjust user bans, publish room passwords, disperse multi-placement prizes, or approve UPI requests in the other tabs.',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber.withOpacity(0.15),
                          foregroundColor: Colors.amber,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () {
                          DefaultTabController.of(context).animateTo(1); // Jump to Matches
                        },
                        icon: const Icon(Icons.sports_esports, size: 16),
                        label: const Text('Manage Lobbies', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green.withOpacity(0.15),
                          foregroundColor: Colors.green,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () {
                          DefaultTabController.of(context).animateTo(3); // Jump to Payments
                        },
                        icon: const Icon(Icons.account_balance_wallet, size: 16),
                        label: const Text('Payments Drawer', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildMetricCard(String title, String val, String subtitle, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[800]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(icon, color: color, size: 22),
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              )
            ],
          ),
          const SizedBox(height: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                val,
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Space Grotesk'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                title,
                style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                subtitle,
                style: const TextStyle(color: Colors.grey, fontSize: 9),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          )
        ],
      ),
    );
  }
}

// --- SUB PANEL 2: MATCHES & LOBBIES MANAGER ---
class AdminMatchesManagerPane extends StatelessWidget {
  const AdminMatchesManagerPane({super.key});

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);
    final activeLobbies = fb.tournaments;

    if (activeLobbies.isEmpty) {
      return const Center(
        child: Text('No active lobbies available.', style: TextStyle(color: Colors.grey)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: activeLobbies.length,
      itemBuilder: (context, index) {
        final lobby = activeLobbies[index];
        final isCompleted = lobby.status == 'completed';
        final isCancelled = lobby.cancelled;

        return Card(
          color: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.amber.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '${lobby.gameName.toUpperCase()} - ${lobby.gameMode}',
                        style: const TextStyle(color: Colors.amber, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          isCancelled 
                              ? 'CANCELLED' 
                              : isCompleted 
                                  ? 'COMPLETED' 
                                  : 'ACTIVE',
                          style: TextStyle(
                            color: isCancelled 
                                ? Colors.redAccent 
                                : isCompleted 
                                    ? Colors.grey 
                                    : Colors.green,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (!isCompleted && !isCancelled)
                          PopupMenuButton<String>(
                            icon: const Icon(Icons.more_vert, color: Colors.grey, size: 18),
                            padding: EdgeInsets.zero,
                            onSelected: (val) {
                              if (val == 'edit') {
                                _showEditTournamentSheet(context, fb, lobby);
                              } else if (val == 'delete') {
                                _showDeleteTournamentConfirmation(context, fb, lobby);
                              }
                            },
                            itemBuilder: (context) => [
                              const PopupMenuItem(
                                value: 'edit',
                                child: Row(
                                  children: [
                                    Icon(Icons.edit, color: Colors.blue, size: 16),
                                    SizedBox(width: 8),
                                    Text('Edit Lobby', style: TextStyle(color: Colors.white, fontSize: 13)),
                                  ],
                                ),
                              ),
                              const PopupMenuItem(
                                value: 'delete',
                                child: Row(
                                  children: [
                                    Icon(Icons.delete, color: Colors.redAccent, size: 16),
                                    SizedBox(width: 8),
                                    Text('Delete Lobby', style: TextStyle(color: Colors.white, fontSize: 13)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  lobby.title,
                  style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  'Map: ${lobby.map} | Slots Filled: ${lobby.joinedCount}/${lobby.totalSlots}',
                  style: const TextStyle(color: Colors.grey, fontSize: 12),
                ),
                Text(
                  'Registration closes: ${lobby.registrationCloseTime}',
                  style: const TextStyle(color: Colors.grey, fontSize: 11),
                ),
                if (!isCompleted && !isCancelled) ...[
                  const Divider(height: 24, color: Color(0xFF334155)),
                  const Text(
                    'ADMIN LOBBY ACTIONS:',
                    style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue.withOpacity(0.15),
                          foregroundColor: Colors.blue,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () => _showApprovePlayersSheet(context, fb, lobby),
                        icon: const Icon(Icons.how_to_reg, size: 14),
                        label: const Text('Approve Players', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple.withOpacity(0.15),
                          foregroundColor: Colors.purple[300],
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () => _showUploadCredentialsDialog(context, fb, lobby),
                        icon: const Icon(Icons.vpn_key, size: 14),
                        label: const Text('Set Room Pass', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green.withOpacity(0.15),
                          foregroundColor: Colors.green,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () => _showPublishResultsSheet(context, fb, lobby),
                        icon: const Icon(Icons.emoji_events, size: 14),
                        label: const Text('Publish Results', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent.withOpacity(0.15),
                          foregroundColor: Colors.redAccent,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () => _showCancelMatchConfirmation(context, fb, lobby),
                        icon: const Icon(Icons.cancel, size: 14),
                        label: const Text('Cancel & Refund', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  )
                ] else if (isCompleted) ...[
                  const Divider(height: 24, color: Color(0xFF334155)),
                  Text(
                    'Winner: ${lobby.winnerName ?? "N/A"} | Prize Pool Fully Dispersed',
                    style: const TextStyle(color: Colors.amber, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ] else if (isCancelled) ...[
                  const Divider(height: 24, color: Color(0xFF334155)),
                  const Text(
                    'Lobby Cancelled - All competitor entry fees automatically refunded to main wallets.',
                    style: TextStyle(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  // Action 1: Player Approvals Dialog
  void _showApprovePlayersSheet(BuildContext context, FirebaseService fb, Tournament lobby) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final participants = lobby.participants;
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Competitor Approvals: ${lobby.title}',
                    style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text('Approve users so they can unlock Room credentials in their panel.', style: TextStyle(color: Colors.grey, fontSize: 11)),
                  const Divider(height: 24, color: Color(0xFF334155)),
                  if (participants.isEmpty)
                    const Expanded(
                      child: Center(
                        child: Text('No players registered yet.', style: TextStyle(color: Colors.grey)),
                      ),
                    )
                  else
                    Expanded(
                      child: ListView.builder(
                        itemCount: participants.length,
                        itemBuilder: (context, idx) {
                          final pUid = participants[idx];
                          final uIndex = fb.users.indexWhere((u) => u.uid == pUid);
                          final pName = uIndex != -1 ? fb.users[uIndex].name : pUid;
                          final isApproved = lobby.approvedPlayers.contains(pUid);

                          return ListTile(
                            title: Text(pName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            subtitle: Text('UID: $pUid', style: const TextStyle(color: Colors.grey, fontSize: 11)),
                            trailing: isApproved
                                ? const Chip(
                                    label: Text('APPROVED', style: TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold)),
                                    backgroundColor: Color(0xFF0F172A),
                                  )
                                : ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.amber,
                                      foregroundColor: Colors.black,
                                      minimumSize: const Size(80, 32),
                                    ),
                                    onPressed: () {
                                      fb.approvePlayer(lobby.id, pUid);
                                      setSheetState(() {});
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text('Player $pName registration approved!')),
                                      );
                                    },
                                    child: const Text('Approve', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                                  ),
                          );
                        },
                      ),
                    ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // Action 2: Upload Room Credentials
  void _showUploadCredentialsDialog(BuildContext context, FirebaseService fb, Tournament lobby) {
    final roomController = TextEditingController(text: lobby.roomId == 'TBD' ? '' : lobby.roomId);
    final passController = TextEditingController(text: lobby.roomPassword == 'TBD' ? '' : lobby.roomPassword);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Upload Room Credentials', style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Approved participants will instantly receive a system push notification and view these credentials.', style: TextStyle(color: Colors.grey, fontSize: 12)),
              const SizedBox(height: 16),
              TextField(
                controller: roomController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'ROOM ID',
                  labelStyle: const TextStyle(color: Colors.amber),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: passController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'PASSWORD',
                  labelStyle: const TextStyle(color: Colors.amber),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.amber, foregroundColor: Colors.black),
              onPressed: () {
                final rId = roomController.text.trim();
                final rPass = passController.text.trim();
                if (rId.isNotEmpty && rPass.isNotEmpty) {
                  fb.uploadRoomCredentials(lobby.id, rId, rPass);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Room Credentials published and push alerts broadcasted!')),
                  );
                }
              },
              child: const Text('Broadcast Details'),
            )
          ],
        );
      },
    );
  }

  // Action 3: Publish Results & Disperse Multi-Placement Prizes
  void _showPublishResultsSheet(BuildContext context, FirebaseService fb, Tournament lobby) {
    if (lobby.participants.isEmpty) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          title: const Text('No participants', style: TextStyle(color: Colors.white)),
          content: const Text('Cannot declare winners because zero competitors joined this lobby.', style: TextStyle(color: Colors.grey)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Dismiss', style: TextStyle(color: Colors.amber)),
            )
          ],
        ),
      );
      return;
    }

    String firstPlaceUid = lobby.participants.first;
    String secondPlaceUid = lobby.participants.length > 1 ? lobby.participants[1] : '';
    String thirdPlaceUid = lobby.participants.length > 2 ? lobby.participants[2] : '';
    double killRewardVal = lobby.killReward > 0 ? lobby.killReward : 5.0;
    
    // Kill stats input trackers
    final Map<String, TextEditingController> killControllers = {};
    for (var uId in lobby.participants) {
      killControllers[uId] = TextEditingController(text: '0');
    }

    // Bonus event input trackers
    final bonusWinnerController = TextEditingController(); // empty or userId
    final bonusAmountController = TextEditingController(text: '0');
    final bonusDescController = TextEditingController(text: 'MVP Award');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
                left: 20,
                right: 20,
                top: 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Publish Placements & Disperse Prizes', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Space Grotesk')),
                    const SizedBox(height: 4),
                    Text('Lobby: ${lobby.title} | Pool: \$${lobby.prizePool}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    const Divider(height: 24, color: Color(0xFF334155)),

                    // Placement 1
                    const Text('1ST PLACE CHAMPION (Gets 60% Payout)', style: TextStyle(color: Colors.amber, fontSize: 10, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    _buildUserDropdown(lobby.participants, fb, firstPlaceUid, (val) {
                      if (val != null) setSheetState(() => firstPlaceUid = val);
                    }),
                    const SizedBox(height: 12),

                    // Placement 2
                    const Text('2ND PLACE RUNNER UP (Gets 25% Payout)', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    _buildUserDropdown(lobby.participants, fb, secondPlaceUid, (val) {
                      if (val != null) setSheetState(() => secondPlaceUid = val);
                    }, allowEmpty: true),
                    const SizedBox(height: 12),

                    // Placement 3
                    const Text('3RD PLACE RUNNER UP (Gets 15% Payout)', style: TextStyle(color: Colors.brown, fontSize: 10, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    _buildUserDropdown(lobby.participants, fb, thirdPlaceUid, (val) {
                      if (val != null) setSheetState(() => thirdPlaceUid = val);
                    }, allowEmpty: true),
                    const SizedBox(height: 16),

                    // Kill reward multiplier
                    Row(
                      children: [
                        const Expanded(child: Text('Kill Reward Per Kill (\$)', style: TextStyle(color: Colors.grey, fontSize: 12, fontWeight: FontWeight.bold))),
                        SizedBox(
                          width: 80,
                          height: 36,
                          child: TextField(
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white, fontSize: 12),
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: BorderSide.none),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                            ),
                            onChanged: (val) {
                              killRewardVal = double.tryParse(val) ?? 0.0;
                            },
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 24, color: Color(0xFF334155)),

                    // Competitor Kills Entry List
                    const Text('COMPETITOR KILLS LOG:', style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Container(
                      maxHeight: 120,
                      decoration: BoxDecoration(color: const Color(0xFF0F172A), borderRadius: BorderRadius.circular(12)),
                      child: ListView(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(8),
                        children: lobby.participants.map((uId) {
                          final uIdx = fb.users.indexWhere((u) => u.uid == uId);
                          final pName = uIdx != -1 ? fb.users[uIdx].name : uId;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(pName, style: const TextStyle(color: Colors.white, fontSize: 13)),
                                SizedBox(
                                  width: 60,
                                  height: 32,
                                  child: TextField(
                                    controller: killControllers[uId],
                                    keyboardType: TextInputType.number,
                                    style: const TextStyle(color: Colors.amber, fontSize: 13, fontWeight: FontWeight.bold),
                                    decoration: InputDecoration(
                                      filled: true,
                                      fillColor: const Color(0xFF1E293B),
                                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: BorderSide.none),
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Bonus Prize details
                    const Text('BONUS EVENT AWARD (OPTIONAL)', style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: bonusDescController,
                            style: const TextStyle(color: Colors.white, fontSize: 12),
                            decoration: _buildInputDeco('Bonus Title (e.g. MVP)'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        SizedBox(
                          width: 80,
                          child: TextField(
                            controller: bonusAmountController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white, fontSize: 12),
                            decoration: _buildInputDeco('Prize (\$)'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    _buildUserDropdown(lobby.participants, fb, bonusWinnerController.text, (val) {
                      setSheetState(() {
                        bonusWinnerController.text = val ?? '';
                      });
                    }, allowEmpty: true, emptyLabel: 'No Bonus Winner Assigned'),

                    const SizedBox(height: 24),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        // Extract kills map
                        final Map<String, int> finalKills = {};
                        killControllers.forEach((uId, ctrl) {
                          finalKills[uId] = int.tryParse(ctrl.text.trim()) ?? 0;
                        });

                        final double bonusAmt = double.tryParse(bonusAmountController.text.trim()) ?? 0.0;

                        fb.publishResults(
                          tournamentId: lobby.id,
                          firstPlaceUid: firstPlaceUid,
                          secondPlaceUid: secondPlaceUid,
                          thirdPlaceUid: thirdPlaceUid,
                          killReward: killRewardVal,
                          killStats: finalKills,
                          bonusWinnerUid: bonusWinnerController.text,
                          bonusAmount: bonusAmt,
                          bonusDescription: bonusDescController.text.trim(),
                        );

                        // Close sheet
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Lobby outcomes published! All prizes distributed instantly.')),
                        );
                      },
                      child: const Text('Disperse Earnings & Archive Match', style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildUserDropdown(
    List<String> userUids,
    FirebaseService fb,
    String currentValue,
    Function(String?) onChanged, {
    bool allowEmpty = false,
    String emptyLabel = 'None / Unassigned',
  }) {
    final items = <DropdownMenuItem<String>>[];
    
    if (allowEmpty) {
      items.add(DropdownMenuItem(
        value: '',
        child: Text(emptyLabel, style: const TextStyle(color: Colors.grey, fontSize: 13)),
      ));
    }

    for (var uId in userUids) {
      if (uId.isEmpty) continue;
      final uIdx = fb.users.indexWhere((u) => u.uid == uId);
      final uName = uIdx != -1 ? fb.users[uIdx].name : uId;
      items.add(DropdownMenuItem(
        value: uId,
        child: Text(uName, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
      ));
    }

    // Ensure currentValue matches an item, fallback to first if not
    String checkedValue = currentValue;
    if (!items.any((item) => item.value == currentValue)) {
      checkedValue = items.isNotEmpty ? items.first.value ?? '' : '';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(color: const Color(0xFF0F172A), borderRadius: BorderRadius.circular(10)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: checkedValue,
          dropdownColor: const Color(0xFF1E293B),
          isExpanded: true,
          items: items,
          onChanged: onChanged,
        ),
      ),
    );
  }

  // Action 4: Cancel Match & Automatic Payout Refunds
  void _showCancelMatchConfirmation(BuildContext context, FirebaseService fb, Tournament lobby) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          title: const Text('Cancel Game Lobby?', style: TextStyle(color: Colors.white)),
          content: Text(
            'Confirm cancelling "${lobby.title}"?\n\nThis will instantly issue automatic entry fee refunds of ₹${lobby.entryFee.toStringAsFixed(2)} directly back to all ${lobby.joinedCount} registered user wallets.',
            style: const TextStyle(color: Colors.grey, fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Dismiss', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
              onPressed: () {
                fb.cancelTournament(lobby.id);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Lobby cancelled and full refunds distributed!')),
                );
              },
              child: const Text('Cancel & Refund', style: TextStyle(fontWeight: FontWeight.bold)),
            )
          ],
        );
      },
    );
  }

  void _showEditTournamentSheet(BuildContext context, FirebaseService fb, Tournament lobby) {
    final titleCtrl = TextEditingController(text: lobby.title);
    final gameCtrl = TextEditingController(text: lobby.gameName);
    final feeCtrl = TextEditingController(text: lobby.entryFee.toString());
    final prizeCtrl = TextEditingController(text: lobby.prizePool.toString());
    final slotsCtrl = TextEditingController(text: lobby.totalSlots.toString());
    final mapCtrl = TextEditingController(text: lobby.map);
    final rulesCtrl = TextEditingController(text: lobby.rules);
    final startCtrl = TextEditingController(text: lobby.startTime);
    final endCtrl = TextEditingController(text: lobby.endTime);
    final regCloseCtrl = TextEditingController(text: lobby.registrationCloseTime);
    final killRewardCtrl = TextEditingController(text: lobby.killReward.toString());
    final bonusCtrl = TextEditingController(text: lobby.bonusEvents);
    String selectedMode = lobby.gameMode;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: StatefulBuilder(
            builder: (context, setSheetState) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Edit Game Lobby',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white, fontFamily: 'Space Grotesk'),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.grey),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: titleCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        labelText: 'Tournament Title',
                        labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: gameCtrl,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Game',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF0F172A),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: selectedMode,
                                dropdownColor: const Color(0xFF1E293B),
                                style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold),
                                items: ['Solo', 'Duo', 'Squad', 'Clash Squad', 'Lone Wolf'].map((String val) {
                                  return DropdownMenuItem<String>(
                                    value: val,
                                    child: Text(val),
                                  );
                                }).toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setSheetState(() {
                                      selectedMode = val;
                                    });
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: feeCtrl,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Entry Fee (₹)',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: prizeCtrl,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Prize Pool (₹)',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: slotsCtrl,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Total Slots',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: mapCtrl,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Map Name',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: startCtrl,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Start Time (YYYY-MM-DD HH:MM)',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: endCtrl,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'End Time (YYYY-MM-DD HH:MM)',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: regCloseCtrl,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Registration Closes (HH:MM)',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: killRewardCtrl,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Kill Reward (₹/Kill)',
                              labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                              filled: true,
                              fillColor: const Color(0xFF0F172A),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: bonusCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        labelText: 'Bonus Events Description',
                        labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: rulesCtrl,
                      style: const TextStyle(color: Colors.white),
                      maxLines: 2,
                      decoration: InputDecoration(
                        labelText: 'Custom match rules...',
                        labelStyle: const TextStyle(color: Colors.grey, fontSize: 11),
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                      ),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        final title = titleCtrl.text.trim();
                        final game = gameCtrl.text.trim();
                        final fee = double.tryParse(feeCtrl.text.trim()) ?? lobby.entryFee;
                        final prize = double.tryParse(prizeCtrl.text.trim()) ?? lobby.prizePool;
                        final slots = int.tryParse(slotsCtrl.text.trim()) ?? lobby.totalSlots;
                        final map = mapCtrl.text.trim();
                        final rules = rulesCtrl.text.trim();
                        final startTime = startCtrl.text.trim();
                        final endTime = endCtrl.text.trim();
                        final regClose = regCloseCtrl.text.trim();
                        final killRewardVal = double.tryParse(killRewardCtrl.text.trim()) ?? lobby.killReward;
                        final bonusVal = bonusCtrl.text.trim();

                        if (title.isNotEmpty && game.isNotEmpty) {
                          final updated = Tournament(
                            id: lobby.id,
                            title: title,
                            gameName: game,
                            gameMode: selectedMode,
                            entryFee: fee,
                            prizePool: prize,
                            totalSlots: slots,
                            joinedCount: lobby.joinedCount,
                            dateTime: startTime,
                            rules: rules,
                            participants: lobby.participants,
                            status: lobby.status,
                            map: map.isEmpty ? 'Classic' : map,
                            startTime: startTime,
                            endTime: endTime,
                            registrationCloseTime: regClose,
                            killReward: killRewardVal,
                            bonusEvents: bonusVal,
                            approvedPlayers: lobby.approvedPlayers,
                            reportedIssues: lobby.reportedIssues,
                            killStats: lobby.killStats,
                            cancelled: lobby.cancelled,
                            winnerName: lobby.winnerName,
                            firstPlaceUid: lobby.firstPlaceUid,
                            secondPlaceUid: lobby.secondPlaceUid,
                            thirdPlaceUid: lobby.thirdPlaceUid,
                            roomId: lobby.roomId,
                            roomPassword: lobby.roomPassword,
                          );

                          fb.editTournament(updated);
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Tournament details updated successfully!')),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Please fill all mandatory titles & game names.')),
                          );
                        }
                      },
                      child: const Text('Save Changes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  void _showDeleteTournamentConfirmation(BuildContext context, FirebaseService fb, Tournament lobby) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Delete Tournament?', style: TextStyle(color: Colors.white, fontFamily: 'Space Grotesk')),
          content: Text(
            'Are you sure you want to completely delete "${lobby.title}"? This cannot be undone. Active registrants will NOT be automatically refunded if you delete, please cancel the lobby first to refund.',
            style: const TextStyle(color: Colors.grey, fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
              onPressed: () {
                fb.deleteTournament(lobby.id);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Lobby "${lobby.title}" has been deleted.')),
                );
              },
              child: const Text('Completely Delete', style: TextStyle(fontWeight: FontWeight.bold)),
            )
          ],
        );
      },
    );
  }
}

// --- SUB PANEL 3: USER REGISTRY (BAN/UNBAN) ---
class AdminUsersPane extends StatelessWidget {
  const AdminUsersPane({super.key});

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);
    final users = fb.users;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: users.length,
      itemBuilder: (context, index) {
        final u = users[index];
        final isBanned = u.isBanned;

        return Card(
          color: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: isBanned ? Colors.redAccent.withOpacity(0.2) : Colors.amber.withOpacity(0.2),
                  foregroundColor: isBanned ? Colors.redAccent : Colors.amber,
                  child: Text(u.name.substring(0, 1).toUpperCase()),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            u.name,
                            style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          if (u.isOnline) ...[
                            const SizedBox(width: 6),
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        u.email.isNotEmpty ? u.email : u.phone,
                        style: const TextStyle(color: Colors.grey, fontSize: 11),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Wallet Balance: \$${u.walletBalance.toStringAsFixed(2)}',
                        style: const TextStyle(color: Colors.green, fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                Column(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isBanned ? Colors.green.withOpacity(0.15) : Colors.redAccent.withOpacity(0.15),
                        foregroundColor: isBanned ? Colors.green : Colors.redAccent,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        minimumSize: Size.zero,
                        side: BorderSide(color: isBanned ? Colors.green : Colors.redAccent),
                      ),
                      onPressed: () {
                        fb.toggleUserBan(u.uid);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('${u.name} is now ${isBanned ? "UNBANNED" : "BANNED"}!')),
                        );
                      },
                      child: Text(
                        isBanned ? 'Unban User' : 'Ban User',
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      u.isAdmin ? 'Admin Role' : 'Player Role',
                      style: const TextStyle(color: Colors.grey, fontSize: 9, fontWeight: FontWeight.bold),
                    )
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }
}

// --- SUB PANEL 4: UPI PAYMENTS MANAGEMENT ---
class AdminPaymentsPane extends StatelessWidget {
  const AdminPaymentsPane({super.key});

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);
    final txns = fb.transactions.where((tx) => tx.status == 'PENDING').toList();

    if (txns.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle_outline, size: 48, color: Colors.grey[700]),
            const SizedBox(height: 12),
            const Text('No pending transaction approvals.', style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: txns.length,
      itemBuilder: (context, index) {
        final tx = txns[index];
        final isDeposit = tx.type == 'DEPOSIT';

        return Card(
          color: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      tx.type,
                      style: TextStyle(color: isDeposit ? Colors.green : Colors.orange, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '\$${tx.amount.toStringAsFixed(2)}',
                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                const SizedBox(height: 8),
                Text(tx.description, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 4),
                Text('UPI ID / TXN: ${tx.upiTxnId ?? "N/A"}', style: const TextStyle(color: Colors.amber, fontSize: 11)),
                const Divider(height: 24, color: Color(0xFF334155)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        fb.rejectTransaction(tx.id);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('UPI Request Rejected!')));
                      },
                      child: const Text('Reject', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                      onPressed: () {
                        fb.approveTransaction(tx.id);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('UPI Request Approved & Wallets credited!')));
                      },
                      child: const Text('Approve & Pay', style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }
}

// --- SUB PANEL 5: COMPLAINTS (VIEW REPORTS) ---
class AdminComplaintsPane extends StatelessWidget {
  const AdminComplaintsPane({super.key});

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);
    
    // Aggregate reports from all lobbies
    final List<Map<String, dynamic>> allReports = [];
    for (var lobby in fb.tournaments) {
      for (var report in lobby.reportedIssues) {
        allReports.add({
          'lobbyId': lobby.id,
          'lobbyTitle': lobby.title,
          ...report,
        });
      }
    }

    if (allReports.isEmpty) {
      return const Center(
        child: Text('No complaints or match issues submitted.', style: TextStyle(color: Colors.grey)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: allReports.length,
      itemBuilder: (context, index) {
        final rep = allReports[index];
        final isResolved = rep['status'] == 'RESOLVED';

        return Card(
          color: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'LOBBY: ${rep['lobbyTitle']}',
                      style: const TextStyle(color: Colors.amber, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      isResolved ? 'RESOLVED' : 'PENDING',
                      style: TextStyle(
                        color: isResolved ? Colors.green : Colors.redAccent,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(rep['description'], style: const TextStyle(color: Colors.white, fontSize: 13)),
                const SizedBox(height: 8),
                Text('By: ${rep['userName']} (UID: ${rep['userId']}) | On: ${rep['timestamp']}', style: const TextStyle(color: Colors.grey, fontSize: 10)),
                if (!isResolved) ...[
                  const Divider(height: 20, color: Color(0xFF334155)),
                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.withOpacity(0.15),
                        foregroundColor: Colors.green,
                        elevation: 0,
                      ),
                      onPressed: () {
                        fb.resolveReportedIssue(rep['lobbyId'], rep['id']);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Complaint report resolved!')));
                      },
                      icon: const Icon(Icons.check, size: 14),
                      label: const Text('Resolve Case', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ]
              ],
            ),
          ),
        );
      },
    );
  }
}

// --- SUB PANEL 6: BROADCAST ALERTS ---
class AdminBroadcasterPane extends StatefulWidget {
  const AdminBroadcasterPane({super.key});

  @override
  State<AdminBroadcasterPane> createState() => _AdminBroadcasterPaneState();
}

class _AdminBroadcasterPaneState extends State<AdminBroadcasterPane> {
  final _titleCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();

  @override
  void dispose() {
    _titleCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context, listen: false);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'BROADCAST PUSH SYSTEM',
            style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey[800]!),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Send System Push Notification',
                  style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                const Text('All online and offline players will receive this simulated system-wide alert banner instantly.', style: TextStyle(color: Colors.grey, fontSize: 11)),
                const Divider(height: 24, color: Color(0xFF334155)),
                TextField(
                  controller: _titleCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: _buildInputDeco('Alert Headline (e.g., Ludo match delayed)'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _bodyCtrl,
                  maxLines: 4,
                  style: const TextStyle(color: Colors.white),
                  decoration: _buildInputDeco('Notification message body content details...'),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () {
                    final t = _titleCtrl.text.trim();
                    final b = _bodyCtrl.text.trim();
                    if (t.isNotEmpty && b.isNotEmpty) {
                      fb.sendGlobalPushNotification(t, b);
                      _titleCtrl.clear();
                      _bodyCtrl.clear();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Global Push Notification Broadcasted successfully!')),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Please enter headline & message body.')),
                      );
                    }
                  },
                  icon: const Icon(Icons.campaign),
                  label: const Text('Broadcast Simulated Alert', style: TextStyle(fontWeight: FontWeight.bold)),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  InputDecoration _buildInputDeco(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.grey, fontSize: 12),
      filled: true,
      fillColor: const Color(0xFF0F172A),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    );
  }
}

// --- SUB PANEL 7: COUPONS MANAGER ---
class AdminCouponsPane extends StatefulWidget {
  const AdminCouponsPane({super.key});

  @override
  State<AdminCouponsPane> createState() => _AdminCouponsPaneState();
}

class _AdminCouponsPaneState extends State<AdminCouponsPane> {
  final _codeController = TextEditingController();
  final _amountController = TextEditingController();
  String _couponType = 'BONUS';

  @override
  void dispose() {
    _codeController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _showAddCouponDialog(BuildContext context, FirebaseService fb) {
    _codeController.clear();
    _amountController.clear();
    _couponType = 'BONUS';

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1E293B),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Text('Create Coupon Code', style: TextStyle(color: Colors.white, fontFamily: 'Space Grotesk')),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Launch an active check-in or promotional sponsor code for users.',
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _codeController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        labelText: 'COUPON CODE (e.g. FREE50)',
                        labelStyle: const TextStyle(color: Colors.grey, fontSize: 12),
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _amountController,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        labelText: 'AMOUNT (₹)',
                        labelStyle: const TextStyle(color: Colors.grey, fontSize: 12),
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text('Wallet Destination', style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0F172A),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: _couponType,
                          dropdownColor: const Color(0xFF0F172A),
                          style: const TextStyle(color: Colors.white, fontSize: 14),
                          onChanged: (val) {
                            if (val != null) {
                              setDialogState(() {
                                _couponType = val;
                              });
                            }
                          },
                          items: const [
                            DropdownMenuItem(value: 'BONUS', child: Text('Bonus Wallet')),
                            DropdownMenuItem(value: 'MAIN', child: Text('Main Wallet')),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.amber, foregroundColor: Colors.black),
                  onPressed: () {
                    final code = _codeController.text.trim().toUpperCase();
                    final amt = double.tryParse(_amountController.text.trim());
                    if (code.isNotEmpty && amt != null && amt > 0) {
                      fb.addCouponCode(code, amt, _couponType);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Voucher $code created successfully!'), backgroundColor: Colors.green),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Please fill all fields with valid values.')),
                      );
                    }
                  },
                  child: const Text('Publish Coupon'),
                )
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);
    final coupons = fb.coupons;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ACTIVE VOUCHERS',
                    style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Space Grotesk'),
                  ),
                  SizedBox(height: 2),
                  Text('Reward and promotional code database', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.amber, foregroundColor: Colors.black),
                onPressed: () => _showAddCouponDialog(context, fb),
                icon: const Icon(Icons.add, size: 16),
                label: const Text('Create Coupon', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: coupons.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.percent, size: 48, color: Colors.grey[800]),
                        const SizedBox(height: 12),
                        const Text('No active promo coupons found.', style: TextStyle(color: Colors.grey)),
                        const SizedBox(height: 4),
                        const Text('Click Create Coupon to add one.', style: TextStyle(color: Colors.grey, fontSize: 11)),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: coupons.length,
                    itemBuilder: (context, index) {
                      final c = coupons[index];
                      final code = c['code'] ?? 'UNKNOWN';
                      final amt = c['amount'] ?? 0.0;
                      final type = c['type'] ?? 'BONUS';
                      final redeemed = c['redeemedBy'] as List<dynamic>? ?? [];

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E293B),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.grey[800]!),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        '$code',
                                        style: const TextStyle(color: Colors.amber, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.0, fontFamily: 'Space Grotesk'),
                                      ),
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: type == 'MAIN' ? Colors.green.withOpacity(0.15) : Colors.cyan.withOpacity(0.15),
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          type == 'MAIN' ? 'MAIN WALLET' : 'BONUS WALLET',
                                          style: TextStyle(color: type == 'MAIN' ? Colors.greenAccent : Colors.cyanAccent, fontSize: 8, fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    'Reward Value: ₹${amt.toStringAsFixed(1)}',
                                    style: const TextStyle(color: Colors.white, fontSize: 12),
                                  ),
                                  Text(
                                    'Total Redemptions: ${redeemed.length} user(s)',
                                    style: const TextStyle(color: Colors.grey, fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      backgroundColor: const Color(0xFF1E293B),
                                      title: const Text('Delete Coupon?', style: TextStyle(color: Colors.white)),
                                      content: Text('Are you sure you want to delete the voucher code $code? Users will no longer be able to redeem it.'),
                                      actions: [
                                        TextButton(
                                          onPressed: () => Navigator.pop(context),
                                          child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
                                        ),
                                        ElevatedButton(
                                          style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                                          onPressed: () {
                                            fb.deleteCouponCode(code);
                                            Navigator.pop(context);
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              SnackBar(content: Text('Voucher $code deleted!')),
                                            );
                                          },
                                          child: const Text('Delete'),
                                        )
                                      ],
                                    );
                                  },
                                );
                              },
                              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                            )
                          ],
                        ),
                      );
                    },
                  ),
          )
        ],
      ),
    );
  }
}

// --- SUB PANEL 8: MANAGE APP OFFERS ---
class AdminOffersPane extends StatefulWidget {
  const AdminOffersPane({super.key});

  @override
  State<AdminOffersPane> createState() => _AdminOffersPaneState();
}

class _AdminOffersPaneState extends State<AdminOffersPane> {
  final _appNameController = TextEditingController();
  final _logoUrlController = TextEditingController();
  final _downloadUrlController = TextEditingController();
  final _rewardAmountController = TextEditingController();
  final _packageNameController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _appNameController.dispose();
    _logoUrlController.dispose();
    _downloadUrlController.dispose();
    _rewardAmountController.dispose();
    _packageNameController.dispose();
    super.dispose();
  }

  InputDecoration _buildInputDeco(String label, String hint) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.amber, fontSize: 13, fontWeight: FontWeight.w500),
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.grey, fontSize: 11),
      filled: true,
      fillColor: const Color(0xFF0F172A),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.amber, width: 1.5),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }

  void _publishOffer() {
    if (_formKey.currentState!.validate()) {
      final appName = _appNameController.text.trim();
      final logoUrl = _logoUrlController.text.trim();
      final downloadUrl = _downloadUrlController.text.trim();
      final rewardAmount = double.tryParse(_rewardAmountController.text.trim()) ?? 0.0;
      final packageName = _packageNameController.text.trim();

      final newOffer = OfferApp(
        id: 'off_${DateTime.now().millisecondsSinceEpoch}',
        appName: appName,
        logoUrl: logoUrl.isEmpty 
            ? 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=100' 
            : logoUrl,
        downloadUrl: downloadUrl,
        rewardAmount: rewardAmount,
        packageName: packageName,
      );

      Provider.of<FirebaseService>(context, listen: false).addOffer(newOffer);

      _appNameController.clear();
      _logoUrlController.clear();
      _downloadUrlController.clear();
      _rewardAmountController.clear();
      _packageNameController.clear();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Sponsor Offer "$appName" published successfully!'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final fb = Provider.of<FirebaseService>(context);
    final offers = fb.offers;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Title card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFFFACC15).withOpacity(0.15),
                    const Color(0xFF1E293B).withOpacity(0.4),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFFACC15).withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.monetization_on, color: Color(0xFFFACC15), size: 32),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'CPA OFFERS & SPONSOR APPS',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Space Grotesk',
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Add and manage sponsor apps that users can install to earn rewards.',
                          style: TextStyle(color: Colors.grey[400], fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Form Title
            const Text(
              'PUBLISH NEW SPONSOR OFFER',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 12),

            // App Name Field
            TextFormField(
              controller: _appNameController,
              style: const TextStyle(color: Colors.white),
              decoration: _buildInputDeco('App Name', 'e.g., Telegram, Discord, Free Fire'),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter the app name';
                }
                return null;
              },
            ),
            const SizedBox(height: 12),

            // Logo URL Field
            TextFormField(
              controller: _logoUrlController,
              style: const TextStyle(color: Colors.white),
              decoration: _buildInputDeco('Logo URL (Unsplash or direct image link)', 'e.g., https://images.unsplash.com/...'),
            ),
            const SizedBox(height: 12),

            // Download URL Field
            TextFormField(
              controller: _downloadUrlController,
              style: const TextStyle(color: Colors.white),
              decoration: _buildInputDeco('Download / Play Store URL', 'e.g., https://play.google.com/store/apps/...'),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter the download URL';
                }
                return null;
              },
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                // Reward Amount
                Expanded(
                  child: TextFormField(
                    controller: _rewardAmountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    style: const TextStyle(color: Colors.white),
                    decoration: _buildInputDeco('Reward Cash (₹)', 'e.g., 20.0'),
                    validator: (val) {
                      if (val == null || val.trim().isEmpty) {
                        return 'Required';
                      }
                      if (double.tryParse(val.trim()) == null) {
                        return 'Invalid number';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 12),
                // Package Name
                Expanded(
                  child: TextFormField(
                    controller: _packageNameController,
                    style: const TextStyle(color: Colors.white),
                    decoration: _buildInputDeco('Package Name', 'e.g., org.telegram.messenger'),
                    validator: (val) {
                      if (val == null || val.trim().isEmpty) {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Publish Button
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFACC15),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 3,
              ),
              onPressed: _publishOffer,
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.publish, size: 20),
                  SizedBox(width: 8),
                  Text(
                    'Publish Sponsor Offer',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 0.5),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),

            // Active Offers Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'ACTIVE SPONSOR OFFERS',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.amber.withOpacity(0.2)),
                  ),
                  child: Text(
                    '${offers.length} Active',
                    style: const TextStyle(color: Colors.amber, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            if (offers.isEmpty)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 40),
                alignment: Alignment.center,
                child: const Text(
                  'No sponsor offers active. Add one above!',
                  style: TextStyle(color: Colors.grey, fontSize: 13),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: offers.length,
                itemBuilder: (context, index) {
                  final app = offers[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E293B).withOpacity(0.5),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.06)),
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.network(
                            app.logoUrl,
                            width: 40,
                            height: 40,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                width: 40,
                                height: 40,
                                color: const Color(0xFF0F172A),
                                child: const Icon(Icons.image_not_supported, color: Colors.grey, size: 20),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                app.appName,
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Package: ${app.packageName}',
                                style: const TextStyle(color: Colors.grey, fontSize: 10),
                              ),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              '+ ₹${app.rewardAmount.toStringAsFixed(1)}',
                              style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold, fontSize: 13),
                            ),
                            const SizedBox(height: 4),
                            GestureDetector(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      backgroundColor: const Color(0xFF1E293B),
                                      title: const Text('Remove Offer?', style: TextStyle(color: Colors.white)),
                                      content: Text('Are you sure you want to remove the sponsor offer for "${app.appName}"?'),
                                      actions: [
                                        TextButton(
                                          onPressed: () => Navigator.pop(context),
                                          child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
                                        ),
                                        ElevatedButton(
                                          style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                                          onPressed: () {
                                            fb.removeOffer(app.id);
                                            Navigator.pop(context);
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              SnackBar(content: Text('Sponsor offer "${app.appName}" removed!')),
                                            );
                                          },
                                          child: const Text('Remove'),
                                        )
                                      ],
                                    );
                                  },
                                );
                              },
                              child: const Text(
                                'Delete',
                                style: TextStyle(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.w600),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
