import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/firebase_service.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();

  bool _isEmailMode = true;
  bool _isLoading = false;
  String _phoneError = '';
  String _emailError = '';

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _phoneController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  void _showForgotPasswordDialog() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text(
            'Reset Account Password',
            style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Enter your registered email or username. We will send you a 6-digit OTP code to reset your password.',
                style: GoogleFonts.poppins(color: Colors.grey[400], fontSize: 12, height: 1.4),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                style: GoogleFonts.poppins(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Email or Username',
                  labelStyle: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 13),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: GoogleFonts.poppins(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFACC15),
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {
                final target = controller.text.trim();
                if (target.isNotEmpty) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Recovery instructions and secure OTP code sent to $target!', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                      backgroundColor: const Color(0xFFFACC15),
                    ),
                  );
                }
              },
              child: Text('Send Code', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
            )
          ],
        );
      },
    );
  }

  Future<void> _handleEmailLogin() async {
    final input = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (input.isEmpty) {
      setState(() {
        _emailError = 'Please enter your username or email address';
      });
      return;
    }

    final email = input.contains('@') ? input : '$input@asttournament.com';

    if (password.length < 6) {
      setState(() {
        _emailError = 'Password must be at least 6 characters';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _emailError = '';
    });

    try {
      final service = Provider.of<FirebaseService>(context, listen: false);
      await service.loginWithEmail(email, password);
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      }
    } catch (e) {
      setState(() {
        _emailError = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _handlePhoneLogin() async {
    final phone = _phoneController.text.trim();
    if (phone.length < 10) {
      setState(() {
        _phoneError = 'Please enter a valid 10-digit phone number';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _phoneError = '';
    });

    // Simulate OTP sending
    await Future.delayed(const Duration(milliseconds: 800));
    
    if (!mounted) return;
    setState(() {
      _isLoading = false;
    });

    // Show dynamic sheet for SMS OTP entry
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1E293B), // slate-800
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Verify Phone OTP',
                    style: GoogleFonts.poppins(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: () => Navigator.pop(context),
                  )
                ],
              ),
              const SizedBox(height: 12),
              Text(
                'Enter the 6-digit verification code sent to (+91) $phone:',
                style: GoogleFonts.poppins(color: Colors.grey, fontSize: 14),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _otpController,
                keyboardType: TextInputType.number,
                maxLength: 6,
                style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, letterSpacing: 6, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  counterText: '',
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  hintText: '• • • • • •',
                  hintStyle: const TextStyle(color: Colors.grey, letterSpacing: 6),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFACC15),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: () async {
                  final otp = _otpController.text.trim();
                  if (otp.length == 6) {
                    Navigator.pop(context); // Close bottom sheet
                    setState(() {
                      _isLoading = true;
                    });
                    
                    final service = Provider.of<FirebaseService>(this.context, listen: false);
                    await service.loginWithPhone('+91$phone');
                    
                    if (mounted) {
                      Navigator.pushReplacement(
                        this.context,
                        MaterialPageRoute(builder: (context) => const HomeScreen()),
                      );
                    }
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Please enter a valid 6-digit OTP.', style: GoogleFonts.poppins())),
                    );
                  }
                },
                child: Text(
                  'Verify & Continue',
                  style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  Future<void> _handleGoogleLogin() async {
    setState(() {
      _isLoading = true;
    });
    // Simulate authentic Google Auth selection flow
    await Future.delayed(const Duration(milliseconds: 700));
    final service = Provider.of<FirebaseService>(context, listen: false);
    await service.loginWithEmail('urast5818@gmail.com', 'google_verified_password');
    setState(() {
      _isLoading = false;
    });
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), // Premium Dark Navy
      body: Stack(
        children: [
          // 3D Gaming Environment Background Photo
          Positioned.fill(
            child: Image.network(
              'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop',
              fit: BoxFit.cover,
            ),
          ),
          // Deep Indigo-Navy gradient overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF0F172A).withOpacity(0.95),
                    const Color(0xFF1E1B4B).withOpacity(0.85),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 16),
                    // App Logo Header (Glowing custom esports ring)
                    Center(
                      child: Hero(
                        tag: 'app_trophy',
                        child: Container(
                          padding: const EdgeInsets.all(22),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E293B).withOpacity(0.5), // Glassmorphic
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFFFACC15).withOpacity(0.35), width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF3B82F6).withOpacity(0.15), // Electric Blue Glow
                                blurRadius: 30,
                                spreadRadius: 5,
                              )
                            ],
                          ),
                          child: const Icon(
                            Icons.emoji_events,
                            size: 58,
                            color: Color(0xFFFACC15), // Gold
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'AST TOURNAMENTS',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(
                        fontSize: 26,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Enter the elite gaming arena. Compete in custom daily tournaments and claim instant secure pay rewards.',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(
                        fontSize: 13,
                        color: Colors.grey[400],
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Glassmorphic Input Card Container
                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B).withOpacity(0.45), // Slate-800 glass
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white.withOpacity(0.06)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 25,
                            offset: const Offset(0, 12),
                          )
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // Mode toggle tab bar (Esports style)
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFF0F172A).withOpacity(0.8),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: Colors.white.withOpacity(0.04)),
                            ),
                            padding: const EdgeInsets.all(4),
                            child: Row(
                              children: [
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => setState(() => _isEmailMode = true),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                      decoration: BoxDecoration(
                                        gradient: _isEmailMode 
                                            ? const LinearGradient(colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)]) 
                                            : null,
                                        color: _isEmailMode ? null : Colors.transparent,
                                        borderRadius: BorderRadius.circular(12),
                                        boxShadow: _isEmailMode 
                                            ? [BoxShadow(color: const Color(0xFF3B82F6).withOpacity(0.3), blurRadius: 10)] 
                                            : null,
                                      ),
                                      child: Text(
                                        'Email Access',
                                        textAlign: TextAlign.center,
                                        style: GoogleFonts.poppins(
                                          color: Colors.white, 
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => setState(() => _isEmailMode = false),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                      decoration: BoxDecoration(
                                        gradient: !_isEmailMode 
                                            ? const LinearGradient(colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)]) 
                                            : null,
                                        color: !_isEmailMode ? null : Colors.transparent,
                                        borderRadius: BorderRadius.circular(12),
                                        boxShadow: !_isEmailMode 
                                            ? [BoxShadow(color: const Color(0xFF3B82F6).withOpacity(0.3), blurRadius: 10)] 
                                            : null,
                                      ),
                                      child: Text(
                                        'Phone OTP',
                                        textAlign: TextAlign.center,
                                        style: GoogleFonts.poppins(
                                          color: Colors.white, 
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),

                          // Dynamic Sign In Input Panel
                          _isEmailMode ? _buildEmailForm() : _buildPhoneForm(),
                        ],
                      ),
                    ),

                    const SizedBox(height: 28),

                    // Social Sign-In divider
                    Row(
                      children: [
                        Expanded(child: Divider(color: Colors.grey[850])),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Text(
                            'OR CONTINUE WITH', 
                            style: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5),
                          ),
                        ),
                        Expanded(child: Divider(color: Colors.grey[850])),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Google Sign-In Button (Premium Glassmorphic style)
                    OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        side: BorderSide(color: Colors.white.withOpacity(0.08)),
                        backgroundColor: Colors.white.withOpacity(0.02),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      onPressed: _isLoading ? null : _handleGoogleLogin,
                      icon: Image.network(
                        'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/1200px-Google_%22G%22_logo.svg.png',
                        height: 18,
                        errorBuilder: (context, error, stackTrace) => const Icon(Icons.g_mobiledata, color: Colors.blue, size: 24),
                      ),
                      label: Text(
                        'Sign In with Google Account',
                        style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmailForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _emailController,
          style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
          keyboardType: TextInputType.emailAddress,
          decoration: InputDecoration(
            labelText: 'Email Address or Username',
            labelStyle: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 13),
            prefixIcon: const Icon(Icons.email_outlined, color: Colors.grey, size: 20),
            filled: true,
            fillColor: const Color(0xFF0F172A).withOpacity(0.8),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.05)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFFACC15), width: 1.5),
            ),
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _passwordController,
          style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Password',
            labelStyle: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 13),
            prefixIcon: const Icon(Icons.lock_outline, color: Colors.grey, size: 20),
            filled: true,
            fillColor: const Color(0xFF0F172A).withOpacity(0.8),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.05)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFFACC15), width: 1.5),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Align(
          alignment: Alignment.centerRight,
          child: GestureDetector(
            onTap: _showForgotPasswordDialog,
            child: Text(
              'Forgot Password?',
              style: GoogleFonts.poppins(color: const Color(0xFFFACC15), fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        if (_emailError.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(_emailError, style: GoogleFonts.poppins(color: Colors.redAccent, fontSize: 12)),
        ],
        const SizedBox(height: 24),
        Container(
          height: 52,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: const LinearGradient(
              colors: [Color(0xFFFACC15), Color(0xFFEAB308)], // Gold gradients
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFACC15).withOpacity(0.2),
                blurRadius: 10,
                offset: const Offset(0, 4),
              )
            ],
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.black,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: _isLoading ? null : _handleEmailLogin,
            child: _isLoading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : Text('ENTER BATTLEGROUND', style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 0.5)),
          ),
        ),
      ],
    );
  }

  Widget _buildPhoneForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _phoneController,
          style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
          keyboardType: TextInputType.phone,
          maxLength: 10,
          decoration: InputDecoration(
            counterText: '',
            labelText: 'Mobile Number',
            labelStyle: GoogleFonts.poppins(color: Colors.grey[500], fontSize: 13),
            prefixIcon: const Icon(Icons.phone_outlined, color: Colors.grey, size: 20),
            prefixText: '+91 ',
            prefixStyle: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
            filled: true,
            fillColor: const Color(0xFF0F172A).withOpacity(0.8),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.05)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFFACC15), width: 1.5),
            ),
          ),
        ),
        if (_phoneError.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(_phoneError, style: GoogleFonts.poppins(color: Colors.redAccent, fontSize: 12)),
        ],
        const SizedBox(height: 24),
        Container(
          height: 52,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: const LinearGradient(
              colors: [Color(0xFFFACC15), Color(0xFFEAB308)],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFACC15).withOpacity(0.2),
                blurRadius: 10,
                offset: const Offset(0, 4),
              )
            ],
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.black,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: _isLoading ? null : _handlePhoneLogin,
            child: _isLoading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : Text('REQUEST SMS OTP', style: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 0.5)),
          ),
        ),
      ],
    );
  }
}
