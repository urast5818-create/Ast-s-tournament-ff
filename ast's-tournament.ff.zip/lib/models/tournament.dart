class Tournament {
  String id;
  String title;
  String gameName;
  String gameMode;
  double entryFee;
  double prizePool;
  int totalSlots;
  int joinedCount;
  String dateTime;
  String rules;
  List<String> participants;
  String status; // 'upcoming', 'ongoing', 'completed'
  String? winnerName;
  String map;

  // Additional rules and details
  String startTime;
  String endTime;
  String registrationCloseTime;
  String roomId;
  String roomPassword;
  List<String> approvedPlayers;
  List<Map<String, dynamic>> reportedIssues;
  bool cancelled;
  
  // Prize placements and stats
  String? firstPlaceUid;
  String? secondPlaceUid;
  String? thirdPlaceUid;
  double killReward;
  String bonusEvents;
  Map<String, int> killStats; // User UID -> Kill count

  Tournament({
    required this.id,
    required this.title,
    required this.gameName,
    required this.gameMode,
    required this.entryFee,
    required this.prizePool,
    required this.totalSlots,
    required this.joinedCount,
    required this.dateTime,
    required this.rules,
    required this.participants,
    required this.status,
    this.winnerName,
    required this.map,
    this.startTime = '',
    this.endTime = '',
    this.registrationCloseTime = '',
    this.roomId = 'TBD',
    this.roomPassword = 'TBD',
    required this.approvedPlayers,
    required this.reportedIssues,
    this.cancelled = false,
    this.firstPlaceUid,
    this.secondPlaceUid,
    this.thirdPlaceUid,
    this.killReward = 0.0,
    this.bonusEvents = '',
    required this.killStats,
  });

  factory Tournament.fromMap(Map<String, dynamic> data, String documentId) {
    // Safely cast reported issues
    final rawReports = data['reportedIssues'] as List? ?? [];
    final reportsList = rawReports.map((e) => Map<String, dynamic>.from(e as Map)).toList();

    // Safely cast killStats
    final rawKillStats = data['killStats'] as Map? ?? {};
    final killStatsMap = rawKillStats.map((k, v) => MapEntry(k.toString(), v as int));

    return Tournament(
      id: documentId,
      title: data['title'] ?? '',
      gameName: data['gameName'] ?? 'Unknown Game',
      gameMode: data['gameMode'] ?? 'Solo',
      entryFee: (data['entryFee'] as num?)?.toDouble() ?? 0.0,
      prizePool: (data['prizePool'] as num?)?.toDouble() ?? 0.0,
      totalSlots: data['totalSlots'] ?? 100,
      joinedCount: data['joinedCount'] ?? 0,
      dateTime: data['dateTime'] ?? '',
      rules: data['rules'] ?? '',
      participants: List<String>.from(data['participants'] ?? []),
      status: data['status'] ?? 'upcoming',
      winnerName: data['winnerName'],
      map: data['map'] ?? 'Classic',
      startTime: data['startTime'] ?? '',
      endTime: data['endTime'] ?? '',
      registrationCloseTime: data['registrationCloseTime'] ?? '',
      roomId: data['roomId'] ?? 'TBD',
      roomPassword: data['roomPassword'] ?? 'TBD',
      approvedPlayers: List<String>.from(data['approvedPlayers'] ?? []),
      reportedIssues: reportsList,
      cancelled: data['cancelled'] ?? false,
      firstPlaceUid: data['firstPlaceUid'],
      secondPlaceUid: data['secondPlaceUid'],
      thirdPlaceUid: data['thirdPlaceUid'],
      killReward: (data['killReward'] as num?)?.toDouble() ?? 0.0,
      bonusEvents: data['bonusEvents'] ?? '',
      killStats: killStatsMap,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'gameName': gameName,
      'gameMode': gameMode,
      'entryFee': entryFee,
      'prizePool': prizePool,
      'totalSlots': totalSlots,
      'joinedCount': joinedCount,
      'dateTime': dateTime,
      'rules': rules,
      'participants': participants,
      'status': status,
      'winnerName': winnerName,
      'map': map,
      'startTime': startTime,
      'endTime': endTime,
      'registrationCloseTime': registrationCloseTime,
      'roomId': roomId,
      'roomPassword': roomPassword,
      'approvedPlayers': approvedPlayers,
      'reportedIssues': reportedIssues,
      'cancelled': cancelled,
      'firstPlaceUid': firstPlaceUid,
      'secondPlaceUid': secondPlaceUid,
      'thirdPlaceUid': thirdPlaceUid,
      'killReward': killReward,
      'bonusEvents': bonusEvents,
      'killStats': killStats,
    };
  }
}
