class UserProfile {
  final String uid;
  final String name;
  final String email;
  final String phone;
  final double walletBalance; // Main Wallet
  final double bonusBalance; // Bonus Wallet
  final double referralBalance; // Referral Wallet
  final bool isAdmin;
  final int joinedCount;
  final int wonCount;
  final double totalEarnings;
  final bool isBanned;
  final bool isOnline;
  final String referralCode;
  final String referredBy;

  UserProfile({
    required this.uid,
    required this.name,
    required this.email,
    required this.phone,
    required this.walletBalance,
    this.bonusBalance = 0.0,
    this.referralBalance = 0.0,
    required this.isAdmin,
    required this.joinedCount,
    required this.wonCount,
    required this.totalEarnings,
    this.isBanned = false,
    this.isOnline = false,
    this.referralCode = '',
    this.referredBy = '',
  });

  factory UserProfile.fromMap(Map<String, dynamic> data, String uid) {
    return UserProfile(
      uid: uid,
      name: data['name'] ?? 'Gamer',
      email: data['email'] ?? '',
      phone: data['phone'] ?? '',
      walletBalance: (data['walletBalance'] as num?)?.toDouble() ?? 0.0,
      bonusBalance: (data['bonusBalance'] as num?)?.toDouble() ?? 0.0,
      referralBalance: (data['referralBalance'] as num?)?.toDouble() ?? 0.0,
      isAdmin: data['isAdmin'] ?? false,
      joinedCount: data['joinedCount'] ?? 0,
      wonCount: data['wonCount'] ?? 0,
      totalEarnings: (data['totalEarnings'] as num?)?.toDouble() ?? 0.0,
      isBanned: data['isBanned'] ?? false,
      isOnline: data['isOnline'] ?? false,
      referralCode: data['referralCode'] ?? 'AST_${(data['name'] ?? 'GAMER').toString().replaceAll(' ', '').toUpperCase()}',
      referredBy: data['referredBy'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'walletBalance': walletBalance,
      'bonusBalance': bonusBalance,
      'referralBalance': referralBalance,
      'isAdmin': isAdmin,
      'joinedCount': joinedCount,
      'wonCount': wonCount,
      'totalEarnings': totalEarnings,
      'isBanned': isBanned,
      'isOnline': isOnline,
      'referralCode': referralCode,
      'referredBy': referredBy,
    };
  }
}
