class OfferApp {
  final String id;
  final String appName;
  final String logoUrl;
  final String downloadUrl;
  final double rewardAmount;
  final String packageName; // উদাহরণ: com.instagram.android (ইন্সটল চেক করার জন্য)

  OfferApp({
    required this.id,
    required this.appName,
    required this.logoUrl,
    required this.downloadUrl,
    required this.rewardAmount,
    required this.packageName,
  });

  factory OfferApp.fromMap(Map<String, dynamic> data, String documentId) {
    return OfferApp(
      id: documentId,
      appName: data['appName'] ?? '',
      logoUrl: data['logoUrl'] ?? '',
      downloadUrl: data['downloadUrl'] ?? '',
      rewardAmount: (data['rewardAmount'] as num?)?.toDouble() ?? 0.0,
      packageName: data['packageName'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'appName': appName,
      'logoUrl': logoUrl,
      'downloadUrl': downloadUrl,
      'rewardAmount': rewardAmount,
      'packageName': packageName,
    };
  }
}
