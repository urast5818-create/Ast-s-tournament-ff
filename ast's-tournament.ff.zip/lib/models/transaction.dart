class WalletTransaction {
  final String id;
  final String userId;
  final String type; // 'DEPOSIT', 'WITHDRAWAL', 'ENTRY_FEE', 'WINNINGS', 'BONUS', 'REFERRAL_CONVERT'
  final double amount;
  final String status; // 'PENDING', 'APPROVED', 'REJECTED', 'SUCCESS'
  final DateTime timestamp;
  final String description;
  final String? upiTxnId;
  final String walletType; // 'MAIN', 'BONUS', 'REFERRAL'

  WalletTransaction({
    required this.id,
    required this.userId,
    required this.type,
    required this.amount,
    required this.status,
    required this.timestamp,
    required this.description,
    this.upiTxnId,
    this.walletType = 'MAIN',
  });

  factory WalletTransaction.fromMap(Map<String, dynamic> data, String documentId) {
    return WalletTransaction(
      id: documentId,
      userId: data['userId'] ?? '',
      type: data['type'] ?? 'DEPOSIT',
      amount: (data['amount'] as num?)?.toDouble() ?? 0.0,
      status: data['status'] ?? 'PENDING',
      timestamp: data['timestamp'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(data['timestamp']) 
          : DateTime.now(),
      description: data['description'] ?? '',
      upiTxnId: data['upiTxnId'],
      walletType: data['walletType'] ?? 'MAIN',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'type': type,
      'amount': amount,
      'status': status,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'description': description,
      'upiTxnId': upiTxnId,
      'walletType': walletType,
    };
  }
}
