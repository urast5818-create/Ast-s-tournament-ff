import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/tournament.dart';
import '../models/user_profile.dart';
import '../models/transaction.dart';

class OfflineDbService {
  static final OfflineDbService _instance = OfflineDbService._internal();
  factory OfflineDbService() => _instance;
  OfflineDbService._internal();

  File? _cacheFile;

  Future<void> init() async {
    try {
      final directory = await getApplicationSupportDirectory();
      _cacheFile = File('${directory.path}/asts_tournament_offline_v1.json');
      if (!await _cacheFile!.exists()) {
        await _cacheFile!.create(recursive: true);
        await _cacheFile!.writeAsString(jsonEncode({
          'tournaments': [],
          'transactions': [],
          'user_profile': null,
          'notifications': [],
          'pending_actions': [],
        }));
      }
    } catch (e) {
      // Fallback or log if path_provider fails in a mock/test environment
      print('OfflineDbService init error: $e');
    }
  }

  Future<Map<String, dynamic>> _readCache() async {
    try {
      if (_cacheFile == null || !await _cacheFile!.exists()) {
        await init();
      }
      if (_cacheFile != null && await _cacheFile!.exists()) {
        final contents = await _cacheFile!.readAsString();
        return jsonDecode(contents) as Map<String, dynamic>;
      }
    } catch (e) {
      print('OfflineDbService readCache error: $e');
    }
    return {
      'tournaments': [],
      'transactions': [],
      'user_profile': null,
      'notifications': [],
      'pending_actions': [],
    };
  }

  Future<void> _writeCache(Map<String, dynamic> data) async {
    try {
      if (_cacheFile == null) {
        await init();
      }
      if (_cacheFile != null) {
        await _cacheFile!.writeAsString(jsonEncode(data));
      }
    } catch (e) {
      print('OfflineDbService writeCache error: $e');
    }
  }

  // --- Tournaments ---
  Future<void> saveTournaments(List<Tournament> list) async {
    final data = await _readCache();
    data['tournaments'] = list.map((t) => {'id': t.id, 'data': t.toMap()}).toList();
    await _writeCache(data);
  }

  Future<List<Tournament>> loadTournaments() async {
    final data = await _readCache();
    final list = data['tournaments'] as List? ?? [];
    return list.map((item) {
      final mapItem = item as Map<String, dynamic>;
      return Tournament.fromMap(mapItem['data'], mapItem['id']);
    }).toList();
  }

  // --- Transactions ---
  Future<void> saveTransactions(List<WalletTransaction> list) async {
    final data = await _readCache();
    data['transactions'] = list.map((t) => {'id': t.id, 'data': t.toMap()}).toList();
    await _writeCache(data);
  }

  Future<List<WalletTransaction>> loadTransactions() async {
    final data = await _readCache();
    final list = data['transactions'] as List? ?? [];
    return list.map((item) {
      final mapItem = item as Map<String, dynamic>;
      return WalletTransaction.fromMap(mapItem['data'], mapItem['id']);
    }).toList();
  }

  // --- Profile ---
  Future<void> saveUserProfile(UserProfile? profile) async {
    final data = await _readCache();
    data['user_profile'] = profile != null ? {'uid': profile.uid, 'data': profile.toMap()} : null;
    await _writeCache(data);
  }

  Future<UserProfile?> loadUserProfile() async {
    final data = await _readCache();
    final item = data['user_profile'];
    if (item == null) return null;
    final mapItem = item as Map<String, dynamic>;
    return UserProfile.fromMap(mapItem['data'], mapItem['uid']);
  }

  // --- Notifications ---
  Future<void> saveNotifications(List<String> notifications) async {
    final data = await _readCache();
    data['notifications'] = notifications;
    await _writeCache(data);
  }

  Future<List<String>> loadNotifications() async {
    final data = await _readCache();
    final list = data['notifications'] as List? ?? [];
    return List<String>.from(list);
  }

  // --- Pending Actions ---
  Future<void> savePendingActions(List<Map<String, dynamic>> actions) async {
    final data = await _readCache();
    data['pending_actions'] = actions;
    await _writeCache(data);
  }

  Future<List<Map<String, dynamic>>> loadPendingActions() async {
    final data = await _readCache();
    final list = data['pending_actions'] as List? ?? [];
    return list.map((item) => Map<String, dynamic>.from(item)).toList();
  }
}
