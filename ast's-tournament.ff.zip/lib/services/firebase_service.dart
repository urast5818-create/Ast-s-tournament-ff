import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import '../models/tournament.dart';
import '../models/user_profile.dart';
import '../models/transaction.dart';
import '../models/offer_app.dart';
import 'offline_db_service.dart';

class FirebaseService extends ChangeNotifier {
  // Auth state
  bool _isLoggedIn = false;
  String? _currentUserId;
  UserProfile? _currentUserProfile;
  bool _useMock = true; // Fallback simulation to guarantee zero crashes on startup

  // Connectivity
  bool _isOnline = true;
  final OfflineDbService _offlineDb = OfflineDbService();
  Timer? _connectivityTimer;

  // Pagination
  int _tournamentPage = 1;
  static const int _pageSize = 5;

  // Mock State Store
  final List<Tournament> _mockTournaments = [];
  final List<WalletTransaction> _mockTransactions = [];
  final List<UserProfile> _mockUsers = [];
  final List<String> _notifications = [];

  // স্পন্সর অ্যাপের অফার লিস্ট ট্র্যাক করার জন্য ভ্যারিয়েবল
  final List<OfferApp> _mockOffers = [
    OfferApp(
      id: 'off_01',
      appName: 'Telegram Messenger',
      logoUrl: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=100',
      downloadUrl: 'https://play.google.com/store/apps/details?id=org.telegram.messenger',
      rewardAmount: 20.0,
      packageName: 'org.telegram.messenger',
    ),
    OfferApp(
      id: 'off_02',
      appName: 'Garena Free Fire MAX',
      logoUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=100',
      downloadUrl: 'https://play.google.com/store/apps/details?id=com.dts.freefiremax',
      rewardAmount: 50.0,
      packageName: 'com.dts.freefiremax',
    ),
  ];

  List<OfferApp> get offers => _mockOffers;

  // অফার সাকসেসফুলি কমপ্লিট হলে ওয়ালেটে টাকা ক্রেডিট করার ফাংশন
  Future<String?> completeAppDownloadOffer(String offerId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    if (_currentUserProfile == null) return 'Please log in first.';

    final oIndex = _mockOffers.indexWhere((o) => o.id == offerId);
    if (oIndex == -1) return 'Offer not found.';
    final app = _mockOffers[oIndex];

    final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      
      // ইউজারের মেইন ওয়ালেটে অ্যাপ ডাউনলোডের টাকা যোগ হচ্ছে
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance + app.rewardAmount, // টাকা যোগ হলো
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings + app.rewardAmount,
        isBanned: oldUser.isBanned,
        isOnline: oldUser.isOnline,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      
      _mockUsers[uIndex] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);

      // ট্রানজেকশন লেজারে হিস্টোরি সেভ করা হচ্ছে
      _mockTransactions.insert(
        0,
        WalletTransaction(
          id: 'tx_${DateTime.now().millisecondsSinceEpoch}_offer_${app.id}',
          userId: _currentUserId!,
          type: 'WINNINGS',
          amount: app.rewardAmount,
          status: 'SUCCESS',
          timestamp: DateTime.now(),
          description: 'Completed Task: Installed ${app.appName}',
          walletType: 'MAIN',
        ),
      );
      _offlineDb.saveTransactions(_mockTransactions);
    }

    _addNotification('[TASK COMPLETED]  ${app.rewardAmount.toStringAsFixed(0)} credited for downloading ${app.appName}!');
    notifyListeners();
    return null; // Success
  }

  // অ্যাডমিন প্যানেল থেকে নতুন স্পন্সর অফার যোগ করার ফাংশন
  void addOffer(OfferApp offer) {
    _mockOffers.add(offer);
    notifyListeners();
  }

  // অ্যাডমিন প্যানেল থেকে স্পন্সর অফার রিমুভ করার ফাংশন
  void removeOffer(String offerId) {
    _mockOffers.removeWhere((o) => o.id == offerId);
    notifyListeners();
  }

  bool get isLoggedIn => _isLoggedIn;
  String? get currentUserId => _currentUserId;
  UserProfile? get currentUserProfile => _currentUserProfile;
  List<Tournament> get tournaments => _mockTournaments;
  List<WalletTransaction> get transactions => _mockTransactions;
  List<UserProfile> get users => _mockUsers;
  List<String> get notifications => _notifications;

  bool get isOnline => _isOnline;
  List<Tournament> get paginatedTournaments => _mockTournaments.take(_tournamentPage * _pageSize).toList();
  bool get hasMoreTournaments => _mockTournaments.length > (_tournamentPage * _pageSize);

  int get totalUsersCount => _mockUsers.length;
  int get onlineUsersCount => _mockUsers.where((u) => u.isOnline).length;
  int get totalTournamentsCount => _mockTournaments.length;
  double get totalRevenue => _mockTournaments.fold(0.0, (sum, t) => sum + (t.joinedCount * t.entryFee));
  int get pendingWithdrawRequestsCount => _mockTransactions.where((tx) => tx.type == 'WITHDRAWAL' && tx.status == 'PENDING').length;

  int get liveMatchesCount => _mockTournaments.where((t) => t.status == 'ongoing').length;
  int get upcomingMatchesCount => _mockTournaments.where((t) => t.status == 'upcoming').length;
  int get completedMatchesCount => _mockTournaments.where((t) => t.status == 'completed' && !t.cancelled).length;
  int get cancelledMatchesCount => _mockTournaments.where((t) => t.cancelled).length;

  double get totalWalletBalance => _mockUsers.fold(0.0, (sum, u) => sum + u.walletBalance + u.bonusBalance + u.referralBalance);
  double get totalDeposits => _mockTransactions.where((tx) => tx.type == 'DEPOSIT' && tx.status == 'SUCCESS').fold(0.0, (sum, tx) => sum + tx.amount);
  double get totalWithdrawals => _mockTransactions.where((tx) => tx.type == 'WITHDRAWAL' && tx.status == 'SUCCESS').fold(0.0, (sum, tx) => sum + tx.amount);

  // --- REWARDS SYSTEM: Coupons & Daily Check-in ---
  final List<Map<String, dynamic>> _mockCoupons = [
    {'code': 'WELCOME50', 'amount': 50.0, 'type': 'BONUS', 'redeemedBy': <String>[]},
    {'code': 'ASTFREE', 'amount': 10.0, 'type': 'BONUS', 'redeemedBy': <String>[]},
    {'code': 'PROPLAY30', 'amount': 30.0, 'type': 'BONUS', 'redeemedBy': <String>[]},
  ];

  List<Map<String, dynamic>> get coupons => _mockCoupons;

  final Map<String, String> _lastDailyClaimTimes = {};

  bool canClaimDailyReward() {
    if (_currentUserId == null) return false;
    final lastClaimStr = _lastDailyClaimTimes[_currentUserId];
    if (lastClaimStr == null || lastClaimStr.isEmpty) return true;
    try {
      final lastClaim = DateTime.parse(lastClaimStr);
      final difference = DateTime.now().difference(lastClaim);
      return difference.inHours >= 24;
    } catch (_) {
      return true;
    }
  }

  Future<String?> claimDailyReward() async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (_currentUserProfile == null) return 'Please log in first.';
    
    if (!canClaimDailyReward()) {
      return 'You have already claimed your daily reward today. Try again in 24 hours!';
    }
    
    final double rewardAmt = 5.0; // ₹5 Daily Bonus reward
    _lastDailyClaimTimes[_currentUserId!] = DateTime.now().toIso8601String();
    
    final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance,
        bonusBalance: oldUser.bonusBalance + rewardAmt,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        isBanned: oldUser.isBanned,
        isOnline: oldUser.isOnline,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIndex] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);
      
      // Save Transaction
      _mockTransactions.insert(
        0,
        WalletTransaction(
          id: 'tx_${DateTime.now().millisecondsSinceEpoch}_daily_claim',
          userId: _currentUserId!,
          type: 'BONUS',
          amount: rewardAmt,
          status: 'SUCCESS',
          timestamp: DateTime.now(),
          description: 'Daily Check-in Reward',
          walletType: 'BONUS',
        ),
      );
      _offlineDb.saveTransactions(_mockTransactions);
    }
    
    _addNotification('Claimed daily check-in reward! ₹${rewardAmt.toStringAsFixed(1)} added to your Bonus Wallet.');
    notifyListeners();
    return null; // success
  }

  Future<String?> redeemCouponCode(String code) async {
    await Future.delayed(const Duration(milliseconds: 400));
    if (_currentUserProfile == null) return 'Please log in first.';
    
    final couponIndex = _mockCoupons.indexWhere((c) => c['code'].toString().trim().toUpperCase() == code.trim().toUpperCase());
    if (couponIndex == -1) return 'Invalid Coupon Code. Please try another.';
    
    final coupon = _mockCoupons[couponIndex];
    final redeemedList = coupon['redeemedBy'] as List<String>;
    if (redeemedList.contains(_currentUserId)) {
      return 'You have already redeemed this Coupon Code.';
    }
    
    redeemedList.add(_currentUserId!);
    final double amt = coupon['amount'] as double;
    final String type = coupon['type'] as String;
    
    // Add to user balance
    final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: type == 'MAIN' ? oldUser.walletBalance + amt : oldUser.walletBalance,
        bonusBalance: type == 'BONUS' ? oldUser.bonusBalance + amt : oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        isBanned: oldUser.isBanned,
        isOnline: oldUser.isOnline,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIndex] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);
      
      // Save Transaction
      _mockTransactions.insert(
        0,
        WalletTransaction(
          id: 'tx_${DateTime.now().millisecondsSinceEpoch}_coupon_${code.toUpperCase()}',
          userId: _currentUserId!,
          type: 'BONUS',
          amount: amt,
          status: 'SUCCESS',
          timestamp: DateTime.now(),
          description: 'Redeemed Coupon: ${code.toUpperCase()}',
          walletType: type,
        ),
      );
      _offlineDb.saveTransactions(_mockTransactions);
    }
    
    _addNotification('Successfully redeemed coupon $code! ₹${amt.toStringAsFixed(1)} added to your wallet.');
    notifyListeners();
    return null; // success
  }

  void addCouponCode(String code, double amount, String type) {
    _mockCoupons.add({
      'code': code.trim().toUpperCase(),
      'amount': amount,
      'type': type,
      'redeemedBy': <String>[],
    });
    _addNotification('Admin created a new coupon code: ${code.toUpperCase()}');
    notifyListeners();
  }

  void deleteCouponCode(String code) {
    _mockCoupons.removeWhere((c) => c['code'].toString().toUpperCase() == code.trim().toUpperCase());
    _addNotification('Admin deleted coupon code: ${code.toUpperCase()}');
    notifyListeners();
  }

  FirebaseService() {
    _initializeData();
  }

  Future<void> _initializeData() async {
    // 1. Initialize Offline Database
    await _offlineDb.init();

    // 2. Load cached profile, tournaments, transactions, and notifications
    final cachedProfile = await _offlineDb.loadUserProfile();
    final cachedTournaments = await _offlineDb.loadTournaments();
    final cachedTransactions = await _offlineDb.loadTransactions();
    final cachedNotifications = await _offlineDb.loadNotifications();

    if (cachedProfile != null) {
      _currentUserProfile = cachedProfile;
      _currentUserId = cachedProfile.uid;
      _isLoggedIn = true;
    }

    if (cachedTournaments.isNotEmpty) {
      _mockTournaments.clear();
      _mockTournaments.addAll(cachedTournaments);
    } else {
      _seedDefaultTournaments();
    }

    if (cachedTransactions.isNotEmpty) {
      _mockTransactions.clear();
      _mockTransactions.addAll(cachedTransactions);
    } else {
      _seedDefaultTransactions();
    }

    if (cachedNotifications.isNotEmpty) {
      _notifications.clear();
      _notifications.addAll(cachedNotifications);
    } else {
      _seedDefaultNotifications();
    }

    // Seed sample users list for admin operations
    _seedDefaultUsers();

    // 3. Check connectivity initially and start loop
    await checkConnectivity();
    startConnectivityLoop();

    notifyListeners();
  }

  void _seedDefaultUsers() {
    _mockUsers.clear();
    _mockUsers.addAll([
      UserProfile(
        uid: 'user_123',
        name: 'AlphaGamer',
        email: 'urast5818@gmail.com',
        phone: '+919876543210',
        walletBalance: 250.0,
        bonusBalance: 50.0,
        referralBalance: 20.0,
        isAdmin: true,
        joinedCount: 2,
        wonCount: 1,
        totalEarnings: 150.0,
        isBanned: false,
        isOnline: true,
        referralCode: 'AST_ALPHAGAMER',
        referredBy: '',
      ),
      UserProfile(
        uid: 'user_456',
        name: 'OmegaSniper',
        email: 'omega@gamers.com',
        phone: '+919988776655',
        walletBalance: 120.0,
        bonusBalance: 10.0,
        referralBalance: 0.0,
        isAdmin: false,
        joinedCount: 1,
        wonCount: 0,
        totalEarnings: 0.0,
        isBanned: false,
        isOnline: true,
        referralCode: 'AST_OMEGASNIPER',
        referredBy: '',
      ),
      UserProfile(
        uid: 'user_789',
        name: 'DeltaPro',
        email: 'delta@gamers.com',
        phone: '+919888776655',
        walletBalance: 45.0,
        bonusBalance: 10.0,
        referralBalance: 0.0,
        isAdmin: false,
        joinedCount: 1,
        wonCount: 0,
        totalEarnings: 0.0,
        isBanned: false,
        isOnline: false,
        referralCode: 'AST_DELTAPRO',
        referredBy: 'user_123',
      ),
      UserProfile(
        uid: 'user_abc',
        name: 'PhoenixHero',
        email: 'phoenix@gamers.com',
        phone: '+919777665544',
        walletBalance: 80.0,
        bonusBalance: 10.0,
        referralBalance: 0.0,
        isAdmin: false,
        joinedCount: 0,
        wonCount: 0,
        totalEarnings: 0.0,
        isBanned: false,
        isOnline: true,
        referralCode: 'AST_PHOENIXHERO',
        referredBy: '',
      ),
      UserProfile(
        uid: 'user_xyz',
        name: 'ShadowViper',
        email: 'viper@gamers.com',
        phone: '+919666554433',
        walletBalance: 15.0,
        bonusBalance: 10.0,
        referralBalance: 0.0,
        isAdmin: false,
        joinedCount: 0,
        wonCount: 0,
        totalEarnings: 0.0,
        isBanned: true,
        isOnline: false,
        referralCode: 'AST_SHADOWVIPER',
        referredBy: '',
      ),
    ]);
  }

  void _seedDefaultTournaments() {
    _mockTournaments.clear();
    _mockTournaments.addAll([
      Tournament(
        id: 'bgmi_elite_01',
        title: 'BGMI Elite Pro Championship',
        gameName: 'BGMI',
        gameMode: 'Squad',
        entryFee: 50.0,
        prizePool: 5000.0,
        totalSlots: 100,
        joinedCount: 42,
        dateTime: '2026-07-20 18:00',
        rules: '1. Emulators are strictly prohibited.\n2. Hacks/Cheats will lead to instant disqualification.\n3. Screen recording is mandatory for top-3 squads.',
        participants: ['user_123', 'user_456'],
        status: 'upcoming',
        map: 'Erangel',
        startTime: '2026-07-20 18:00',
        endTime: '2026-07-20 21:00',
        registrationCloseTime: '2026-07-20 17:45',
        roomId: 'TBD',
        roomPassword: 'TBD',
        approvedPlayers: ['user_123'],
        reportedIssues: [],
        cancelled: false,
        killReward: 5.0,
        bonusEvents: 'MVP: \$50, Most Headshots: \$25',
        killStats: {},
      ),
      Tournament(
        id: 'freefire_clash_02',
        title: 'Free Fire Clash Squad Duel',
        gameName: 'Free Fire',
        gameMode: 'Solo',
        entryFee: 0.0,
        prizePool: 1000.0,
        totalSlots: 50,
        joinedCount: 49,
        dateTime: '2026-07-18 15:30',
        rules: '1. Standard rules apply.\n2. Standard map match.\n3. Winner takes all.',
        participants: ['user_456', 'user_789'],
        status: 'upcoming',
        map: 'Bermuda',
        startTime: '2026-07-18 15:30',
        endTime: '2026-07-18 17:00',
        registrationCloseTime: '2026-07-18 15:15',
        roomId: 'FF-88392',
        roomPassword: '992',
        approvedPlayers: ['user_456', 'user_789'],
        reportedIssues: [],
        cancelled: false,
        killReward: 2.0,
        bonusEvents: 'First Blood: \$10',
        killStats: {},
      ),
      Tournament(
        id: 'ludo_king_03',
        title: 'Ludo Stars Mega Tournament',
        gameName: 'Ludo King',
        gameMode: 'Solo',
        entryFee: 10.0,
        prizePool: 800.0,
        totalSlots: 32,
        joinedCount: 32,
        dateTime: '2026-07-16 12:00',
        rules: '1. Standard dice rolls.\n2. Toxicity not tolerated.',
        participants: ['user_123', 'user_789'],
        status: 'ongoing',
        map: 'Classic Board',
        startTime: '2026-07-16 12:00',
        endTime: '2026-07-16 13:30',
        registrationCloseTime: '2026-07-16 11:45',
        roomId: 'LUDO-742',
        roomPassword: 'pass',
        approvedPlayers: ['user_123', 'user_789'],
        reportedIssues: [
          {
            'id': 'rep_01',
            'userId': 'user_789',
            'userName': 'DeltaPro',
            'description': 'Opponent did not join the lobby after 10 mins.',
            'status': 'PENDING',
            'timestamp': '2026-07-15 14:30',
          }
        ],
        cancelled: false,
        killReward: 0.0,
        bonusEvents: 'Fastest Win: \$20',
        killStats: {},
      ),
      Tournament(
        id: 'cod_mobile_04',
        title: 'Call of Duty Mobile Open Cup',
        gameName: 'COD Mobile',
        gameMode: 'Duo',
        entryFee: 20.0,
        prizePool: 2000.0,
        totalSlots: 50,
        joinedCount: 50,
        dateTime: '2026-07-10 14:00',
        rules: 'Match successfully completed. Congratulations to winner team.',
        participants: ['user_123'],
        status: 'completed',
        winnerName: 'AlphaGamer',
        map: 'Crash',
        startTime: '2026-07-10 14:00',
        endTime: '2026-07-10 16:00',
        registrationCloseTime: '2026-07-10 13:45',
        roomId: 'COD-12932',
        roomPassword: 'completed_game',
        approvedPlayers: ['user_123'],
        reportedIssues: [],
        cancelled: false,
        killReward: 3.0,
        bonusEvents: '',
        killStats: {'user_123': 8},
      ),
    ]);
    _offlineDb.saveTournaments(_mockTournaments);
  }

  void _seedDefaultTransactions() {
    _mockTransactions.clear();
    _mockTransactions.addAll([
      WalletTransaction(
        id: 'tx_01',
        userId: 'user_123',
        type: 'DEPOSIT',
        amount: 200.0,
        status: 'SUCCESS',
        timestamp: DateTime.now().subtract(const Duration(days: 3)),
        description: 'UPI Deposit - Approved',
        upiTxnId: 'TXN1234567890',
      ),
      WalletTransaction(
        id: 'tx_02',
        userId: 'user_123',
        type: 'ENTRY_FEE',
        amount: 50.0,
        status: 'SUCCESS',
        timestamp: DateTime.now().subtract(const Duration(days: 2)),
        description: 'Registration: BGMI Elite Pro Championship',
      ),
      WalletTransaction(
        id: 'tx_03',
        userId: 'user_123',
        type: 'WINNINGS',
        amount: 150.0,
        status: 'SUCCESS',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
        description: 'Prize Winnings: COD Mobile Open Cup',
      ),
      WalletTransaction(
        id: 'tx_04',
        userId: 'user_123',
        type: 'WITHDRAWAL',
        amount: 50.0,
        status: 'PENDING',
        timestamp: DateTime.now(),
        description: 'Bank Withdrawal Request',
        upiTxnId: 'withdraw_target@upi',
      )
    ]);
    _offlineDb.saveTransactions(_mockTransactions);
  }

  void _seedDefaultNotifications() {
    _notifications.clear();
    _notifications.addAll([
      'Welcome to Ast\'s Tournament App! Start your gaming journey today.',
      'Notification: Your withdrawal request of $50.00 is currently under review.',
      'Match Alert: "Ludo Stars Mega Tournament" is now live. Join lobby ASAP.',
      'Congratulations! You won $150.00 in the Call of Duty Mobile Open Cup!'
    ]);
    _offlineDb.saveNotifications(_notifications);
  }

  // --- Connectivity Checker Loop ---
  void startConnectivityLoop() {
    _connectivityTimer?.cancel();
    _connectivityTimer = Timer.periodic(const Duration(seconds: 4), (timer) async {
      await checkConnectivity();
    });
  }

  Future<void> checkConnectivity() async {
    final prevStatus = _isOnline;
    try {
      final result = await InternetAddress.lookup('google.com').timeout(const Duration(seconds: 3));
      _isOnline = result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } catch (_) {
      _isOnline = false;
    }
    if (prevStatus != _isOnline) {
      notifyListeners();
      if (_isOnline) {
        _addNotification('Internet connection restored. Syncing offline changes...');
        _syncPendingActions();
      }
    }
  }

  @override
  void dispose() {
    _connectivityTimer?.cancel();
    super.dispose();
  }

  // --- Pagination Actions ---
  Future<void> loadMoreTournaments() async {
    if (!hasMoreTournaments) return;
    await Future.delayed(const Duration(milliseconds: 300));
    _tournamentPage++;
    notifyListeners();
  }

  // --- Authentication Actions ---

  Future<bool> loginWithEmail(String email, String password, {String referralCodeInput = ''}) async {
    await Future.delayed(const Duration(milliseconds: 600));
    final index = _mockUsers.indexWhere((u) => u.email.toLowerCase() == email.toLowerCase());
    if (index != -1) {
      _isLoggedIn = true;
      _currentUserId = _mockUsers[index].uid;
      _currentUserProfile = _mockUsers[index];
    } else {
      // Find referrer uid if a referral code was inputted
      String referrerUid = '';
      if (referralCodeInput.isNotEmpty) {
        final refIdx = _mockUsers.indexWhere((u) => u.referralCode.trim().toUpperCase() == referralCodeInput.trim().toUpperCase());
        if (refIdx != -1) {
          referrerUid = _mockUsers[refIdx].uid;
        }
      }

      // Auto-create new account
      final newUser = UserProfile(
        uid: 'user_${DateTime.now().millisecondsSinceEpoch}',
        name: email.split('@').first,
        email: email,
        phone: '',
        walletBalance: 0.0, // Initial Main is 0
        bonusBalance: 10.0, // ₹10 Welcome Bonus
        referralBalance: 0.0,
        isAdmin: email.contains('admin') ? true : false,
        joinedCount: 0,
        wonCount: 0,
        totalEarnings: 0.0,
        referralCode: 'AST_${email.split('@').first.toString().replaceAll(' ', '').toUpperCase()}',
        referredBy: referrerUid,
      );
      _mockUsers.add(newUser);
      _isLoggedIn = true;
      _currentUserId = newUser.uid;
      _currentUserProfile = newUser;

      // Welcome Bonus Transaction
      final bonusTx = WalletTransaction(
        id: 'tx_${DateTime.now().millisecondsSinceEpoch}_welcome',
        userId: newUser.uid,
        type: 'BONUS',
        amount: 10.0,
        status: 'SUCCESS',
        timestamp: DateTime.now(),
        description: 'Welcome Bonus',
        walletType: 'BONUS',
      );
      _mockTransactions.insert(0, bonusTx);
      _offlineDb.saveTransactions(_mockTransactions);
    }
    _offlineDb.saveUserProfile(_currentUserProfile);
    notifyListeners();
    return true;
  }

  Future<bool> loginWithPhone(String phoneNumber, {String referralCodeInput = ''}) async {
    await Future.delayed(const Duration(milliseconds: 600));
    final index = _mockUsers.indexWhere((u) => u.phone == phoneNumber);
    if (index != -1) {
      _isLoggedIn = true;
      _currentUserId = _mockUsers[index].uid;
      _currentUserProfile = _mockUsers[index];
    } else {
      String referrerUid = '';
      if (referralCodeInput.isNotEmpty) {
        final refIdx = _mockUsers.indexWhere((u) => u.referralCode.trim().toUpperCase() == referralCodeInput.trim().toUpperCase());
        if (refIdx != -1) {
          referrerUid = _mockUsers[refIdx].uid;
        }
      }

      final newUser = UserProfile(
        uid: 'user_${DateTime.now().millisecondsSinceEpoch}',
        name: 'Gamer_${phoneNumber.substring(phoneNumber.length - 4)}',
        email: '',
        phone: phoneNumber,
        walletBalance: 0.0,
        bonusBalance: 10.0, // ₹10 Welcome Bonus
        referralBalance: 0.0,
        isAdmin: false,
        joinedCount: 0,
        wonCount: 0,
        totalEarnings: 0.0,
        referralCode: 'AST_${phoneNumber.substring(phoneNumber.length - 4)}',
        referredBy: referrerUid,
      );
      _mockUsers.add(newUser);
      _isLoggedIn = true;
      _currentUserId = newUser.uid;
      _currentUserProfile = newUser;

      // Welcome Bonus Transaction
      final bonusTx = WalletTransaction(
        id: 'tx_${DateTime.now().millisecondsSinceEpoch}_welcome',
        userId: newUser.uid,
        type: 'BONUS',
        amount: 10.0,
        status: 'SUCCESS',
        timestamp: DateTime.now(),
        description: 'Welcome Bonus',
        walletType: 'BONUS',
      );
      _mockTransactions.insert(0, bonusTx);
      _offlineDb.saveTransactions(_mockTransactions);
    }
    _offlineDb.saveUserProfile(_currentUserProfile);
    notifyListeners();
    return true;
  }

  void logout() {
    _isLoggedIn = false;
    _currentUserId = null;
    _currentUserProfile = null;
    _offlineDb.saveUserProfile(null);
    notifyListeners();
  }

  Future<String?> applyReferralCode(String code) async {
    await Future.delayed(const Duration(milliseconds: 400));
    if (_currentUserProfile == null) return 'Not logged in';
    if (_currentUserProfile!.referredBy.isNotEmpty) return 'Referral code already applied!';
    
    final refIdx = _mockUsers.indexWhere((u) => u.referralCode.trim().toUpperCase() == code.trim().toUpperCase());
    if (refIdx == -1) return 'Invalid Referral Code. Please check the code.';
    
    final referrer = _mockUsers[refIdx];
    if (referrer.uid == _currentUserId) return 'You cannot refer yourself.';
    
    // Update current user referredBy
    final uIdx = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIdx != -1) {
      final oldUser = _mockUsers[uIdx];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance,
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        referralCode: oldUser.referralCode,
        referredBy: referrer.uid,
      );
      _mockUsers[uIdx] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);
    }
    
    _addNotification('Referral code applied! You will receive your bonus, and your referrer will be rewarded on your first paid match registration.');
    notifyListeners();
    return null; // success
  }

  Future<String?> convertReferralBalanceToMain(double amount) async {
    await Future.delayed(const Duration(milliseconds: 400));
    if (_currentUserProfile == null) return 'Not logged in';
    if (amount <= 0) return 'Invalid amount';
    if (_currentUserProfile!.referralBalance < amount) return 'Insufficient referral wallet balance.';
    
    final uIdx = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIdx != -1) {
      final oldUser = _mockUsers[uIdx];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance + amount,
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance - amount,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIdx] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);
      
      // Log transaction
      final tx = WalletTransaction(
        id: 'tx_${DateTime.now().millisecondsSinceEpoch}_ref_convert',
        userId: _currentUserId!,
        type: 'REFERRAL_CONVERT',
        amount: amount,
        status: 'SUCCESS',
        timestamp: DateTime.now(),
        description: 'Converted from Referral Wallet',
        walletType: 'MAIN',
      );
      _mockTransactions.insert(0, tx);
      _offlineDb.saveTransactions(_mockTransactions);
    }
    _addNotification('Converted ₹${amount.toStringAsFixed(2)} to Main Wallet cash!');
    notifyListeners();
    return null;
  }

  String getUserNameByUid(String uid) {
    final idx = _mockUsers.indexWhere((u) => u.uid == uid);
    if (idx != -1) {
      return _mockUsers[idx].name;
    }
    if (uid == 'user_123') return 'AlphaGamer';
    if (uid == 'user_456') return 'OmegaSniper';
    if (uid == 'user_789') return 'DeltaPro';
    if (uid == 'user_abc') return 'PhoenixHero';
    if (uid.length > 8) {
      return 'Gamer_${uid.substring(uid.length - 4)}';
    }
    return 'Gamer_$uid';
  }

  // --- Tournament Actions ---

  Future<bool> createTournament(Tournament tournament) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _mockTournaments.insert(0, tournament);
    _offlineDb.saveTournaments(_mockTournaments);
    _addNotification('New tournament "${tournament.title}" created with prize pool of ₹${tournament.prizePool}!');
    notifyListeners();
    return true;
  }

  Future<bool> updateTournament(Tournament updated) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final idx = _mockTournaments.indexWhere((t) => t.id == updated.id);
    if (idx != -1) {
      _mockTournaments[idx] = updated;
      _offlineDb.saveTournaments(_mockTournaments);
      _addNotification('Tournament "${updated.title}" was updated by Admin.');
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<bool> deleteTournament(String tournamentId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final idx = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (idx != -1) {
      final name = _mockTournaments[idx].title;
      _mockTournaments.removeAt(idx);
      _offlineDb.saveTournaments(_mockTournaments);
      _addNotification('Tournament "$name" was deleted by Admin.');
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<String?> joinTournament(String tournamentId) async {
    await Future.delayed(const Duration(milliseconds: 600));
    if (_currentUserProfile == null) return 'Session expired. Please log in again.';

    final tIndex = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (tIndex == -1) return 'Tournament not found.';

    final tournament = _mockTournaments[tIndex];

    if (tournament.cancelled) {
      return 'This tournament has been cancelled.';
    }

    if (tournament.registrationCloseTime.isNotEmpty) {
      try {
        final closeTime = DateTime.parse(tournament.registrationCloseTime);
        if (DateTime.now().isAfter(closeTime)) {
          return 'Registration has closed for this tournament.';
        }
      } catch (_) {
        // Safe fallback if date parsing fails
      }
    }

    if (tournament.participants.contains(_currentUserId)) {
      return 'You have already joined this tournament.';
    }

    if (tournament.joinedCount >= tournament.totalSlots) {
      return 'No slots available. This tournament is full.';
    }

    final fee = tournament.entryFee;
    double bonusDeducted = 0.0;
    double mainDeducted = 0.0;

    if (fee > 0) {
      final totalAvail = _currentUserProfile!.walletBalance + _currentUserProfile!.bonusBalance;
      if (totalAvail < fee) {
        return 'Insufficient wallet balance. Please add money in the Wallet screen.';
      }

      double remainingFee = fee;
      final currentBonus = _currentUserProfile!.bonusBalance;
      final currentMain = _currentUserProfile!.walletBalance;

      if (currentBonus >= remainingFee) {
        bonusDeducted = remainingFee;
        remainingFee = 0.0;
      } else {
        bonusDeducted = currentBonus;
        remainingFee -= currentBonus;
      }

      if (remainingFee > 0.0) {
        mainDeducted = remainingFee;
        remainingFee = 0.0;
      }

      // Update user balances in the mock list
      final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
      if (uIndex != -1) {
        final oldUser = _mockUsers[uIndex];
        final updatedUser = UserProfile(
          uid: oldUser.uid,
          name: oldUser.name,
          email: oldUser.email,
          phone: oldUser.phone,
          walletBalance: oldUser.walletBalance - mainDeducted,
          bonusBalance: oldUser.bonusBalance - bonusDeducted,
          referralBalance: oldUser.referralBalance,
          isAdmin: oldUser.isAdmin,
          joinedCount: oldUser.joinedCount + 1,
          wonCount: oldUser.wonCount,
          totalEarnings: oldUser.totalEarnings,
          referralCode: oldUser.referralCode,
          referredBy: oldUser.referredBy,
        );
        _mockUsers[uIndex] = updatedUser;
        _currentUserProfile = updatedUser;
        _offlineDb.saveUserProfile(updatedUser);
      }

      // Add corresponding transaction ledger entries
      if (bonusDeducted > 0) {
        _mockTransactions.insert(
          0,
          WalletTransaction(
            id: 'tx_${DateTime.now().millisecondsSinceEpoch}_bonus',
            userId: _currentUserId!,
            type: 'ENTRY_FEE',
            amount: bonusDeducted,
            status: 'SUCCESS',
            timestamp: DateTime.now(),
            description: 'Entry fee (Bonus): ${tournament.title}',
            walletType: 'BONUS',
          ),
        );
      }
      if (mainDeducted > 0) {
        _mockTransactions.insert(
          0,
          WalletTransaction(
            id: 'tx_${DateTime.now().millisecondsSinceEpoch}_main',
            userId: _currentUserId!,
            type: 'ENTRY_FEE',
            amount: mainDeducted,
            status: 'SUCCESS',
            timestamp: DateTime.now(),
            description: 'Entry fee (Main): ${tournament.title}',
            walletType: 'MAIN',
          ),
        );
      }
      _offlineDb.saveTransactions(_mockTransactions);

      // --- REFERRAL REWARD TRIGGER ---
      // If this is their first paid match, reward their referrer (if any) with ₹5
      final pastPaidCount = _mockTransactions.where((tx) => tx.userId == _currentUserId && tx.type == 'ENTRY_FEE').length - (bonusDeducted > 0 ? 1 : 0) - (mainDeducted > 0 ? 1 : 0);
      if (pastPaidCount == 0 && _currentUserProfile!.referredBy.isNotEmpty) {
        final referrerUid = _currentUserProfile!.referredBy;
        final refUserIdx = _mockUsers.indexWhere((u) => u.uid == referrerUid);
        if (refUserIdx != -1) {
          final oldRefUser = _mockUsers[refUserIdx];
          final updatedRefUser = UserProfile(
            uid: oldRefUser.uid,
            name: oldRefUser.name,
            email: oldRefUser.email,
            phone: oldRefUser.phone,
            walletBalance: oldRefUser.walletBalance,
            bonusBalance: oldRefUser.bonusBalance,
            referralBalance: oldRefUser.referralBalance + 5.0, // ₹5 Referral reward
            isAdmin: oldRefUser.isAdmin,
            joinedCount: oldRefUser.joinedCount,
            wonCount: oldRefUser.wonCount,
            totalEarnings: oldRefUser.totalEarnings + 5.0,
            referralCode: oldRefUser.referralCode,
            referredBy: oldRefUser.referredBy,
          );
          _mockUsers[refUserIdx] = updatedRefUser;

          // Save in transactions for referrer
          _mockTransactions.insert(
            0,
            WalletTransaction(
              id: 'tx_${DateTime.now().millisecondsSinceEpoch}_ref_reward',
              userId: referrerUid,
              type: 'WINNINGS',
              amount: 5.0,
              status: 'SUCCESS',
              timestamp: DateTime.now(),
              description: 'Referral reward: ${_currentUserProfile!.name} joined',
              walletType: 'REFERRAL',
            ),
          );
          _offlineDb.saveTransactions(_mockTransactions);

          // Trigger Push notification to referrer
          _addNotification('[PUSH NOTIFICATION] You earned ₹5! Your referred friend ${_currentUserProfile!.name} successfully registered for a paid tournament.');
        }
      }
    } else {
      // Free tournament
      final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
      if (uIndex != -1) {
        final oldUser = _mockUsers[uIndex];
        final updatedUser = UserProfile(
          uid: oldUser.uid,
          name: oldUser.name,
          email: oldUser.email,
          phone: oldUser.phone,
          walletBalance: oldUser.walletBalance,
          bonusBalance: oldUser.bonusBalance,
          referralBalance: oldUser.referralBalance,
          isAdmin: oldUser.isAdmin,
          joinedCount: oldUser.joinedCount + 1,
          wonCount: oldUser.wonCount,
          totalEarnings: oldUser.totalEarnings,
          referralCode: oldUser.referralCode,
          referredBy: oldUser.referredBy,
        );
        _mockUsers[uIndex] = updatedUser;
        _currentUserProfile = updatedUser;
        _offlineDb.saveUserProfile(updatedUser);
      }
    }

    // Update tournament
    tournament.participants.add(_currentUserId!);
    tournament.joinedCount += 1;
    _offlineDb.saveTournaments(_mockTournaments);

    _addNotification('Successfully joined tournament: ${tournament.title}');

    if (!_isOnline) {
      _addNotification('You are offline. Registration saved and will sync when online.');
      _queuePendingAction('join', {'tournamentId': tournamentId});
    }

    notifyListeners();
    return null; // success
  }

  // --- Wallet Operations ---

  Future<void> submitDepositRequest(double amount, String upiTxnId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final newTx = WalletTransaction(
      id: 'tx_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUserId!,
      type: 'DEPOSIT',
      amount: amount,
      status: 'PENDING',
      timestamp: DateTime.now(),
      description: 'UPI Deposit Request',
      upiTxnId: upiTxnId,
    );
    _mockTransactions.insert(0, newTx);
    _offlineDb.saveTransactions(_mockTransactions);
    _addNotification('Deposit request of ₹${amount.toStringAsFixed(2)} submitted. Pending admin approval.');

    if (!_isOnline) {
      _addNotification('Offline deposit logged. Will sync when online.');
      _queuePendingAction('deposit', {'amount': amount, 'upiTxnId': upiTxnId});
    }

    notifyListeners();
  }

  Future<void> makeInstantDeposit({
    required double amount,
    required String gatewayTxnId,
    required String orderId,
    required String paymentMethod,
  }) async {
    await Future.delayed(const Duration(milliseconds: 600));
    if (_currentUserProfile == null) return;

    final newTx = WalletTransaction(
      id: gatewayTxnId,
      userId: _currentUserId!,
      type: 'DEPOSIT',
      amount: amount,
      status: 'SUCCESS',
      timestamp: DateTime.now(),
      description: 'Deposit: $paymentMethod ($orderId)',
      upiTxnId: gatewayTxnId,
    );

    _mockTransactions.insert(0, newTx);
    _offlineDb.saveTransactions(_mockTransactions);

    // Credit to Main Wallet
    final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance + amount,
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIndex] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);
    }

    // Success push notification
    _addNotification('[PUSH NOTIFICATION] Deposit Successful: ₹${amount.toStringAsFixed(2)} credited to your Main Wallet.');
    notifyListeners();
  }

  Future<void> submitWithdrawalRequest(double amount, String upiId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final newTx = WalletTransaction(
      id: 'tx_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUserId!,
      type: 'WITHDRAWAL',
      amount: amount,
      status: 'PENDING',
      timestamp: DateTime.now(),
      description: 'Withdrawal to $upiId',
      upiTxnId: upiId,
    );
    _mockTransactions.insert(0, newTx);
    _offlineDb.saveTransactions(_mockTransactions);

    // Deduct pending balance to avoid double spending
    final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance - amount,
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIndex] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);
    }

    _addNotification('Withdrawal request of \$${amount.toStringAsFixed(2)} submitted successfully.');

    if (!_isOnline) {
      _addNotification('Offline withdrawal request logged. Will sync when online.');
      _queuePendingAction('withdrawal', {'amount': amount, 'upiId': upiId});
    }

    notifyListeners();
  }

  // --- Admin Panel Operations ---

  Future<void> approveTransaction(String txnId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final index = _mockTransactions.indexWhere((tx) => tx.id == txnId);
    if (index == -1) return;

    final txn = _mockTransactions[index];
    final updatedTxn = WalletTransaction(
      id: txn.id,
      userId: txn.userId,
      type: txn.type,
      amount: txn.amount,
      status: 'SUCCESS',
      timestamp: txn.timestamp,
      description: txn.description,
      upiTxnId: txn.upiTxnId,
    );
    _mockTransactions[index] = updatedTxn;
    _offlineDb.saveTransactions(_mockTransactions);

    // If it's a deposit, add to user balance
    if (txn.type == 'DEPOSIT') {
      final uIndex = _mockUsers.indexWhere((u) => u.uid == txn.userId);
      if (uIndex != -1) {
        final oldUser = _mockUsers[uIndex];
        final updatedUser = UserProfile(
          uid: oldUser.uid,
          name: oldUser.name,
          email: oldUser.email,
          phone: oldUser.phone,
          walletBalance: oldUser.walletBalance + txn.amount,
          bonusBalance: oldUser.bonusBalance,
          referralBalance: oldUser.referralBalance,
          isAdmin: oldUser.isAdmin,
          joinedCount: oldUser.joinedCount,
          wonCount: oldUser.wonCount,
          totalEarnings: oldUser.totalEarnings,
          referralCode: oldUser.referralCode,
          referredBy: oldUser.referredBy,
        );
        _mockUsers[uIndex] = updatedUser;
        if (_currentUserId == txn.userId) {
          _currentUserProfile = updatedUser;
          _offlineDb.saveUserProfile(updatedUser);
        }
      }
    }
    // If it's a withdrawal, the amount was already deducted on request creation, so we just mark it SUCCESS.
    
    _addNotification('Transaction approved by admin.');
    notifyListeners();
  }

  Future<void> rejectTransaction(String txnId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final index = _mockTransactions.indexWhere((tx) => tx.id == txnId);
    if (index == -1) return;

    final txn = _mockTransactions[index];
    final updatedTxn = WalletTransaction(
      id: txn.id,
      userId: txn.userId,
      type: txn.type,
      amount: txn.amount,
      status: 'REJECTED',
      timestamp: txn.timestamp,
      description: 'Rejected: ${txn.description}',
      upiTxnId: txn.upiTxnId,
    );
    _mockTransactions[index] = updatedTxn;
    _offlineDb.saveTransactions(_mockTransactions);

    // Refund if it was a withdrawal
    if (txn.type == 'WITHDRAWAL') {
      final uIndex = _mockUsers.indexWhere((u) => u.uid == txn.userId);
      if (uIndex != -1) {
        final oldUser = _mockUsers[uIndex];
        final updatedUser = UserProfile(
          uid: oldUser.uid,
          name: oldUser.name,
          email: oldUser.email,
          phone: oldUser.phone,
          walletBalance: oldUser.walletBalance + txn.amount,
          bonusBalance: oldUser.bonusBalance,
          referralBalance: oldUser.referralBalance,
          isAdmin: oldUser.isAdmin,
          joinedCount: oldUser.joinedCount,
          wonCount: oldUser.wonCount,
          totalEarnings: oldUser.totalEarnings,
          referralCode: oldUser.referralCode,
          referredBy: oldUser.referredBy,
        );
        _mockUsers[uIndex] = updatedUser;
        if (_currentUserId == txn.userId) {
          _currentUserProfile = updatedUser;
          _offlineDb.saveUserProfile(updatedUser);
        }
      }
    }

    _addNotification('Transaction request was rejected by admin.');
    notifyListeners();
  }

  Future<void> declareWinner(String tournamentId, String winnerUid) async {
    // Simple wrapper that publishes standard results with 100% of the prize pool going to the winner
    await publishResults(
      tournamentId: tournamentId,
      firstPlaceUid: winnerUid,
      secondPlaceUid: '',
      thirdPlaceUid: '',
      killReward: 0.0,
      killStats: {},
      bonusWinnerUid: '',
      bonusAmount: 0.0,
      bonusDescription: '',
    );
  }

  Future<void> publishResults({
    required String tournamentId,
    required String firstPlaceUid,
    required String secondPlaceUid,
    required String thirdPlaceUid,
    required double killReward,
    required Map<String, int> killStats,
    required String bonusWinnerUid,
    required double bonusAmount,
    required String bonusDescription,
  }) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final tIndex = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (tIndex == -1) return;

    final tournament = _mockTournaments[tIndex];

    tournament.status = 'completed';
    tournament.firstPlaceUid = firstPlaceUid.isNotEmpty ? firstPlaceUid : null;
    tournament.secondPlaceUid = secondPlaceUid.isNotEmpty ? secondPlaceUid : null;
    tournament.thirdPlaceUid = thirdPlaceUid.isNotEmpty ? thirdPlaceUid : null;
    tournament.killReward = killReward;
    tournament.killStats = killStats;
    tournament.bonusEvents = bonusAmount > 0 ? '$bonusDescription: ₹$bonusAmount' : '';

    // Set general winner name
    final wIndex = _mockUsers.indexWhere((u) => u.uid == firstPlaceUid);
    tournament.winnerName = wIndex != -1 ? _mockUsers[wIndex].name : 'Unknown';

    // Calculate and credit prizes
    // 1st Place: 60% of prize pool
    // 2nd Place: 25% of prize pool
    // 3rd Place: 15% of prize pool
    final firstPrize = tournament.prizePool * 0.60;
    final secondPrize = tournament.prizePool * 0.25;
    final thirdPrize = tournament.prizePool * 0.15;

    // Credit placements
    _creditUserPrize(firstPlaceUid, firstPrize, '1st Place: ${tournament.title}');
    _creditUserPrize(secondPlaceUid, secondPrize, '2nd Place: ${tournament.title}');
    _creditUserPrize(thirdPlaceUid, thirdPrize, '3rd Place: ${tournament.title}');

    // Credit Kill Rewards
    killStats.forEach((uId, kills) {
      if (kills > 0 && killReward > 0) {
        final reward = kills * killReward;
        _creditUserPrize(uId, reward, '$kills Kills Reward: ${tournament.title}');
      }
    });

    // Credit Bonus Event
    if (bonusWinnerUid.isNotEmpty && bonusAmount > 0) {
      _creditUserPrize(bonusWinnerUid, bonusAmount, 'Bonus ($bonusDescription): ${tournament.title}');
    }

    _offlineDb.saveTournaments(_mockTournaments);
    _offlineDb.saveTransactions(_mockTransactions);

    _addNotification('[PUSH NOTIFICATION] Results published for "${tournament.title}". Winners credited successfully!');
    notifyListeners();
  }

  void _creditUserPrize(String uId, double amount, String description) {
    if (uId.isEmpty || amount <= 0) return;
    final uIndex = _mockUsers.indexWhere((u) => u.uid == uId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance + amount,
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount + 1,
        totalEarnings: oldUser.totalEarnings + amount,
        isBanned: oldUser.isBanned,
        isOnline: oldUser.isOnline,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIndex] = updatedUser;
      if (_currentUserId == uId) {
        _currentUserProfile = updatedUser;
        _offlineDb.saveUserProfile(updatedUser);
      }

      // Save in wallet history
      _mockTransactions.insert(
        0,
        WalletTransaction(
          id: 'tx_${DateTime.now().millisecondsSinceEpoch}_prize_${uId}_${amount.toInt()}',
          userId: uId,
          type: 'WINNINGS',
          amount: amount,
          status: 'SUCCESS',
          timestamp: DateTime.now(),
          description: description,
        ),
      );
    }
  }

  Future<void> cancelTournament(String tournamentId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final index = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (index == -1) return;
    final t = _mockTournaments[index];
    t.cancelled = true;
    t.status = 'completed'; // Treat completed/cancelled safely so it doesn't show in active registration lists

    // Refund entry fees to everyone
    final fee = t.entryFee;
    if (fee > 0) {
      for (final pId in t.participants) {
        final uIndex = _mockUsers.indexWhere((u) => u.uid == pId);
        if (uIndex != -1) {
          final oldUser = _mockUsers[uIndex];
          final updatedUser = UserProfile(
            uid: oldUser.uid,
            name: oldUser.name,
            email: oldUser.email,
            phone: oldUser.phone,
            walletBalance: oldUser.walletBalance + fee,
            bonusBalance: oldUser.bonusBalance,
            referralBalance: oldUser.referralBalance,
            isAdmin: oldUser.isAdmin,
            joinedCount: oldUser.joinedCount,
            wonCount: oldUser.wonCount,
            totalEarnings: oldUser.totalEarnings,
            isBanned: oldUser.isBanned,
            isOnline: oldUser.isOnline,
            referralCode: oldUser.referralCode,
            referredBy: oldUser.referredBy,
          );
          _mockUsers[uIndex] = updatedUser;
          if (_currentUserId == pId) {
            _currentUserProfile = updatedUser;
            _offlineDb.saveUserProfile(updatedUser);
          }

          // Create refund transaction
          _mockTransactions.insert(
            0,
            WalletTransaction(
              id: 'tx_${DateTime.now().millisecondsSinceEpoch}_ref_$pId',
              userId: pId,
              type: 'REFUND',
              amount: fee,
              status: 'SUCCESS',
              timestamp: DateTime.now(),
              description: 'Refund: Cancelled Match "${t.title}"',
            ),
          );
        }
      }
    }
    _offlineDb.saveTransactions(_mockTransactions);
    _offlineDb.saveTournaments(_mockTournaments);
    _addNotification('[PUSH NOTIFICATION] Tournament "${t.title}" has been cancelled. Entry fees refunded to your wallet.');
    notifyListeners();
  }

  Future<void> approvePlayer(String tournamentId, String userUid) async {
    final index = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (index != -1) {
      final t = _mockTournaments[index];
      if (!t.approvedPlayers.contains(userUid)) {
        t.approvedPlayers.add(userUid);
        _offlineDb.saveTournaments(_mockTournaments);
        
        // Push notification mock
        _addNotification('[PUSH NOTIFICATION] You are APPROVED for the tournament "${t.title}"!');
        notifyListeners();
      }
    }
  }

  Future<void> uploadRoomCredentials(String tournamentId, String roomId, String password) async {
    final index = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (index != -1) {
      final t = _mockTournaments[index];
      t.roomId = roomId;
      t.roomPassword = password;
      _offlineDb.saveTournaments(_mockTournaments);
      
      // Push notification mock to approved players
      _addNotification('[PUSH NOTIFICATION] Room ID & Password published for match "${t.title}": ID: $roomId, Pass: $password');
      notifyListeners();
    }
  }

  Future<void> reportMatchIssue(String tournamentId, String description) async {
    if (_currentUserProfile == null) return;
    final index = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (index != -1) {
      final t = _mockTournaments[index];
      final report = {
        'id': 'rep_${DateTime.now().millisecondsSinceEpoch}',
        'userId': _currentUserId!,
        'userName': _currentUserProfile!.name,
        'description': description,
        'status': 'PENDING',
        'timestamp': DateTime.now().toString().substring(0, 16),
      };
      t.reportedIssues.add(report);
      _offlineDb.saveTournaments(_mockTournaments);
      _addNotification('Your match issue report has been submitted to the admin.');
      notifyListeners();
    }
  }

  Future<void> resolveReportedIssue(String tournamentId, String reportId) async {
    final index = _mockTournaments.indexWhere((t) => t.id == tournamentId);
    if (index != -1) {
      final t = _mockTournaments[index];
      final repIndex = t.reportedIssues.indexWhere((r) => r['id'] == reportId);
      if (repIndex != -1) {
        t.reportedIssues[repIndex]['status'] = 'RESOLVED';
        _offlineDb.saveTournaments(_mockTournaments);
        _addNotification('Report $reportId has been resolved.');
        notifyListeners();
      }
    }
  }

  Future<void> toggleUserBan(String uId) async {
    final uIndex = _mockUsers.indexWhere((u) => u.uid == uId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: oldUser.name,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance,
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        isBanned: !oldUser.isBanned,
        isOnline: oldUser.isOnline,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIndex] = updatedUser;
      if (_currentUserId == uId) {
        _currentUserProfile = updatedUser;
        _offlineDb.saveUserProfile(updatedUser);
      }
      _addNotification('User ${oldUser.name} is now ${updatedUser.isBanned ? "BANNED" : "UNBANNED"}.');
      notifyListeners();
    }
  }

  Future<void> sendGlobalPushNotification(String title, String body) async {
    _addNotification('[PUSH NOTIFICATION] $title: $body');
    notifyListeners();
  }

  Future<void> editTournament(Tournament tournament) async {
    final index = _mockTournaments.indexWhere((t) => t.id == tournament.id);
    if (index != -1) {
      _mockTournaments[index] = tournament;
      _offlineDb.saveTournaments(_mockTournaments);
      _addNotification('Tournament "${tournament.title}" details updated by admin.');
      notifyListeners();
    }
  }

  // --- Internal Utilities ---

  void _addNotification(String message) {
    _notifications.insert(0, message);
    if (_notifications.length > 50) {
      _notifications.removeLast();
    }
    _offlineDb.saveNotifications(_notifications);
  }

  void clearNotifications() {
    _notifications.clear();
    _offlineDb.saveNotifications(_notifications);
    notifyListeners();
  }

  void updateProfileName(String newName) {
    if (_currentUserProfile == null) return;
    final uIndex = _mockUsers.indexWhere((u) => u.uid == _currentUserId);
    if (uIndex != -1) {
      final oldUser = _mockUsers[uIndex];
      final updatedUser = UserProfile(
        uid: oldUser.uid,
        name: newName,
        email: oldUser.email,
        phone: oldUser.phone,
        walletBalance: oldUser.walletBalance,
        bonusBalance: oldUser.bonusBalance,
        referralBalance: oldUser.referralBalance,
        isAdmin: oldUser.isAdmin,
        joinedCount: oldUser.joinedCount,
        wonCount: oldUser.wonCount,
        totalEarnings: oldUser.totalEarnings,
        isBanned: oldUser.isBanned,
        isOnline: oldUser.isOnline,
        referralCode: oldUser.referralCode,
        referredBy: oldUser.referredBy,
      );
      _mockUsers[uIndex] = updatedUser;
      _currentUserProfile = updatedUser;
      _offlineDb.saveUserProfile(updatedUser);

      if (!_isOnline) {
        _addNotification('You are offline. Profile name update will sync when online.');
        _queuePendingAction('update_profile', {'name': newName});
      }
    }
    _addNotification('Profile name updated to "$newName".');
    notifyListeners();
  }

  // --- Background Sync Helpers ---

  Future<void> _queuePendingAction(String type, Map<String, dynamic> payload) async {
    final actions = await _offlineDb.loadPendingActions();
    actions.add({
      'type': type,
      'payload': payload,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
    await _offlineDb.savePendingActions(actions);
  }

  Future<void> _syncPendingActions() async {
    final actions = await _offlineDb.loadPendingActions();
    if (actions.isEmpty) return;

    final List<Map<String, dynamic>> remainingActions = [];

    for (final action in actions) {
      try {
        final type = action['type'];
        final payload = action['payload'] as Map<String, dynamic>;

        if (type == 'join') {
          final tournamentId = payload['tournamentId'];
          await _syncJoinTournament(tournamentId);
        } else if (type == 'deposit') {
          final amount = (payload['amount'] as num).toDouble();
          final upi = payload['upiTxnId'];
          await _syncDeposit(amount, upi);
        } else if (type == 'withdrawal') {
          final amount = (payload['amount'] as num).toDouble();
          final upi = payload['upiId'];
          await _syncWithdrawal(amount, upi);
        } else if (type == 'update_profile') {
          final name = payload['name'];
          await _syncProfileName(name);
        }
      } catch (e) {
        print('Error syncing action: $e');
        remainingActions.add(action);
      }
    }

    await _offlineDb.savePendingActions(remainingActions);
    _addNotification('Offline actions synchronized successfully!');
    
    // Save updated states to offline db
    await _offlineDb.saveUserProfile(_currentUserProfile);
    await _offlineDb.saveTournaments(_mockTournaments);
    await _offlineDb.saveTransactions(_mockTransactions);
    await _offlineDb.saveNotifications(_notifications);

    notifyListeners();
  }

  Future<void> _syncJoinTournament(String tournamentId) async {
    print('Syncing tournament join for $tournamentId');
  }

  Future<void> _syncDeposit(double amount, String upiTxnId) async {
    print('Syncing deposit for \$$amount');
  }

  Future<void> _syncWithdrawal(double amount, String upiId) async {
    print('Syncing withdrawal for \$$amount');
  }

  Future<void> _syncProfileName(String name) async {
    print('Syncing profile name update to $name');
  }
}
