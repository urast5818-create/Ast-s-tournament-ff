import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDummyApiKeyWeb00000000000000000000',
    appId: '1:123456789012:web:abcdef0123456789',
    messagingSenderId: '123456789012',
    projectId: 'asts-tournament',
    authDomain: 'asts-tournament.firebaseapp.com',
    storageBucket: 'asts-tournament.appspot.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDummyApiKeyAndroid00000000000000000',
    appId: '1:123456789012:android:abcdef0123456789',
    messagingSenderId: '123456789012',
    projectId: 'asts-tournament',
    storageBucket: 'asts-tournament.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDummyApiKeyIos000000000000000000000',
    appId: '1:123456789012:ios:abcdef0123456789',
    messagingSenderId: '123456789012',
    projectId: 'asts-tournament',
    storageBucket: 'asts-tournament.appspot.com',
    iosBundleId: 'com.example.astsTournament',
  );
}
